"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleTransaction = void 0;
// ** EMPRESA
__exportStar(require("./src/entities/empresa/parametros/divisas"), exports);
__exportStar(require("./src/entities/empresa/parametros/cargo"), exports);
__exportStar(require("./src/entities/empresa/configuracion"), exports);
__exportStar(require("./src/entities/empresa/empresa"), exports);
__exportStar(require("./src/entities/empresa/parametros/parametro"), exports);
__exportStar(require("./src/entities/empresa/ubigeo"), exports);
__exportStar(require("./src/entities/empresa/parametros/estado"), exports);
__exportStar(require("./src/entities/empresa/parametros/tipoDocumento"), exports);
__exportStar(require("./src/entities/empresa/parametros/tipoExpediente"), exports);
__exportStar(require("./src/entities/empresa/parametros/tipoPersona"), exports);
__exportStar(require("./src/entities/empresa/parametros/tipoTramite"), exports);
__exportStar(require("./src/entities/empresa/parametros/proceso"), exports);
__exportStar(require("./src/entities/empresa/parametros/prioridad"), exports);
__exportStar(require("./src/entities/empresa/parametros/dias"), exports);
__exportStar(require("./src/entities/empresa/parametros/token"), exports);
// ** SISTEMA
__exportStar(require("./src/entities/sistema/menu"), exports);
__exportStar(require("./src/entities/sistema/permisoMenu"), exports);
__exportStar(require("./src/entities/sistema/permisoRol"), exports);
__exportStar(require("./src/entities/sistema/permisoUsuario"), exports);
__exportStar(require("./src/entities/sistema/rol"), exports);
__exportStar(require("./src/entities/sistema/usuario"), exports);
__exportStar(require("./src/entities/sistema/usuarioUOrganica"), exports);
__exportStar(require("./src/entities/sistema/configEmail"), exports);
// ** TRAMITE
__exportStar(require("./src/entities/tramite/archivoAdjubtoMPV"), exports);
__exportStar(require("./src/entities/tramite/archivoAdjunto"), exports);
__exportStar(require("./src/entities/tramite/calendario"), exports);
__exportStar(require("./src/entities/tramite/correlativo"), exports);
__exportStar(require("./src/entities/tramite/correlativoUnidad"), exports);
__exportStar(require("./src/entities/tramite/documentoInterno"), exports);
__exportStar(require("./src/entities/tramite/encargadoUO"), exports);
__exportStar(require("./src/entities/tramite/expediente"), exports);
__exportStar(require("./src/entities/tramite/expedienteMPV"), exports);
__exportStar(require("./src/entities/tramite/expedienteVinculado"), exports);
__exportStar(require("./src/entities/tramite/partidaPresupuestal"), exports);
__exportStar(require("./src/entities/tramite/persona"), exports);
__exportStar(require("./src/entities/tramite/procedimiento"), exports);
__exportStar(require("./src/entities/tramite/procesoTramite"), exports);
__exportStar(require("./src/entities/tramite/requisito"), exports);
__exportStar(require("./src/entities/tramite/rubro"), exports);
__exportStar(require("./src/entities/tramite/sede"), exports);
__exportStar(require("./src/entities/tramite/solicitudMPV"), exports);
__exportStar(require("./src/entities/tramite/unidadOrganica"), exports);
// ** DATA SOURCE
__exportStar(require("./src/data-source"), exports);
__exportStar(require("./src/connection"), exports);
// ** FUNCIONES
var transacction_handler_1 = require("./src/core/handler/transacction.handler");
Object.defineProperty(exports, "handleTransaction", { enumerable: true, get: function () { return transacction_handler_1.handleTransaction; } });
//# sourceMappingURL=index.js.map