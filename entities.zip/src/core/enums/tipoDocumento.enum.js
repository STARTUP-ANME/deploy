"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoDocumento = void 0;
var TipoDocumento;
(function (TipoDocumento) {
    TipoDocumento["Identificacion"] = "Identificacion";
    TipoDocumento["Contrato"] = "contrato";
    TipoDocumento["Tramite"] = "tramite";
    TipoDocumento["Correlativo"] = "correlativo";
})(TipoDocumento || (exports.TipoDocumento = TipoDocumento = {}));
//# sourceMappingURL=tipoDocumento.enum.js.map