"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoEstado = void 0;
var TipoEstado;
(function (TipoEstado) {
    TipoEstado["Tramite"] = "tramite";
    TipoEstado["Bandeja"] = "bandeja";
})(TipoEstado || (exports.TipoEstado = TipoEstado = {}));
//# sourceMappingURL=tipoEstado.js.map