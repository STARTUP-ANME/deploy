"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Angel1733064648280 = void 0;
class Angel1733064648280 {
    constructor() {
        this.name = 'Angel1733064648280';
    }
    up(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" ADD "isAdmin" boolean NOT NULL DEFAULT false`);
            yield queryRunner.query(`ALTER TABLE "empresa"."ubigeo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."rol" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_rol" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."accion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu_accion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_usuario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuarios_u_organicas" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."estado" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."proceso_tramite" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."cargo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."encargado_uo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo_unidad" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."prioridad" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."empresa" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."requisito" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."partida_presupuestal" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."rubro" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_tramite" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."procedimiento" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_expediente" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."sede" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."unidad_organica" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."solicitud_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_vinculado" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."documento_interno" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permisos_menu" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."configuracion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."token" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."proceso" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."divisa" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."parametro" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."dias" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
        });
    }
    down(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`ALTER TABLE "empresa"."dias" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."parametro" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."divisa" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."proceso" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."token" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."configuracion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permisos_menu" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."documento_interno" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_vinculado" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."solicitud_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."unidad_organica" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."sede" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_expediente" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."procedimiento" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_tramite" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."rubro" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."partida_presupuestal" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."requisito" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."empresa" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."prioridad" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo_unidad" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."encargado_uo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."cargo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."proceso_tramite" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."estado" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuarios_u_organicas" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_usuario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu_accion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."accion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_rol" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."rol" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."ubigeo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" DROP COLUMN "isAdmin"`);
        });
    }
}
exports.Angel1733064648280 = Angel1733064648280;
//# sourceMappingURL=1733064648280-angel.js.map