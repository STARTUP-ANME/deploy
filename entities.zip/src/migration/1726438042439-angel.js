"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Angel1726438042439 = void 0;
class Angel1726438042439 {
    constructor() {
        this.name = 'Angel1726438042439';
    }
    up(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" RENAME COLUMN "valor" TO "tipo"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" RENAME COLUMN "tipoDocumentoid" TO "tipoDocumentoId"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" RENAME CONSTRAINT "PK_146dbcaa5e3cd0c0a480756fbc1" TO "PK_13a1aa5b635c7ab49a65e9c8191"`);
            yield queryRunner.query(`ALTER SEQUENCE "empresa"."tipo_documento_tipoDocumentoid_seq" RENAME TO "tipo_documento_tipoDocumentoId_seq"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" RENAME COLUMN "id" TO "calendarioId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" RENAME CONSTRAINT "PK_23635c1711d60068a65edb26b41" TO "PK_dac4d50f68f59bab090f7684525"`);
            yield queryRunner.query(`ALTER SEQUENCE "tramite"."calendario_id_seq" RENAME TO "calendario_calendarioId_seq"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP COLUMN "tipo"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP COLUMN "tipoDoc"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP CONSTRAINT "PK_703fc8452dd7231469d58e3afac"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP COLUMN "id"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP COLUMN "documentoId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD "repLegal" boolean NOT NULL DEFAULT false`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD "tipoPersonaId" integer NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD "tipoDocumentoId" integer NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD "correlativoId" SERIAL NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD CONSTRAINT "PK_4a37027cfba8d3f2055b955ab1b" PRIMARY KEY ("correlativoId")`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD "tipoDocumentoId" integer NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD CONSTRAINT "UQ_ee396e3403f03cb12cfb8edb29d" UNIQUE ("tipoDocumentoId")`);
            yield queryRunner.query(`ALTER TABLE "tramite"."solicitud_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."ubigeo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."unidad_organica" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" DROP COLUMN "tipo"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ADD "tipo" character varying(50) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."sede" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."rubro" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."requisito" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."proceso_tramite" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."procedimiento" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."partida_presupuestal" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_vinculado" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."encargado_uo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."documento_interno" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo_unidad" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" DROP COLUMN "color"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ADD "color" character varying(50) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" DROP COLUMN "textcolor"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ADD "textcolor" character varying(50) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."rol" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_rol" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."accion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu_accion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_usuario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto_mpv" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuarios_u_organicas" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permisos_menu" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_expediente" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."parametro" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."estado" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."divisa" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."configuracion" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."empresa" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "empresa"."cargo" ALTER COLUMN "audAnulado" SET DEFAULT 0`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD CONSTRAINT "FK_f6e02a9b6af249fd75d33131e58" FOREIGN KEY ("tipoDocumentoId") REFERENCES "empresa"."tipo_documento"("tipoDocumentoId") ON DELETE NO ACTION ON UPDATE NO ACTION`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD CONSTRAINT "FK_226c990e981ebfcdd0331ea7d40" FOREIGN KEY ("tipoPersonaId") REFERENCES "empresa"."tipo_persona"("tipoPersonaId") ON DELETE NO ACTION ON UPDATE NO ACTION`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD CONSTRAINT "FK_699302d51d0ce1358471af1e481" FOREIGN KEY ("sedeId") REFERENCES "tramite"."sede"("sedeId") ON DELETE NO ACTION ON UPDATE NO ACTION`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD CONSTRAINT "FK_ee396e3403f03cb12cfb8edb29d" FOREIGN KEY ("tipoDocumentoId") REFERENCES "empresa"."tipo_documento"("tipoDocumentoId") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        });
    }
    down(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP CONSTRAINT "FK_ee396e3403f03cb12cfb8edb29d"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP CONSTRAINT "FK_699302d51d0ce1358471af1e481"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP CONSTRAINT "FK_226c990e981ebfcdd0331ea7d40"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP CONSTRAINT "FK_f6e02a9b6af249fd75d33131e58"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."cargo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."empresa" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."configuracion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."divisa" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."estado" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."parametro" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_expediente" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permisos_menu" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuarios_u_organicas" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."usuario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_usuario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."menu_accion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."accion" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."permiso_rol" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "sistema"."rol" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" DROP COLUMN "textcolor"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ADD "textcolor" character varying(7) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" DROP COLUMN "color"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" ADD "color" character varying(7) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo_unidad" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."archivo_adjunto" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."documento_interno" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."encargado_uo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_vinculado" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."expediente_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."partida_presupuestal" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."procedimiento" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."proceso_tramite" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."requisito" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."rubro" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."sede" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" DROP COLUMN "tipo"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" ADD "tipo" integer NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."unidad_organica" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "empresa"."ubigeo" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."solicitud_mpv" ALTER COLUMN "audAnulado" SET DEFAULT '0'`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP CONSTRAINT "UQ_ee396e3403f03cb12cfb8edb29d"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP COLUMN "tipoDocumentoId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP CONSTRAINT "PK_4a37027cfba8d3f2055b955ab1b"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" DROP COLUMN "correlativoId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP COLUMN "tipoDocumentoId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP COLUMN "tipoPersonaId"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" DROP COLUMN "repLegal"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD "documentoId" integer NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD "id" SERIAL NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."correlativo" ADD CONSTRAINT "PK_703fc8452dd7231469d58e3afac" PRIMARY KEY ("id")`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD "tipoDoc" character varying(20) NOT NULL`);
            yield queryRunner.query(`ALTER TABLE "tramite"."personas" ADD "tipo" character varying(20) NOT NULL`);
            yield queryRunner.query(`ALTER SEQUENCE "tramite"."calendario_calendarioId_seq" RENAME TO "calendario_id_seq"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" RENAME CONSTRAINT "PK_dac4d50f68f59bab090f7684525" TO "PK_23635c1711d60068a65edb26b41"`);
            yield queryRunner.query(`ALTER TABLE "tramite"."calendario" RENAME COLUMN "calendarioId" TO "id"`);
            yield queryRunner.query(`ALTER SEQUENCE "empresa"."tipo_documento_tipoDocumentoId_seq" RENAME TO "tipo_documento_tipoDocumentoid_seq"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" RENAME CONSTRAINT "PK_13a1aa5b635c7ab49a65e9c8191" TO "PK_146dbcaa5e3cd0c0a480756fbc1"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_documento" RENAME COLUMN "tipoDocumentoId" TO "tipoDocumentoid"`);
            yield queryRunner.query(`ALTER TABLE "empresa"."tipo_persona" RENAME COLUMN "tipo" TO "valor"`);
        });
    }
}
exports.Angel1726438042439 = Angel1726438042439;
//# sourceMappingURL=1726438042439-angel.js.map