"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectToDatabase = exports.loadDatabaseConfig = void 0;
const typeorm_1 = require("typeorm");
const fs_1 = require("fs");
const path_1 = require("path");
const dbConnections = {};
// Cargar el archivo de configuración de las bases de datos
const loadDatabaseConfig = (subdomain) => {
    try {
        const configFile = (0, fs_1.readFileSync)((0, path_1.join)(__dirname, 'config.json'), 'utf-8');
        const config = JSON.parse(configFile);
        return config[subdomain];
    }
    catch (error) {
        console.error('Error cargando el archivo de configuración:', error);
        return undefined;
    }
};
exports.loadDatabaseConfig = loadDatabaseConfig;
// Función para conectar dinámicamente con la base de datos según el subdominio
const connectToDatabase = (subdomain) => __awaiter(void 0, void 0, void 0, function* () {
    if (!dbConnections[subdomain]) {
        const config = (0, exports.loadDatabaseConfig)(subdomain);
        if (config) {
            const dataSource = new typeorm_1.DataSource({
                type: 'postgres',
                host: String(process.env.DB_CONFIG_HOSTNAME),
                // extra: {
                //     socketPath: String(process.env.DB_CONFIG_HOSTNAME),
                // },
                // port: Number(process.env.DB_CONFIG_PORT),
                username: String(process.env.DB_CONFIG_USERNAME),
                password: String(process.env.DB_CONFIG_PASSWORD),
                database: config.database,
                //logging: Boolean(process.env.DB_CONFIG_LOGGING),
                logging: false,
                synchronize: true,
                entities: [
                    __dirname + '/entities/**/*.js'
                ],
                migrations: [
                    './src/template/*.js',
                    './src/migration/*.js',
                ],
                subscribers: [],
            }); // Instanciamos un DataSource
            yield dataSource.initialize(); // Inicializamos la conexión
            dbConnections[subdomain] = dataSource;
        }
        else {
            console.error(`No se encontró configuración para el subdominio: ${subdomain}`);
            return null;
        }
    }
    return dbConnections[subdomain];
});
exports.connectToDatabase = connectToDatabase;
//# sourceMappingURL=connection.js.map