"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomMigrationTemplate1724806375363 = void 0;
class CustomMigrationTemplate1724806375363 {
    up(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS empresa`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS sistema`);
            yield queryRunner.query(`CREATE SCHEMA IF NOT EXISTS tramite`);
        });
    }
    down(queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            // Aquí podrías definir la lógica de reversión si es necesario
        });
    }
}
exports.CustomMigrationTemplate1724806375363 = CustomMigrationTemplate1724806375363;
//# sourceMappingURL=schema.js.map