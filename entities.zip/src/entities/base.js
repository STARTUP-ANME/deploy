"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseModel = void 0;
const typeorm_1 = require("typeorm");
const order_decorator_1 = require("./order.decorator");
class BaseModel {
    static useDataSource(dataSource) {
        typeorm_1.BaseEntity.useDataSource.call(this, dataSource);
        const meta = dataSource.entityMetadatasMap.get(this);
        if (meta != null) {
            // reorder columns here
            meta.columns = [...meta.columns].sort((x, y) => {
                const orderX = (0, order_decorator_1.getOrder)(x.target.prototype, x.propertyName);
                const orderY = (0, order_decorator_1.getOrder)(y.target.prototype, y.propertyName);
                return orderX - orderY;
            });
        }
    }
}
exports.BaseModel = BaseModel;
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.Column)({ type: 'char', length: 1, default: () => '0' }),
    __metadata("design:type", String)
], BaseModel.prototype, "audAnulado", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.CreateDateColumn)({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP', }),
    __metadata("design:type", Date)
], BaseModel.prototype, "audFechaReg", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], BaseModel.prototype, "audUsuarioReg", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], BaseModel.prototype, "audIpReg", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.UpdateDateColumn)({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], BaseModel.prototype, "audFechaMod", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], BaseModel.prototype, "audUsuarioMod", void 0);
__decorate([
    (0, order_decorator_1.Order)(9999),
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], BaseModel.prototype, "audIpMod", void 0);
//# sourceMappingURL=base.js.map