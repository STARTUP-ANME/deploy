"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Order = Order;
exports.getOrder = getOrder;
const ORDER_KEY = Symbol.for('order_key');
function Order(value) {
    return (target, propertyKey) => {
        Reflect.defineMetadata(ORDER_KEY, value, target, propertyKey);
    };
}
function getOrder(target, propertyKey, defaultVal = 0) {
    const result = Reflect.getMetadata(ORDER_KEY, target, propertyKey);
    if (typeof result === 'number') {
        return result;
    }
    return defaultVal;
}
//# sourceMappingURL=order.decorator.js.map