"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmpresaModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const expediente_1 = require("../tramite/expediente");
const unidadOrganica_1 = require("../tramite/unidadOrganica");
const usuario_1 = require("../sistema/usuario");
const expedienteMPV_1 = require("../tramite/expedienteMPV");
let EmpresaModel = class EmpresaModel extends base_1.BaseModel {
};
exports.EmpresaModel = EmpresaModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "empresaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "abrev", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 11, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "ruc", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "direccion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }) // Assuming Imagen is binary data
    ,
    __metadata("design:type", String)
], EmpresaModel.prototype, "imagen", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "ubigeoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, default: '' }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "fut", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "plazoAdmin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "plazoLegal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "mesaParteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "usuarioMesaParteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "porVencer", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "contrasena", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "servidor", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], EmpresaModel.prototype, "puerto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "ssl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "plantillaProveido", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'time', nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "horaInicio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'time', nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "horaFin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "isPrintCargoExterno", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "isPrintCargoInterno", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "isPrintTicket", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "licencia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "validar", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "rutaMunicipalidad", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "dominioPrincipal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, default: '' }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "dominioQR", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', default: '', nullable: true }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "manual", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], EmpresaModel.prototype, "whatsapp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 15, default: '' }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "telefono", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, default: '' }),
    __metadata("design:type", String)
], EmpresaModel.prototype, "uuid", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.empresa),
    __metadata("design:type", Array)
], EmpresaModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expedienteMPV_1.ExpedienteMPVModel, expedientesMpv => expedientesMpv.empresa),
    __metadata("design:type", Array)
], EmpresaModel.prototype, "expedientesMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.empresas),
    (0, typeorm_1.JoinColumn)({ name: 'mesaParteId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], EmpresaModel.prototype, "mesaParte", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, usuario => usuario.empresasMesaParte),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioMesaParteId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], EmpresaModel.prototype, "usuarioMesaParte", void 0);
exports.EmpresaModel = EmpresaModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'empresa' })
], EmpresaModel);
//# sourceMappingURL=empresa.js.map