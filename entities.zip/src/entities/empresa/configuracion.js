"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfiguracionModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
let ConfiguracionModel = class ConfiguracionModel extends base_1.BaseModel {
};
exports.ConfiguracionModel = ConfiguracionModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ConfiguracionModel.prototype, "configuracionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ConfiguracionModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2 }),
    __metadata("design:type", Number)
], ConfiguracionModel.prototype, "uit", void 0);
exports.ConfiguracionModel = ConfiguracionModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'configuracion' })
], ConfiguracionModel);
//# sourceMappingURL=configuracion.js.map