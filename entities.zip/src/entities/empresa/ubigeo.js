"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UbigeoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const sede_1 = require("../tramite/sede");
let UbigeoModel = class UbigeoModel extends base_1.BaseModel {
};
exports.UbigeoModel = UbigeoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], UbigeoModel.prototype, "ubigeoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 2 }),
    __metadata("design:type", String)
], UbigeoModel.prototype, "departamentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 2 }),
    __metadata("design:type", String)
], UbigeoModel.prototype, "provinciaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 2 }),
    __metadata("design:type", String)
], UbigeoModel.prototype, "distritoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], UbigeoModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 2, nullable: true }),
    __metadata("design:type", String)
], UbigeoModel.prototype, "regionId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => sede_1.SedeModel, sede => sede.ubigeo),
    __metadata("design:type", Array)
], UbigeoModel.prototype, "sede", void 0);
exports.UbigeoModel = UbigeoModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'ubigeo' })
], UbigeoModel);
//# sourceMappingURL=ubigeo.js.map