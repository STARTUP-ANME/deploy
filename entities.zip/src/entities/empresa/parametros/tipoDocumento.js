"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoDocumentoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const tipoDocumento_enum_1 = require("../../../core/enums/tipoDocumento.enum");
const persona_1 = require("../../tramite/persona");
const encargadoUO_1 = require("../../tramite/encargadoUO");
const correlativoUnidad_1 = require("../../tramite/correlativoUnidad");
const expediente_1 = require("../../tramite/expediente");
const procesoTramite_1 = require("../../tramite/procesoTramite");
let TipoDocumentoModel = class TipoDocumentoModel extends base_1.BaseModel {
};
exports.TipoDocumentoModel = TipoDocumentoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], TipoDocumentoModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], TipoDocumentoModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: null }),
    __metadata("design:type", Number)
], TipoDocumentoModel.prototype, "caracteres", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: tipoDocumento_enum_1.TipoDocumento }),
    __metadata("design:type", String)
], TipoDocumentoModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => persona_1.PersonaModel, persona => persona.tipoDocumento),
    __metadata("design:type", Array)
], TipoDocumentoModel.prototype, "personas", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => encargadoUO_1.EncargadosUOModel, encargadoUO => encargadoUO.tipoDocumento),
    __metadata("design:type", Array)
], TipoDocumentoModel.prototype, "encargadoUO", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => correlativoUnidad_1.CorrelativoUnidadModel, correlativoUnidad => correlativoUnidad.tipoDocumento),
    __metadata("design:type", Array)
], TipoDocumentoModel.prototype, "correlativoUnidad", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, correlativoUnidad => correlativoUnidad.tipoDocumento),
    __metadata("design:type", Array)
], TipoDocumentoModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.tipoDocumento),
    __metadata("design:type", Array)
], TipoDocumentoModel.prototype, "procesoTramites", void 0);
exports.TipoDocumentoModel = TipoDocumentoModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'tipo_documento' })
], TipoDocumentoModel);
//# sourceMappingURL=tipoDocumento.js.map