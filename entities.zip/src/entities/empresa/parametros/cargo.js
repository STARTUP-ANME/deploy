"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CargoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const encargadoUO_1 = require("../../tramite/encargadoUO");
let CargoModel = class CargoModel extends base_1.BaseModel {
};
exports.CargoModel = CargoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CargoModel.prototype, "cargoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], CargoModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => encargadoUO_1.EncargadosUOModel, encargadoUO => encargadoUO.cargo),
    __metadata("design:type", Array)
], CargoModel.prototype, "encargadoUO", void 0);
exports.CargoModel = CargoModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'cargo' })
], CargoModel);
//# sourceMappingURL=cargo.js.map