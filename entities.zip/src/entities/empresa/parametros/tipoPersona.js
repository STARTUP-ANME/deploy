"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoPersonaModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const persona_1 = require("../../tramite/persona");
const tipoDocumento_1 = require("./tipoDocumento");
let TipoPersonaModel = class TipoPersonaModel extends base_1.BaseModel {
};
exports.TipoPersonaModel = TipoPersonaModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], TipoPersonaModel.prototype, "tipoPersonaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], TipoPersonaModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], TipoPersonaModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => persona_1.PersonaModel, persona => persona.tipoPersona),
    __metadata("design:type", Array)
], TipoPersonaModel.prototype, "personas", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.tipoPersona, { nullable: true }),
    __metadata("design:type", Array)
], TipoPersonaModel.prototype, "tipoDocumento", void 0);
exports.TipoPersonaModel = TipoPersonaModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'tipo_persona' })
], TipoPersonaModel);
//# sourceMappingURL=tipoPersona.js.map