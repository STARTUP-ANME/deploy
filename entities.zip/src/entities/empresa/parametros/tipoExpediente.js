"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoExpedienteModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const correlativo_1 = require("../../tramite/correlativo");
const expediente_1 = require("../../tramite/expediente");
const expedienteMPV_1 = require("../../tramite/expedienteMPV");
let TipoExpedienteModel = class TipoExpedienteModel extends base_1.BaseModel {
};
exports.TipoExpedienteModel = TipoExpedienteModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], TipoExpedienteModel.prototype, "tipoExpedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10 }),
    __metadata("design:type", String)
], TipoExpedienteModel.prototype, "codigo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], TipoExpedienteModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20 }),
    __metadata("design:type", String)
], TipoExpedienteModel.prototype, "color", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => correlativo_1.CorrelativoModel, correlativo => correlativo.tipoExpediente),
    __metadata("design:type", correlativo_1.CorrelativoModel)
], TipoExpedienteModel.prototype, "correlativo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.tipoExpediente),
    __metadata("design:type", Array)
], TipoExpedienteModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expedienteMPV_1.ExpedienteMPVModel, expedientesMpv => expedientesMpv.tipoExpediente),
    __metadata("design:type", Array)
], TipoExpedienteModel.prototype, "expedientesMpv", void 0);
exports.TipoExpedienteModel = TipoExpedienteModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'tipo_expediente' })
], TipoExpedienteModel);
//# sourceMappingURL=tipoExpediente.js.map