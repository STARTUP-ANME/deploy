"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EstadoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const tipoEstado_1 = require("../../../core/enums/tipoEstado");
const expediente_1 = require("../../tramite/expediente");
const procesoTramite_1 = require("../../tramite/procesoTramite");
const expedienteMPV_1 = require("../../tramite/expedienteMPV");
let EstadoModel = class EstadoModel extends base_1.BaseModel {
};
exports.EstadoModel = EstadoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], EstadoModel.prototype, "estadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20 }),
    __metadata("design:type", String)
], EstadoModel.prototype, "codigo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], EstadoModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 30, nullable: true }),
    __metadata("design:type", String)
], EstadoModel.prototype, "color", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: tipoEstado_1.TipoEstado }),
    __metadata("design:type", String)
], EstadoModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.estado),
    __metadata("design:type", Array)
], EstadoModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expedienteMPV_1.ExpedienteMPVModel, expedientesMpv => expedientesMpv.estado),
    __metadata("design:type", Array)
], EstadoModel.prototype, "expedientesMpv", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.estado),
    __metadata("design:type", Array)
], EstadoModel.prototype, "procesoTramites", void 0);
exports.EstadoModel = EstadoModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'estado' })
], EstadoModel);
//# sourceMappingURL=estado.js.map