"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TipoTramiteModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../../base");
const procedimiento_1 = require("../../tramite/procedimiento");
let TipoTramiteModel = class TipoTramiteModel extends base_1.BaseModel {
};
exports.TipoTramiteModel = TipoTramiteModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], TipoTramiteModel.prototype, "tipoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], TipoTramiteModel.prototype, "codigo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 15 }),
    __metadata("design:type", String)
], TipoTramiteModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TipoTramiteModel.prototype, "valor", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], TipoTramiteModel.prototype, "valorII", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procedimiento_1.ProcedimientoModel, procedimiento => procedimiento.tipoTramite),
    __metadata("design:type", Array)
], TipoTramiteModel.prototype, "procedimientos", void 0);
exports.TipoTramiteModel = TipoTramiteModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'empresa', name: 'tipo_tramite' })
], TipoTramiteModel);
//# sourceMappingURL=tipoTramite.js.map