"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MenuModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const menuAccion_1 = require("./menuAccion");
const permisoRol_1 = require("./permisoRol");
const permisoUsuario_1 = require("./permisoUsuario");
let MenuModel = class MenuModel extends base_1.BaseModel {
};
exports.MenuModel = MenuModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], MenuModel.prototype, "menuId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], MenuModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', default: 'read' }),
    __metadata("design:type", String)
], MenuModel.prototype, "action", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "subject", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], MenuModel.prototype, "contenido", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], MenuModel.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => MenuModel, (menu) => menu.children),
    (0, typeorm_1.JoinColumn)({ name: 'parentId' }),
    __metadata("design:type", MenuModel)
], MenuModel.prototype, "parent", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => MenuModel, (menu) => menu.parent),
    __metadata("design:type", Array)
], MenuModel.prototype, "children", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => menuAccion_1.MenuAccionModel, menuAccion => menuAccion.menu),
    __metadata("design:type", Array)
], MenuModel.prototype, "menuAcciones", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoRol_1.PermisoRolModel, (permisoRol) => permisoRol.menu),
    __metadata("design:type", Array)
], MenuModel.prototype, "permisosRoles", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoUsuario_1.PermisoUsuarioModel, (permisoUsario) => permisoUsario.menu),
    __metadata("design:type", Array)
], MenuModel.prototype, "permisosUsuarios", void 0);
exports.MenuModel = MenuModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'menu', schema: 'sistema' })
], MenuModel);
//# sourceMappingURL=menu.js.map