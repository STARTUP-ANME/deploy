"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermisoUsuarioModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const usuario_1 = require("./usuario");
const menu_1 = require("./menu");
const accion_1 = require("./accion");
let PermisoUsuarioModel = class PermisoUsuarioModel extends base_1.BaseModel {
};
exports.PermisoUsuarioModel = PermisoUsuarioModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoUsuarioModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoUsuarioModel.prototype, "menuId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoUsuarioModel.prototype, "accionId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, (usuario) => usuario.permisosUsuarios),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], PermisoUsuarioModel.prototype, "usuario", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => menu_1.MenuModel, (menu) => menu.permisosUsuarios),
    (0, typeorm_1.JoinColumn)({ name: 'menuId', referencedColumnName: 'menuId' }) // Especifica la columna en esta tabla que será la clave externa
    ,
    __metadata("design:type", menu_1.MenuModel)
], PermisoUsuarioModel.prototype, "menu", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => accion_1.AccionModel, (accion) => accion.permisosUsuarios),
    (0, typeorm_1.JoinColumn)({ name: 'accionId', referencedColumnName: 'accionId' }) // Especifica la columna en esta tabla que será la clave externa
    ,
    __metadata("design:type", accion_1.AccionModel)
], PermisoUsuarioModel.prototype, "accion", void 0);
exports.PermisoUsuarioModel = PermisoUsuarioModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sistema', name: 'permiso_usuario' })
], PermisoUsuarioModel);
//# sourceMappingURL=permisoUsuario.js.map