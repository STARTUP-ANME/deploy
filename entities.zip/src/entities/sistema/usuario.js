"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsuarioModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const permisoUsuario_1 = require("./permisoUsuario");
const persona_1 = require("../tramite/persona");
const rol_1 = require("./rol");
const usuarioUOrganica_1 = require("./usuarioUOrganica");
const procesoTramite_1 = require("../tramite/procesoTramite");
const expediente_1 = require("../tramite/expediente");
let UsuarioModel = class UsuarioModel extends base_1.BaseModel {
};
exports.UsuarioModel = UsuarioModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], UsuarioModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UsuarioModel.prototype, "personaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150 }),
    __metadata("design:type", String)
], UsuarioModel.prototype, "usuarioNombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 150 }),
    __metadata("design:type", String)
], UsuarioModel.prototype, "clave", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], UsuarioModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], UsuarioModel.prototype, "fechaCambioClave", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: '255', default: '' }),
    __metadata("design:type", String)
], UsuarioModel.prototype, "avatar", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UsuarioModel.prototype, "rolId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => rol_1.RolModel, (persona) => persona.usuarios),
    (0, typeorm_1.JoinColumn)({ name: 'rolId', referencedColumnName: 'rolId' }),
    __metadata("design:type", rol_1.RolModel)
], UsuarioModel.prototype, "rol", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => persona_1.PersonaModel, (persona) => persona.usuarios),
    (0, typeorm_1.JoinColumn)({ name: 'personaId', referencedColumnName: 'personaId' }),
    __metadata("design:type", persona_1.PersonaModel)
], UsuarioModel.prototype, "persona", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoUsuario_1.PermisoUsuarioModel, (permisoUsario) => permisoUsario.usuario),
    __metadata("design:type", Array)
], UsuarioModel.prototype, "permisosUsuarios", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => usuarioUOrganica_1.UsuarioUOrganicaModel, (usuarioUOrganica) => usuarioUOrganica.usuario),
    __metadata("design:type", Array)
], UsuarioModel.prototype, "usuarioUOrganicas", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.usuarioCrea),
    __metadata("design:type", Array)
], UsuarioModel.prototype, "procesoTramitesCrea", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.usuarioRecibe),
    __metadata("design:type", Array)
], UsuarioModel.prototype, "procesoTramitesRecibe", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.usuario),
    __metadata("design:type", Array)
], UsuarioModel.prototype, "expedientes", void 0);
exports.UsuarioModel = UsuarioModel = __decorate([
    (0, typeorm_1.Entity)('usuario', { schema: 'sistema' })
], UsuarioModel);
//# sourceMappingURL=usuario.js.map