"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MenuAccionModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const accion_1 = require("./accion");
const menu_1 = require("./menu");
let MenuAccionModel = class MenuAccionModel extends base_1.BaseModel {
};
exports.MenuAccionModel = MenuAccionModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], MenuAccionModel.prototype, "menuId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], MenuAccionModel.prototype, "accionId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => menu_1.MenuModel, menu => menu.menuAcciones, { eager: false, onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'menuId', referencedColumnName: 'menuId' }),
    __metadata("design:type", menu_1.MenuModel)
], MenuAccionModel.prototype, "menu", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => accion_1.AccionModel, accion => accion.menuAcciones, { eager: false, onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'accionId', referencedColumnName: 'accionId' }),
    __metadata("design:type", accion_1.AccionModel)
], MenuAccionModel.prototype, "accion", void 0);
exports.MenuAccionModel = MenuAccionModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'menu_accion', schema: 'sistema' })
], MenuAccionModel);
//# sourceMappingURL=menuAccion.js.map