"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigEmailModel = void 0;
const typeorm_1 = require("typeorm");
let ConfigEmailModel = class ConfigEmailModel {
};
exports.ConfigEmailModel = ConfigEmailModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ConfigEmailModel.prototype, "configEmailId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100, default: '' }),
    __metadata("design:type", String)
], ConfigEmailModel.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100 }),
    __metadata("design:type", String)
], ConfigEmailModel.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 200 }),
    __metadata("design:type", String)
], ConfigEmailModel.prototype, "pass", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 50 }),
    __metadata("design:type", String)
], ConfigEmailModel.prototype, "host", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 20 }),
    __metadata("design:type", Number)
], ConfigEmailModel.prototype, "port", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "varchar", length: 100, default: true }),
    __metadata("design:type", Boolean)
], ConfigEmailModel.prototype, "secure", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: "int" }),
    __metadata("design:type", Number)
], ConfigEmailModel.prototype, "companyId", void 0);
exports.ConfigEmailModel = ConfigEmailModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sistema', name: 'config_email' })
], ConfigEmailModel);
//# sourceMappingURL=configEmail.js.map