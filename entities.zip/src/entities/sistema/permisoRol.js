"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PermisoRolModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const rol_1 = require("./rol");
const menu_1 = require("./menu");
const accion_1 = require("./accion");
let PermisoRolModel = class PermisoRolModel extends base_1.BaseModel {
};
exports.PermisoRolModel = PermisoRolModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoRolModel.prototype, "rolId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoRolModel.prototype, "menuId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], PermisoRolModel.prototype, "accionId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => rol_1.RolModel, (rol) => rol.permisosRoles),
    (0, typeorm_1.JoinColumn)({ name: 'rolId', referencedColumnName: 'rolId' }),
    __metadata("design:type", rol_1.RolModel)
], PermisoRolModel.prototype, "rol", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => menu_1.MenuModel, (menu) => menu.permisosRoles),
    (0, typeorm_1.JoinColumn)({ name: 'menuId', referencedColumnName: 'menuId' }) // Especifica la columna en esta tabla que será la clave externa
    ,
    __metadata("design:type", menu_1.MenuModel)
], PermisoRolModel.prototype, "menu", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => accion_1.AccionModel, (accion) => accion.permisosRoles),
    (0, typeorm_1.JoinColumn)({ name: 'accionId', referencedColumnName: 'accionId' }) // Especifica la columna en esta tabla que será la clave externa
    ,
    __metadata("design:type", accion_1.AccionModel)
], PermisoRolModel.prototype, "accion", void 0);
exports.PermisoRolModel = PermisoRolModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'sistema', name: 'permiso_rol' })
], PermisoRolModel);
//# sourceMappingURL=permisoRol.js.map