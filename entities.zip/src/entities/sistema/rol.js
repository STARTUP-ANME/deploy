"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const permisoRol_1 = require("./permisoRol");
const usuario_1 = require("./usuario");
let RolModel = class RolModel extends base_1.BaseModel {
};
exports.RolModel = RolModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], RolModel.prototype, "rolId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], RolModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', default: '' }),
    __metadata("design:type", String)
], RolModel.prototype, "detalle", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bool' }),
    __metadata("design:type", Boolean)
], RolModel.prototype, "interno", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'bool', nullable: true }),
    __metadata("design:type", Boolean)
], RolModel.prototype, "correlativo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoRol_1.PermisoRolModel, (permisoRol) => permisoRol.rol),
    __metadata("design:type", Array)
], RolModel.prototype, "permisosRoles", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => usuario_1.UsuarioModel, (usuario) => usuario.rol),
    __metadata("design:type", Array)
], RolModel.prototype, "usuarios", void 0);
exports.RolModel = RolModel = __decorate([
    (0, typeorm_1.Entity)('rol', { schema: 'sistema' })
], RolModel);
//# sourceMappingURL=rol.js.map