"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsuarioUOrganicaModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const usuario_1 = require("./usuario");
const unidadOrganica_1 = require("../tramite/unidadOrganica");
let UsuarioUOrganicaModel = class UsuarioUOrganicaModel extends base_1.BaseModel {
};
exports.UsuarioUOrganicaModel = UsuarioUOrganicaModel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], UsuarioUOrganicaModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'int' }),
    __metadata("design:type", Number)
], UsuarioUOrganicaModel.prototype, "unidadOrganicaId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ type: 'bool', default: false }),
    __metadata("design:type", Boolean)
], UsuarioUOrganicaModel.prototype, "select", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, (usuario) => usuario.usuarioUOrganicas),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], UsuarioUOrganicaModel.prototype, "usuario", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, (unidadOrganica) => unidadOrganica.usuarioUOrganicas),
    (0, typeorm_1.JoinColumn)({ name: 'unidadOrganicaId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], UsuarioUOrganicaModel.prototype, "unidadOrganica", void 0);
exports.UsuarioUOrganicaModel = UsuarioUOrganicaModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'usuarios_u_organicas', schema: 'sistema' })
], UsuarioUOrganicaModel);
//# sourceMappingURL=usuarioUOrganica.js.map