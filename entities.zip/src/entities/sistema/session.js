"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionModel = void 0;
const typeorm_1 = require("typeorm");
const usuario_1 = require("./usuario");
let SessionModel = class SessionModel {
};
exports.SessionModel = SessionModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SessionModel.prototype, "sessionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], SessionModel.prototype, "token", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SessionModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, (usuario) => usuario.sessions),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], SessionModel.prototype, "usuario", void 0);
exports.SessionModel = SessionModel = __decorate([
    (0, typeorm_1.Entity)('session', { schema: 'sistema' })
], SessionModel);
//# sourceMappingURL=session.js.map