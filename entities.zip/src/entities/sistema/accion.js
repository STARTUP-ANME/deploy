"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccionModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const menuAccion_1 = require("./menuAccion");
const permisoRol_1 = require("./permisoRol");
const permisoUsuario_1 = require("./permisoUsuario");
let AccionModel = class AccionModel extends base_1.BaseModel {
};
exports.AccionModel = AccionModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], AccionModel.prototype, "accionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], AccionModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], AccionModel.prototype, "accion", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => menuAccion_1.MenuAccionModel, menuAccion => menuAccion.accion),
    __metadata("design:type", Array)
], AccionModel.prototype, "menuAcciones", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoRol_1.PermisoRolModel, (permisoRol) => permisoRol.accion),
    __metadata("design:type", Array)
], AccionModel.prototype, "permisosRoles", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => permisoUsuario_1.PermisoUsuarioModel, (permisoUsario) => permisoUsario.accion),
    __metadata("design:type", Array)
], AccionModel.prototype, "permisosUsuarios", void 0);
exports.AccionModel = AccionModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'accion', schema: 'sistema' })
], AccionModel);
//# sourceMappingURL=accion.js.map