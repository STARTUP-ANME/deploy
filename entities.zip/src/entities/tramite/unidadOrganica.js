"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnidadOrganicaModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const sede_1 = require("./sede");
const procedimiento_1 = require("./procedimiento");
const usuarioUOrganica_1 = require("../sistema/usuarioUOrganica");
const encargadoUO_1 = require("./encargadoUO");
const correlativoUnidad_1 = require("./correlativoUnidad");
const expediente_1 = require("./expediente");
const archivoAdjunto_1 = require("./archivoAdjunto");
const procesoTramite_1 = require("./procesoTramite");
const archivoAdjuntoMPV_1 = require("./archivoAdjuntoMPV");
const empresa_1 = require("../empresa/empresa");
let UnidadOrganicaModel = class UnidadOrganicaModel extends base_1.BaseModel {
};
exports.UnidadOrganicaModel = UnidadOrganicaModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], UnidadOrganicaModel.prototype, "unidadOrganicaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], UnidadOrganicaModel.prototype, "abreviatura", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], UnidadOrganicaModel.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], UnidadOrganicaModel.prototype, "nivel", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UnidadOrganicaModel.prototype, "relacionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UnidadOrganicaModel.prototype, "ordenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], UnidadOrganicaModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], UnidadOrganicaModel.prototype, "tupa", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], UnidadOrganicaModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sede_1.SedeModel, sede => sede.unidadOrganica, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'sedeId', referencedColumnName: 'sedeId' }),
    __metadata("design:type", sede_1.SedeModel)
], UnidadOrganicaModel.prototype, "sede", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procedimiento_1.ProcedimientoModel, procedimiento => procedimiento.unidadOrganica),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "procedimientos", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => empresa_1.EmpresaModel, empresa => empresa.mesaParte),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "empresas", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => UnidadOrganicaModel, unidadOrganica => unidadOrganica.subunidades, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'relacionId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", UnidadOrganicaModel)
], UnidadOrganicaModel.prototype, "relacion", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => UnidadOrganicaModel, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'ordenId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", UnidadOrganicaModel)
], UnidadOrganicaModel.prototype, "orden", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => UnidadOrganicaModel, unidadOrganica => unidadOrganica.relacion),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "subunidades", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => usuarioUOrganica_1.UsuarioUOrganicaModel, (usuarioUOrganica) => usuarioUOrganica.unidadOrganica),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "usuarioUOrganicas", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => encargadoUO_1.EncargadosUOModel, encargadoUO => encargadoUO.unidadOrganica),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "encargadoUO", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => correlativoUnidad_1.CorrelativoUnidadModel, correlativoUnidad => correlativoUnidad.unidadOrganica),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "correlativoUnidad", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.origen),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => archivoAdjunto_1.ArchivoAdjuntoModel, archivoAdjunto => archivoAdjunto.origen),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "archivoAdjuntos", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => archivoAdjuntoMPV_1.ArchivoAdjuntoMPVModel, archivoAdjunto => archivoAdjunto.origen),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "archivoAdjuntosMpv", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.origen),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "procesoTramitesOrigen", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.destino),
    __metadata("design:type", Array)
], UnidadOrganicaModel.prototype, "procesoTramitesDestino", void 0);
exports.UnidadOrganicaModel = UnidadOrganicaModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'unidad_organica', schema: 'tramite' })
], UnidadOrganicaModel);
//# sourceMappingURL=unidadOrganica.js.map