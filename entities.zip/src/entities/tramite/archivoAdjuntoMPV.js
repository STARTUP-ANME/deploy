"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArchivoAdjuntoMPVModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const unidadOrganica_1 = require("./unidadOrganica");
const expedienteMPV_1 = require("./expedienteMPV");
let ArchivoAdjuntoMPVModel = class ArchivoAdjuntoMPVModel extends base_1.BaseModel {
};
exports.ArchivoAdjuntoMPVModel = ArchivoAdjuntoMPVModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "archivoAdjuntoMpvId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "expedienteMPVId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoMPVModel.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoMPVModel.prototype, "extension", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoMPVModel.prototype, "url", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "origenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "destinos", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "procesos", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoMPVModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => expedienteMPV_1.ExpedienteMPVModel, expedienteMpv => expedienteMpv.archivoAdjuntosMpv),
    (0, typeorm_1.JoinColumn)({ name: 'expedienteMPVId', referencedColumnName: 'expedienteMPVId' }),
    __metadata("design:type", expedienteMPV_1.ExpedienteMPVModel)
], ArchivoAdjuntoMPVModel.prototype, "expedienteMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.archivoAdjuntosMpv),
    (0, typeorm_1.JoinColumn)({ name: 'origenId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ArchivoAdjuntoMPVModel.prototype, "origen", void 0);
exports.ArchivoAdjuntoMPVModel = ArchivoAdjuntoMPVModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'tramite', name: 'archivo_adjunto_mpv' })
], ArchivoAdjuntoMPVModel);
//# sourceMappingURL=archivoAdjuntoMPV.js.map