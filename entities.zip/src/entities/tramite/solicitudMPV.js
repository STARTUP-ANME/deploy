"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SolicitudMPVModel = void 0;
const typeorm_1 = require("typeorm");
const expedienteMPV_1 = require("./expedienteMPV");
let SolicitudMPVModel = class SolicitudMPVModel {
};
exports.SolicitudMPVModel = SolicitudMPVModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], SolicitudMPVModel.prototype, "solicitudId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], SolicitudMPVModel.prototype, "token", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], SolicitudMPVModel.prototype, "fecha", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", String)
], SolicitudMPVModel.prototype, "codigo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], SolicitudMPVModel.prototype, "valido", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => expedienteMPV_1.ExpedienteMPVModel, expedienteMpv => expedienteMpv.solicitudMpv),
    __metadata("design:type", expedienteMPV_1.ExpedienteMPVModel)
], SolicitudMPVModel.prototype, "expedienteMpv", void 0);
exports.SolicitudMPVModel = SolicitudMPVModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'solicitud_mpv', schema: 'tramite' })
], SolicitudMPVModel);
//# sourceMappingURL=solicitudMPV.js.map