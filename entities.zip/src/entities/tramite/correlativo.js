"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CorrelativoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const sede_1 = require("./sede");
const tipoExpediente_1 = require("../empresa/parametros/tipoExpediente");
let CorrelativoModel = class CorrelativoModel extends base_1.BaseModel {
};
exports.CorrelativoModel = CorrelativoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "correlativoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "tipoExpedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "correlativo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "longitud", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], CorrelativoModel.prototype, "prefijo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sede_1.SedeModel, sede => sede.correlativo),
    (0, typeorm_1.JoinColumn)({ name: 'sedeId', referencedColumnName: 'sedeId' }),
    __metadata("design:type", sede_1.SedeModel)
], CorrelativoModel.prototype, "sede", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => tipoExpediente_1.TipoExpedienteModel, tipoExpediente => tipoExpediente.correlativo),
    (0, typeorm_1.JoinColumn)({ name: 'tipoExpedienteId', referencedColumnName: 'tipoExpedienteId' }),
    __metadata("design:type", tipoExpediente_1.TipoExpedienteModel)
], CorrelativoModel.prototype, "tipoExpediente", void 0);
exports.CorrelativoModel = CorrelativoModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'correlativo', schema: 'tramite' })
], CorrelativoModel);
//# sourceMappingURL=correlativo.js.map