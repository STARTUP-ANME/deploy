"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcedimientoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const unidadOrganica_1 = require("./unidadOrganica");
const rubro_1 = require("./rubro");
const expediente_1 = require("./expediente");
const tipoTramite_1 = require("../empresa/parametros/tipoTramite");
const expedienteMPV_1 = require("./expedienteMPV");
let ProcedimientoModel = class ProcedimientoModel extends base_1.BaseModel {
};
exports.ProcedimientoModel = ProcedimientoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProcedimientoModel.prototype, "procedimientoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProcedimientoModel.prototype, "unidadOrganicaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], ProcedimientoModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcedimientoModel.prototype, "plazo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcedimientoModel.prototype, "tipoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], ProcedimientoModel.prototype, "showMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.procedimientos),
    (0, typeorm_1.JoinColumn)({ name: 'unidadOrganicaId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ProcedimientoModel.prototype, "unidadOrganica", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => rubro_1.RubroModel, rubro => rubro.procedimiento),
    __metadata("design:type", Array)
], ProcedimientoModel.prototype, "rubros", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.procedimiento),
    __metadata("design:type", Array)
], ProcedimientoModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expedienteMPV_1.ExpedienteMPVModel, expedientesMpv => expedientesMpv.procedimiento),
    __metadata("design:type", Array)
], ProcedimientoModel.prototype, "expedientesMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoTramite_1.TipoTramiteModel, tipoProcedimiento => tipoProcedimiento.procedimientos),
    (0, typeorm_1.JoinColumn)({ name: 'tipoTramiteId', referencedColumnName: 'tipoTramiteId' }),
    __metadata("design:type", tipoTramite_1.TipoTramiteModel)
], ProcedimientoModel.prototype, "tipoTramite", void 0);
exports.ProcedimientoModel = ProcedimientoModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'procedimiento', schema: 'tramite' })
], ProcedimientoModel);
//# sourceMappingURL=procedimiento.js.map