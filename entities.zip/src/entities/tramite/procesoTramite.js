"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcesoTramiteModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const expediente_1 = require("./expediente");
const unidadOrganica_1 = require("./unidadOrganica");
const estado_1 = require("../empresa/parametros/estado");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
const usuario_1 = require("../sistema/usuario");
const expedienteMPV_1 = require("./expedienteMPV");
let ProcesoTramiteModel = class ProcesoTramiteModel extends base_1.BaseModel {
};
exports.ProcesoTramiteModel = ProcesoTramiteModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "procesoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "expedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "expedienteMPVId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "origenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "destinoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "etapa", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "orden", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "referenciaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', nullable: true }),
    __metadata("design:type", Boolean)
], ProcesoTramiteModel.prototype, "isComplete", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ProcesoTramiteModel.prototype, "fRegistro", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ProcesoTramiteModel.prototype, "fRecibido", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ProcesoTramiteModel.prototype, "fAtencion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "observaciones", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "motivo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ProcesoTramiteModel.prototype, "leido", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], ProcesoTramiteModel.prototype, "fLeido", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "estadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "tramites", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "tipoEnvioId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "documentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "documento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "folios", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "asunto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProcesoTramiteModel.prototype, "importancia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "usuarioCreaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProcesoTramiteModel.prototype, "usuarioRecibeId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => expediente_1.ExpedienteModel, expediente => expediente.procesoTramites),
    (0, typeorm_1.JoinColumn)({ name: 'expedienteId', referencedColumnName: 'expedienteId' }),
    __metadata("design:type", expediente_1.ExpedienteModel)
], ProcesoTramiteModel.prototype, "expediente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => expedienteMPV_1.ExpedienteMPVModel, expedienteMpv => expedienteMpv.procesoTramites),
    (0, typeorm_1.JoinColumn)({ name: 'expedienteMPVId', referencedColumnName: 'expedienteMPVId' }),
    __metadata("design:type", expedienteMPV_1.ExpedienteMPVModel)
], ProcesoTramiteModel.prototype, "expedienteMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, uOrganica => uOrganica.procesoTramitesOrigen),
    (0, typeorm_1.JoinColumn)({ name: 'origenId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ProcesoTramiteModel.prototype, "origen", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, uOrganica => uOrganica.procesoTramitesDestino),
    (0, typeorm_1.JoinColumn)({ name: 'destinoId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ProcesoTramiteModel.prototype, "destino", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => estado_1.EstadoModel, estado => estado.procesoTramites),
    (0, typeorm_1.JoinColumn)({ name: 'estadoId', referencedColumnName: 'estadoId' }),
    __metadata("design:type", estado_1.EstadoModel)
], ProcesoTramiteModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, usuario => usuario.procesoTramitesCrea),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioCreaId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], ProcesoTramiteModel.prototype, "usuarioCrea", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, usuario => usuario.procesoTramitesRecibe),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioRecibeId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], ProcesoTramiteModel.prototype, "usuarioRecibe", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.procesoTramites),
    (0, typeorm_1.JoinColumn)({ name: 'documentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], ProcesoTramiteModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => ProcesoTramiteModel),
    (0, typeorm_1.JoinColumn)({ name: 'referenciaId' }),
    __metadata("design:type", ProcesoTramiteModel)
], ProcesoTramiteModel.prototype, "referencia", void 0);
exports.ProcesoTramiteModel = ProcesoTramiteModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'proceso_tramite', schema: 'tramite' })
], ProcesoTramiteModel);
//# sourceMappingURL=procesoTramite.js.map