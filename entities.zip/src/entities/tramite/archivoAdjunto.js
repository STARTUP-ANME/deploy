"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArchivoAdjuntoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const expediente_1 = require("./expediente");
const unidadOrganica_1 = require("./unidadOrganica");
let ArchivoAdjuntoModel = class ArchivoAdjuntoModel extends base_1.BaseModel {
};
exports.ArchivoAdjuntoModel = ArchivoAdjuntoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "archivoAdjuntoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "expedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoModel.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoModel.prototype, "extension", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar' }),
    __metadata("design:type", String)
], ArchivoAdjuntoModel.prototype, "url", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "origenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "destinos", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "procesos", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ArchivoAdjuntoModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => expediente_1.ExpedienteModel, expediente => expediente.archivoAdjuntos),
    (0, typeorm_1.JoinColumn)({ name: 'expedienteId', referencedColumnName: 'expedienteId' }),
    __metadata("design:type", expediente_1.ExpedienteModel)
], ArchivoAdjuntoModel.prototype, "expediente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.archivoAdjuntos),
    (0, typeorm_1.JoinColumn)({ name: 'origenId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ArchivoAdjuntoModel.prototype, "origen", void 0);
exports.ArchivoAdjuntoModel = ArchivoAdjuntoModel = __decorate([
    (0, typeorm_1.Entity)({ schema: 'tramite', name: 'archivo_adjunto' })
], ArchivoAdjuntoModel);
//# sourceMappingURL=archivoAdjunto.js.map