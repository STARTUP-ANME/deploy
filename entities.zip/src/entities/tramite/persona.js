"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonaModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
const tipoPersona_1 = require("../empresa/parametros/tipoPersona");
const usuario_1 = require("../sistema/usuario");
const encargadoUO_1 = require("./encargadoUO");
const expediente_1 = require("./expediente");
let PersonaModel = class PersonaModel extends base_1.BaseModel {
};
exports.PersonaModel = PersonaModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], PersonaModel.prototype, "personaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "nombres", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "apePaterno", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "apeMaterno", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "documento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "direccion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], PersonaModel.prototype, "repLegal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "contrasena", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "servidor", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], PersonaModel.prototype, "puerto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', nullable: true }),
    __metadata("design:type", Boolean)
], PersonaModel.prototype, "ssl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "telefono", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "docRep", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "nombresRep", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "apPatRep", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "apMatRep", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false, nullable: true }),
    __metadata("design:type", Boolean)
], PersonaModel.prototype, "emailConfirmado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], PersonaModel.prototype, "token", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], PersonaModel.prototype, "tokenExpiration", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PersonaModel.prototype, "tipoPersonaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], PersonaModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.personas),
    (0, typeorm_1.JoinColumn)({ name: 'tipoDocumentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], PersonaModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoPersona_1.TipoPersonaModel, tipoPersona => tipoPersona.personas),
    (0, typeorm_1.JoinColumn)({ name: 'tipoPersonaId', referencedColumnName: 'tipoPersonaId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], PersonaModel.prototype, "tipoPersona", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => usuario_1.UsuarioModel, (usuario) => usuario.persona),
    __metadata("design:type", Array)
], PersonaModel.prototype, "usuarios", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => encargadoUO_1.EncargadosUOModel, encargadoUO => encargadoUO.persona),
    __metadata("design:type", Array)
], PersonaModel.prototype, "encargadoUO", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.remitente),
    __metadata("design:type", Array)
], PersonaModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.representante),
    __metadata("design:type", Array)
], PersonaModel.prototype, "expedientesRepresentantes", void 0);
exports.PersonaModel = PersonaModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'personas', schema: 'tramite' })
], PersonaModel);
//# sourceMappingURL=persona.js.map