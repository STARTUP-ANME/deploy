"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpedienteModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const archivoAdjunto_1 = require("./archivoAdjunto");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
const persona_1 = require("./persona");
const estado_1 = require("../empresa/parametros/estado");
const prioridad_1 = require("../empresa/parametros/prioridad");
const sede_1 = require("./sede");
const empresa_1 = require("../empresa/empresa");
const unidadOrganica_1 = require("./unidadOrganica");
const procesoTramite_1 = require("./procesoTramite");
let ExpedienteModel = class ExpedienteModel extends base_1.BaseModel {
};
exports.ExpedienteModel = ExpedienteModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "expedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "empresaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "nroDocumento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "cantidad", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "asunto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "observaciones", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "tipoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], ExpedienteModel.prototype, "fechaLimite", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "prioridadId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "folio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "monto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], ExpedienteModel.prototype, "fechaRegistro", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "remitenteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "tipoExpedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "procedimientoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "estadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "referencia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true })
    //tipo de relacion => manytoone, esta relacionada con la tabla expedientemvp
    ,
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "mpvId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "origenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ExpedienteModel.prototype, "separado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], ExpedienteModel.prototype, "fechaRegularizado", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "correo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteModel.prototype, "uuid", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteModel.prototype, "personaRegistradorId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sede_1.SedeModel, sede => sede.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'sedeId', referencedColumnName: 'sedeId' }),
    __metadata("design:type", sede_1.SedeModel)
], ExpedienteModel.prototype, "sede", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => empresa_1.EmpresaModel, empresa => empresa.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'empresaId', referencedColumnName: 'empresaId' }),
    __metadata("design:type", empresa_1.EmpresaModel)
], ExpedienteModel.prototype, "empresa", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'tipoDocumentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], ExpedienteModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'origenId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], ExpedienteModel.prototype, "origen", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => persona_1.PersonaModel, persona => persona.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'remitenteId', referencedColumnName: 'personaId' }),
    __metadata("design:type", persona_1.PersonaModel)
], ExpedienteModel.prototype, "remitente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => estado_1.EstadoModel, estado => estado.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'estadoId', referencedColumnName: 'estadoId' }),
    __metadata("design:type", estado_1.EstadoModel)
], ExpedienteModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => prioridad_1.PrioridadModel, prioridad => prioridad.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'prioridadId', referencedColumnName: 'prioridadId' }),
    __metadata("design:type", prioridad_1.PrioridadModel)
], ExpedienteModel.prototype, "prioridad", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => archivoAdjunto_1.ArchivoAdjuntoModel, archivoAdjunto => archivoAdjunto.expediente),
    __metadata("design:type", Array)
], ExpedienteModel.prototype, "archivoAdjuntos", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.expediente),
    __metadata("design:type", Array)
], ExpedienteModel.prototype, "procesoTramites", void 0);
exports.ExpedienteModel = ExpedienteModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'expediente', schema: 'tramite' })
], ExpedienteModel);
//# sourceMappingURL=expediente.js.map