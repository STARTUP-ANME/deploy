"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CorrelativoUnidadModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const unidadOrganica_1 = require("./unidadOrganica");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
let CorrelativoUnidadModel = class CorrelativoUnidadModel extends base_1.BaseModel {
};
exports.CorrelativoUnidadModel = CorrelativoUnidadModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "correlativoUnidadId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "unidadOrganicaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "correlativo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], CorrelativoUnidadModel.prototype, "longitud", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], CorrelativoUnidadModel.prototype, "prefijo", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.correlativoUnidad),
    (0, typeorm_1.JoinColumn)({ name: 'tipoDocumentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], CorrelativoUnidadModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.correlativoUnidad),
    (0, typeorm_1.JoinColumn)({ name: 'unidadOrganicaId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], CorrelativoUnidadModel.prototype, "unidadOrganica", void 0);
exports.CorrelativoUnidadModel = CorrelativoUnidadModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'correlativo_unidad', schema: 'tramite' })
], CorrelativoUnidadModel);
//# sourceMappingURL=correlativoUnidad.js.map