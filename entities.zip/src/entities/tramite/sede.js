"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SedeModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const ubigeo_1 = require("../empresa/ubigeo");
const unidadOrganica_1 = require("./unidadOrganica");
const correlativo_1 = require("./correlativo");
const expediente_1 = require("./expediente");
const expedienteMPV_1 = require("./expedienteMPV");
let SedeModel = class SedeModel extends base_1.BaseModel {
};
exports.SedeModel = SedeModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], SedeModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], SedeModel.prototype, "nombre", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], SedeModel.prototype, "direccion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20 }),
    __metadata("design:type", String)
], SedeModel.prototype, "abreviacion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], SedeModel.prototype, "ubigeoId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => ubigeo_1.UbigeoModel, (ubigeo) => ubigeo.sede),
    (0, typeorm_1.JoinColumn)({ name: 'ubigeoId', referencedColumnName: 'ubigeoId' }),
    __metadata("design:type", ubigeo_1.UbigeoModel)
], SedeModel.prototype, "ubigeo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.sede),
    __metadata("design:type", Array)
], SedeModel.prototype, "unidadOrganica", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => correlativo_1.CorrelativoModel, correlativo => correlativo.sede),
    __metadata("design:type", Array)
], SedeModel.prototype, "correlativo", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expediente_1.ExpedienteModel, expediente => expediente.sede),
    __metadata("design:type", Array)
], SedeModel.prototype, "expedientes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => expedienteMPV_1.ExpedienteMPVModel, expedientesMpv => expedientesMpv.sede),
    __metadata("design:type", Array)
], SedeModel.prototype, "expedientesMpv", void 0);
exports.SedeModel = SedeModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'sede', schema: 'tramite' })
], SedeModel);
//# sourceMappingURL=sede.js.map