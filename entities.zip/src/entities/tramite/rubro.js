"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RubroModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const procedimiento_1 = require("./procedimiento");
const requisito_1 = require("./requisito");
const partidaPresupuestal_1 = require("./partidaPresupuestal");
let RubroModel = class RubroModel extends base_1.BaseModel {
};
exports.RubroModel = RubroModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], RubroModel.prototype, "rubroId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], RubroModel.prototype, "procedimientoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], RubroModel.prototype, "partidaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text' }),
    __metadata("design:type", String)
], RubroModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], RubroModel.prototype, "tipo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2 }),
    __metadata("design:type", Number)
], RubroModel.prototype, "monto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean' }),
    __metadata("design:type", Boolean)
], RubroModel.prototype, "obligatorio", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => procedimiento_1.ProcedimientoModel, procedimiento => procedimiento.rubros),
    (0, typeorm_1.JoinColumn)({ name: 'procedimientoId', referencedColumnName: 'procedimientoId' }),
    __metadata("design:type", procedimiento_1.ProcedimientoModel)
], RubroModel.prototype, "procedimiento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => partidaPresupuestal_1.PartidaPresupuestalModel, partida => partida.rubros, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'partidaId', referencedColumnName: 'partidaId' }),
    __metadata("design:type", partidaPresupuestal_1.PartidaPresupuestalModel)
], RubroModel.prototype, "partidaPresupuestal", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => requisito_1.RequisitoModel, requisito => requisito.rubro),
    __metadata("design:type", Array)
], RubroModel.prototype, "requisito", void 0);
exports.RubroModel = RubroModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'rubro', schema: 'tramite' })
], RubroModel);
//# sourceMappingURL=rubro.js.map