"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpedienteVinculadoModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const expediente_1 = require("./expediente");
let ExpedienteVinculadoModel = class ExpedienteVinculadoModel extends base_1.BaseModel {
};
exports.ExpedienteVinculadoModel = ExpedienteVinculadoModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "expedienteVinculadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "vinculoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "expedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "procesoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], ExpedienteVinculadoModel.prototype, "fecha", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "documentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteVinculadoModel.prototype, "documento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteVinculadoModel.prototype, "motivo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], ExpedienteVinculadoModel.prototype, "activo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "referenciaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteVinculadoModel.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => expediente_1.ExpedienteModel, expediente => expediente.expedienteVinculados),
    (0, typeorm_1.JoinColumn)({ name: 'vinculoId', referencedColumnName: 'expedienteId' }),
    __metadata("design:type", expediente_1.ExpedienteModel)
], ExpedienteVinculadoModel.prototype, "expediente", void 0);
exports.ExpedienteVinculadoModel = ExpedienteVinculadoModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'expediente_vinculado', schema: 'tramite' })
], ExpedienteVinculadoModel);
//# sourceMappingURL=expedienteVinculado.js.map