"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EncargadosUOModel = void 0;
const typeorm_1 = require("typeorm");
const base_1 = require("../base");
const persona_1 = require("./persona");
const unidadOrganica_1 = require("./unidadOrganica");
const cargo_1 = require("../empresa/parametros/cargo");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
let EncargadosUOModel = class EncargadosUOModel extends base_1.BaseModel {
};
exports.EncargadosUOModel = EncargadosUOModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], EncargadosUOModel.prototype, "encargadoUOId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz' }),
    __metadata("design:type", Date)
], EncargadosUOModel.prototype, "fechaInicio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', default: null }),
    __metadata("design:type", Date)
], EncargadosUOModel.prototype, "fechaFin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], EncargadosUOModel.prototype, "documento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], EncargadosUOModel.prototype, "unidadOrganicaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], EncargadosUOModel.prototype, "personaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], EncargadosUOModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], EncargadosUOModel.prototype, "cargoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: true }),
    __metadata("design:type", Boolean)
], EncargadosUOModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => cargo_1.CargoModel, cargo => cargo.encargadoUO),
    (0, typeorm_1.JoinColumn)({ name: 'cargoId', referencedColumnName: 'cargoId' }),
    __metadata("design:type", cargo_1.CargoModel)
], EncargadosUOModel.prototype, "cargo", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.encargadoUO),
    (0, typeorm_1.JoinColumn)({ name: 'tipoDocumentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], EncargadosUOModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => persona_1.PersonaModel, persona => persona.encargadoUO),
    (0, typeorm_1.JoinColumn)({ name: 'personaId', referencedColumnName: 'personaId' }),
    __metadata("design:type", persona_1.PersonaModel)
], EncargadosUOModel.prototype, "persona", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => unidadOrganica_1.UnidadOrganicaModel, unidadOrganica => unidadOrganica.encargadoUO),
    (0, typeorm_1.JoinColumn)({ name: 'unidadOrganicaId', referencedColumnName: 'unidadOrganicaId' }),
    __metadata("design:type", unidadOrganica_1.UnidadOrganicaModel)
], EncargadosUOModel.prototype, "unidadOrganica", void 0);
exports.EncargadosUOModel = EncargadosUOModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'encargado_uo', schema: 'tramite' })
], EncargadosUOModel);
//# sourceMappingURL=encargadoUO.js.map