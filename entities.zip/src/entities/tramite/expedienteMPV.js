"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpedienteMPVModel = void 0;
const base_1 = require("../base");
const typeorm_1 = require("typeorm");
const sede_1 = require("./sede");
const tipoExpediente_1 = require("../empresa/parametros/tipoExpediente");
const empresa_1 = require("../empresa/empresa");
const tipoDocumento_1 = require("../empresa/parametros/tipoDocumento");
const usuario_1 = require("../sistema/usuario");
const persona_1 = require("./persona");
const estado_1 = require("../empresa/parametros/estado");
const prioridad_1 = require("../empresa/parametros/prioridad");
const procedimiento_1 = require("./procedimiento");
const procesoTramite_1 = require("./procesoTramite");
const solicitudMPV_1 = require("./solicitudMPV");
const archivoAdjuntoMPV_1 = require("./archivoAdjuntoMPV");
const tipoTramite_1 = require("../empresa/parametros/tipoTramite");
const expediente_1 = require("./expediente");
let ExpedienteMPVModel = class ExpedienteMPVModel extends base_1.BaseModel {
};
exports.ExpedienteMPVModel = ExpedienteMPVModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('increment'),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "expedienteMPVId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "empresaId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "nroDocumento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "cantidad", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "asunto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "observaciones", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "dias", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "tipoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], ExpedienteMPVModel.prototype, "fechaLimite", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "prioridadId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "folio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "monto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], ExpedienteMPVModel.prototype, "fechaRegistro", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "usuarioId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "remitenteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "tipoExpedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "procedimientoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "estadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "origenId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "referencia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "correo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "motivo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ExpedienteMPVModel.prototype, "envioCorreo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "solicitudId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedienteMPVModel.prototype, "personaRegistradorId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedienteMPVModel.prototype, "uuid", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => persona_1.PersonaModel, persona => persona.expedientesRepresentantesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'personaRegistradorId', referencedColumnName: 'personaId' }),
    __metadata("design:type", persona_1.PersonaModel)
], ExpedienteMPVModel.prototype, "representante", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sede_1.SedeModel, sede => sede.expedientesMpv),
    (0, typeorm_1.OneToOne)(() => expediente_1.ExpedienteModel, (expediente) => expediente.mpv),
    __metadata("design:type", expediente_1.ExpedienteModel)
], ExpedienteMPVModel.prototype, "expediente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => sede_1.SedeModel, sede => sede.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'sedeId', referencedColumnName: 'sedeId' }),
    __metadata("design:type", sede_1.SedeModel)
], ExpedienteMPVModel.prototype, "sede", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoExpediente_1.TipoExpedienteModel, tipoExpediente => tipoExpediente.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'tipoExpedienteId', referencedColumnName: 'tipoExpedienteId' }),
    __metadata("design:type", tipoExpediente_1.TipoExpedienteModel)
], ExpedienteMPVModel.prototype, "tipoExpediente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => empresa_1.EmpresaModel, empresa => empresa.expedientesMpv),
    (0, typeorm_1.ManyToOne)(() => tipoTramite_1.TipoTramiteModel, tipoTramite => tipoTramite.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'tipoTramiteId', referencedColumnName: 'tipoTramiteId' }),
    __metadata("design:type", tipoTramite_1.TipoTramiteModel)
], ExpedienteMPVModel.prototype, "tipoTramiteMpv", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => empresa_1.EmpresaModel, empresa => empresa.expedientes),
    (0, typeorm_1.JoinColumn)({ name: 'empresaId', referencedColumnName: 'empresaId' }),
    __metadata("design:type", empresa_1.EmpresaModel)
], ExpedienteMPVModel.prototype, "empresa", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => tipoDocumento_1.TipoDocumentoModel, tipoDocumento => tipoDocumento.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'tipoDocumentoId', referencedColumnName: 'tipoDocumentoId' }),
    __metadata("design:type", tipoDocumento_1.TipoDocumentoModel)
], ExpedienteMPVModel.prototype, "tipoDocumento", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => usuario_1.UsuarioModel, usuario => usuario.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'usuarioId', referencedColumnName: 'usuarioId' }),
    __metadata("design:type", usuario_1.UsuarioModel)
], ExpedienteMPVModel.prototype, "usuario", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => persona_1.PersonaModel, persona => persona.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'remitenteId', referencedColumnName: 'personaId' }),
    __metadata("design:type", persona_1.PersonaModel)
], ExpedienteMPVModel.prototype, "remitente", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => estado_1.EstadoModel, estado => estado.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'estadoId', referencedColumnName: 'estadoId' }),
    __metadata("design:type", estado_1.EstadoModel)
], ExpedienteMPVModel.prototype, "estado", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => prioridad_1.PrioridadModel, prioridad => prioridad.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'prioridadId', referencedColumnName: 'prioridadId' }),
    __metadata("design:type", prioridad_1.PrioridadModel)
], ExpedienteMPVModel.prototype, "prioridad", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => procedimiento_1.ProcedimientoModel, procedimiento => procedimiento.expedientesMpv),
    (0, typeorm_1.JoinColumn)({ name: 'procedimientoId', referencedColumnName: 'procedimientoId' }),
    __metadata("design:type", procedimiento_1.ProcedimientoModel)
], ExpedienteMPVModel.prototype, "procedimiento", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => archivoAdjuntoMPV_1.ArchivoAdjuntoMPVModel, archivoAdjunto => archivoAdjunto.expedienteMpv),
    __metadata("design:type", Array)
], ExpedienteMPVModel.prototype, "archivoAdjuntosMpv", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => procesoTramite_1.ProcesoTramiteModel, procesoTramite => procesoTramite.expedienteMpv),
    __metadata("design:type", Array)
], ExpedienteMPVModel.prototype, "procesoTramites", void 0);
__decorate([
    (0, typeorm_1.OneToOne)(() => solicitudMPV_1.SolicitudMPVModel, solicitudMpv => solicitudMpv.expedienteMpv),
    (0, typeorm_1.JoinColumn)({ name: 'solicitudId', referencedColumnName: 'solicitudId' }),
    __metadata("design:type", solicitudMPV_1.SolicitudMPVModel)
], ExpedienteMPVModel.prototype, "solicitudMpv", void 0);
exports.ExpedienteMPVModel = ExpedienteMPVModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'expediente_mpv', schema: 'tramite' })
], ExpedienteMPVModel);
//# sourceMappingURL=expedienteMPV.js.map