"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpedientesMPVModel = void 0;
const base_1 = require("../base");
const typeorm_1 = require("typeorm");
let ExpedientesMPVModel = class ExpedientesMPVModel extends base_1.BaseModel {
};
exports.ExpedientesMPVModel = ExpedientesMPVModel;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' })
    //tipo de relacion => manytoone, esta relacionada con la tabla sede  
    ,
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "sedeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50 }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "nroDocumento", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "cantidad", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "tipoDocumentoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "asunto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "descripcion", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "observaciones", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' })
    //tipo de relacion => manytoone, esta relacionada con la tabla tipos de tramite
    ,
    (0, typeorm_1.Column)({ type: 'integer' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "tipoTramiteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamptz', nullable: true }),
    __metadata("design:type", Date)
], ExpedientesMPVModel.prototype, "fechaLimite", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' })
    //tipo de relacion => manytoone, esta relacionada con la tabla prioridad
    ,
    (0, typeorm_1.Column)({ type: 'integer' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "prioridadId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "folio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "monto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date' }),
    __metadata("design:type", Date)
], ExpedientesMPVModel.prototype, "fechaRegistro", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "remitenteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "tipoExpedienteId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "procedimientoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "anio", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "referencia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "correo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' })
    //tipo de relacion => manytoone, esta relacionada con la tabla estados
    ,
    (0, typeorm_1.Column)({ type: 'integer' }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "estadoId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ExpedientesMPVModel.prototype, "motivo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'boolean', default: false }),
    __metadata("design:type", Boolean)
], ExpedientesMPVModel.prototype, "envioCorreo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "solicitudId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ExpedientesMPVModel.prototype, "personaRegistradorId", void 0);
exports.ExpedientesMPVModel = ExpedientesMPVModel = __decorate([
    (0, typeorm_1.Entity)({ name: 'expediente_mpv', schema: 'tramite' })
], ExpedientesMPVModel);
//# sourceMappingURL=expedienteMPV.js.map