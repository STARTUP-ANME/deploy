var o={NATURAL:291,JURIDICA:292},t={DNI:301,RUC:302},e={NORMAL:271,URGENTE:272},r={MPV:"/attachments/mpv/"};export{o as a,t as b,e as c,r as d};
