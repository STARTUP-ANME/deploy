var t={apiUrl:"http://104.236.201.180:4004",apiUrlFile:"http://localhost:4000",apiUrlWA:"http://localhost:4000"};export{t as a};
