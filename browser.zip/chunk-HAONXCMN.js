var e={NATURAL:291,JURIDICA:292},t={DNI:301,RUC:302},r={NORMAL:271,URGENTE:272};var o={MPV:"/attachments/mpv/",EXTERNO:"/attachments/external/"};export{e as a,t as b,r as c,o as d};
