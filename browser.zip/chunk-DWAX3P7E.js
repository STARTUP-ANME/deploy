var o={Identificacion:"Identificacion",Contrato:"contrato",Tramite:"tramite",Correlativo:"correlativo"},t={DNI:"dni",RUC:"ruc"};export{o as a,t as b};
