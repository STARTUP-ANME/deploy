var t={apiUrl:"http://104.236.201.180:4004"};export{t as a};
