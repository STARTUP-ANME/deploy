var o={Identificacion:"Identificacion",Contrato:"contrato",Tramite:"tramite",Correlativo:"correlativo"},t={DNI:"dni",RUC:"ruc",COD_MODULAR:"cod_modular"};export{o as a,t as b};
