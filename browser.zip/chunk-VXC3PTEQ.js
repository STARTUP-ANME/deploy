var a={NATURAL:"natural",JURIDICA:"juridica"};export{a};
