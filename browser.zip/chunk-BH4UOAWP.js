var t={apiUrl:"http://104.236.201.180:4004",apiUrlFile:"http://104.236.201.180:5002",apiUrlWA:"http://104.236.201.180:4000"};export{t as a};
