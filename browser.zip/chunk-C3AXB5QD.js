var e={NATURAL:291,JURIDICA:292},r={DNI:301,RUC:302},t={NORMAL:271,URGENTE:272};export{e as a,r as b,t as c};
