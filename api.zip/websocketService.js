"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.websocketService = void 0;
const server_1 = require("./server"); // Asegúrate de que coincida con tu archivo principal
exports.websocketService = {
    notifyUser: (usuarioId, sessions) => {
        server_1.io.to(`user-${usuarioId}`).emit('sessionNotification', sessions); // Envía un evento al usuario
    },
    notifyDeleteSession: (usuarioId, token) => {
        server_1.io.to(`user-${usuarioId}`).emit('deleteSession', token); // Envía un evento al usuario
    },
};
//# sourceMappingURL=websocketService.js.map