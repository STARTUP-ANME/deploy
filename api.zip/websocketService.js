"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.websocketService = void 0;
const server_1 = require("./server"); // Asegúrate de que coincida con tu archivo principal
exports.websocketService = {
    notifyUser: (usuarioId, uuid, sessions) => {
        server_1.io.to(`user-${usuarioId}-${uuid}`).emit('sessionNotification', sessions); // Envía un evento al usuario
    },
    notifyDeleteSession: (usuarioId, uuid, token) => {
        server_1.io.to(`user-${usuarioId}-${uuid}`).emit('deleteSession', token); // Envía un evento al usuario
    },
};
//# sourceMappingURL=websocketService.js.map