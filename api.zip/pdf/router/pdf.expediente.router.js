"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfExpedienteRoute = void 0;
const express_1 = require("express");
const expedientePdf_controller_1 = require("../controller/expediente/expedientePdf.controller");
const tramitePdf_controller_1 = require("../controller/tramite/tramitePdf.controller");
const db_midleware_1 = require("../../core/middleware/db.midleware");
exports.pdfExpedienteRoute = (0, express_1.Router)();
exports.pdfExpedienteRoute.post('/sello', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.selloPdf);
exports.pdfExpedienteRoute.post('/ticket', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.ticketPdf);
exports.pdfExpedienteRoute.post('/recepcionado', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.recepcionadosPdf);
exports.pdfExpedienteRoute.post('/tramite-normal', db_midleware_1.dbMiddleware, tramitePdf_controller_1.tramitePdfController.hojaTramiteNormalPdf);
exports.pdfExpedienteRoute.post('/tramite-advanced', db_midleware_1.dbMiddleware, tramitePdf_controller_1.tramitePdfController.hojaTramiteAvanzadaPdf);
exports.pdfExpedienteRoute.post('/proveido', db_midleware_1.dbMiddleware, tramitePdf_controller_1.tramitePdfController.proveidoPdf);
exports.pdfExpedienteRoute.post('/hoja-tramite', db_midleware_1.dbMiddleware, tramitePdf_controller_1.tramitePdfController.hojaTramitePdf);
exports.pdfExpedienteRoute.post('/top', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.topExpedientesPdf);
exports.pdfExpedienteRoute.post('/for-person', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.forPersonExpedientesPdf);
exports.pdfExpedienteRoute.post('/dashboard', db_midleware_1.dbMiddleware, expedientePdf_controller_1.expedientePdfController.dashboardPdf);
//# sourceMappingURL=pdf.expediente.router.js.map