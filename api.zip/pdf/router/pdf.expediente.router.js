"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfExpedienteRoute = void 0;
const express_1 = require("express");
const expedientePdf_controller_1 = require("../controller/expediente/expedientePdf.controller");
exports.pdfExpedienteRoute = (0, express_1.Router)();
exports.pdfExpedienteRoute.post('/sello', expedientePdf_controller_1.expedientePdfController.selloPdf);
exports.pdfExpedienteRoute.post('/recepcionado', expedientePdf_controller_1.expedientePdfController.recepcionadosPdf);
//# sourceMappingURL=pdf.expediente.router.js.map