"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pdfExpedienteRoute = void 0;
const express_1 = require("express");
const expedientePdf_controller_1 = require("../controller/expediente/expedientePdf.controller");
const tramitePdf_controller_1 = require("../controller/tramite/tramitePdf.controller");
exports.pdfExpedienteRoute = (0, express_1.Router)();
exports.pdfExpedienteRoute.post('/sello', expedientePdf_controller_1.expedientePdfController.selloPdf);
exports.pdfExpedienteRoute.post('/recepcionado', expedientePdf_controller_1.expedientePdfController.recepcionadosPdf);
exports.pdfExpedienteRoute.post('/tramite-normal', tramitePdf_controller_1.tramitePdfController.hojaTramiteNormalPdf);
exports.pdfExpedienteRoute.post('/tramite-advanced', tramitePdf_controller_1.tramitePdfController.hojaTramiteAvanzadaPdf);
//# sourceMappingURL=pdf.expediente.router.js.map