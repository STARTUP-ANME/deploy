"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fonts = void 0;
const path_1 = __importDefault(require("path"));
exports.fonts = {
    FontAwesome: {
        normal: path_1.default.join(__dirname, 'font', 'fontawesome-webfont.ttf'),
    },
    Roboto: {
        normal: path_1.default.join(__dirname, 'font', '/roboto/Roboto-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/roboto/Roboto-Medium.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/roboto/Roboto-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/roboto/Roboto-MediumItalic.ttf'),
    },
    Lato: {
        normal: path_1.default.join(__dirname, 'font', '/lato/Lato-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/lato/Lato-Bold.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/lato/Lato-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/lato/Lato-BoldItalic.ttf'),
    },
    CourierPrime: {
        normal: path_1.default.join(__dirname, 'font', '/courierprime/CourierPrime-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/courierprime/CourierPrime-Bold.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/courierprime/CourierPrime-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/courierprime/CourierPrime-BoldItalic.ttf'),
    },
    SourceCodePro: {
        normal: path_1.default.join(__dirname, 'font', '/sourcecodepro/SourceCodePro-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/sourcecodepro/SourceCodePro-Bold.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/sourcecodepro/SourceCodePro-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/sourcecodepro/SourceCodePro-BoldItalic.ttf'),
    },
    Montserrat: {
        normal: path_1.default.join(__dirname, 'font', '/montserrat/Montserrat-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/montserrat/Montserrat-Bold.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/montserrat/Montserrat-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/montserrat/Montserrat-BoldItalic.ttf'),
    },
    OpenSans: {
        normal: path_1.default.join(__dirname, 'font', '/open-sans/OpenSans-Regular.ttf'),
        bold: path_1.default.join(__dirname, 'font', '/open-sans/OpenSans-Bold.ttf'),
        italics: path_1.default.join(__dirname, 'font', '/open-sans/OpenSans-Italic.ttf'),
        bolditalics: path_1.default.join(__dirname, 'font', '/open-sans/OpenSans-BoldItalic.ttf'),
    }
};
//# sourceMappingURL=font.js.map