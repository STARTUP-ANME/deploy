"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HojaTramiteNormalPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const HojaTramiteNormalPdf = (proceso, empresa) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const body = [
            [
                { text: 'Origen', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Fecha', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Estado', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Fecha atencion', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Documento', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Folios', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' },
                { text: 'Destino', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center' }
            ],
        ];
        proceso.forEach(item => {
            var _a;
            body.push([
                {
                    text: `${item.origen.nombre}`, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: "center"
                },
                {
                    text: item.fRegistro ? `${(0, moment_timezone_1.default)(item.fRegistro).tz("America/Lima").format('DD-MM-yyyy hh:mm a')}` : '', fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: ""
                },
                {
                    text: `${item.estado.descripcion}`, fontSize: 9, fillColor: '',
                    bold: false,
                    alignment: "",
                    color: '',
                },
                {
                    text: item.fAtencion ? `${(0, moment_timezone_1.default)(item.fAtencion).tz("America/Lima").format('DD-MM-yyyy hh:mm a')}` : '', fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: ""
                },
                {
                    text: `${item.documento}`, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: ""
                },
                {
                    text: item.expediente.folio.toString(), fontSize: 9, fillColor: '',
                    bold: false,
                    alignment: "",
                    color: '',
                },
                {
                    text: (_a = item.destino) === null || _a === void 0 ? void 0 : _a.nombre, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: ""
                },
            ]);
        });
        const content = [
            {
                table: {
                    widths: ['50%', '50%'],
                    body: [
                        [
                            {
                                text: 'Fecha y hora:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: proceso[0].fRegistro ? `${(0, moment_timezone_1.default)(proceso[0].fRegistro).tz("America/Lima").format('DD-MM-yyyy hh:mm a')}` : '',
                                bold: true,
                                fontSize: 9,
                            },
                        ],
                        [
                            {
                                text: 'Razon social / Nombres:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: `${proceso[0].usuarioRecibe.persona.nombres} ${proceso[0].usuarioRecibe.persona.apePaterno} ${proceso[0].usuarioRecibe.persona.apeMaterno}`,
                                bold: true,
                                fontSize: 9,
                            },
                        ],
                        [
                            {
                                text: 'Asunto:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: proceso[0].expediente.asunto,
                                bold: true,
                                fontSize: 9,
                            }
                        ]
                    ],
                },
                layout: 'noBorders'
            },
            {
                table: {
                    headerRows: 1,
                    widths: ['20%', '10%', '10%', '10%', '20%', '10%', '20%'],
                    body: body,
                }
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.HojaTramiteNormalPdf = HojaTramiteNormalPdf;
//# sourceMappingURL=content.js.map