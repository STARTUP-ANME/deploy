"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatorExpedientePdf = void 0;
const pdfmake_1 = __importDefault(require("pdfmake"));
const font_1 = require("../font");
const log_helper_1 = require("../../../core/helpers/log.helper");
const docdefinition_1 = require("./hojaTramiteAdvanced/docdefinition");
const docdefinition_2 = require("./hojaTramiteNormal/docdefinition");
const docdefinition_3 = require("./proveido/docdefinition");
const docdefinition_4 = require("./hojaTramite/docdefinition");
class GeneratorExpedientePdf {
    constructor() {
        /**
         * Generacion de reporte de servicio por rango de fechas
         */
        this.generateHojaTramiteNormalPdf = (expedienteId, dataSource) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_2.docHojaTramiteNormalDefinition)(expedienteId, dataSource);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.info(`generateServicePdf for : ${error.message}`);
            }
        });
        /**
         * Generacion de reporte de servicio por rango de fechas
         */
        this.generateHojaTramiteAvanzadaPdf = (expedienteId, dataSource) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_1.docHojaTramiteAdvancedDefinition)(expedienteId, dataSource);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.info(`generateServicePdf for : ${error.message}`);
            }
        });
        this.generateProveidoPdf = (procesoTramiteId, dataSource) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_3.docProveidoDefinition)(procesoTramiteId, dataSource);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.info(`generateServicePdf for : ${error.message}`);
            }
        });
        this.generateHojaTramitePdf = (expedienteId, dataSource) => __awaiter(this, void 0, void 0, function* () {
            try {
                const printer = new pdfmake_1.default(font_1.fonts);
                const doc = yield (0, docdefinition_4.docHojaTramiteDefinition)(expedienteId, dataSource);
                const pdfDoc = printer.createPdfKitDocument(doc);
                return new Promise((resolve, reject) => {
                    try {
                        const chunks = [];
                        pdfDoc.on('data', (chunk) => chunks.push(chunk));
                        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
                        pdfDoc.end();
                    }
                    catch (err) {
                        reject(err);
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.info(`generateServicePdf for : ${error.message}`);
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new GeneratorExpedientePdf();
        return this.instance;
    }
}
exports.generatorExpedientePdf = GeneratorExpedientePdf.getInstance();
//# sourceMappingURL=genTramitePdf.js.map