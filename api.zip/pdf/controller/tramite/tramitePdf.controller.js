"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tramitePdfController = void 0;
const http_status_codes_1 = require("http-status-codes");
const genTramitePdf_1 = require("./genTramitePdf");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class TramitePdfController {
    constructor() {
        this.hojaTramiteNormalPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.body;
                if (expedienteId) {
                    const binaryResult = yield genTramitePdf_1.generatorExpedientePdf.generateHojaTramiteNormalPdf(expedienteId, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=sello.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.hojaTramiteAvanzadaPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.body;
                if (expedienteId) {
                    const binaryResult = yield genTramitePdf_1.generatorExpedientePdf.generateHojaTramiteAvanzadaPdf(expedienteId, dataSource);
                    const currentDate = (0, moment_timezone_1.default)().tz("America/Lima").format("DD_MM_YYYY");
                    res.setHeader('Content-disposition', `attachment; filename=Conformidad_Recepcion${currentDate}.pdf`);
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.proveidoPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramiteId } = req.body;
                if (procesoTramiteId) {
                    const binaryResult = yield genTramitePdf_1.generatorExpedientePdf.generateProveidoPdf(procesoTramiteId, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=sello.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.hojaTramitePdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.body;
                if (expedienteId) {
                    const binaryResult = yield genTramitePdf_1.generatorExpedientePdf.generateHojaTramitePdf(expedienteId, dataSource);
                    const currentDate = (0, moment_timezone_1.default)().tz("America/Lima").format("DD_MM_YYYY");
                    res.setHeader('Content-disposition', `attachment; filename=Conformidad_Recepcion${currentDate}.pdf`);
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new TramitePdfController();
        return this.instance;
    }
}
exports.tramitePdfController = TramitePdfController.getInstance();
//# sourceMappingURL=tramitePdf.controller.js.map