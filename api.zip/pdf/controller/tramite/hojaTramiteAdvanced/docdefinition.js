"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docHojaTramiteAdvancedDefinition = void 0;
const style_1 = require("./style");
const empresa_service_1 = require("../../../../empresa/empresa/service/empresa.service");
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const moment_1 = __importDefault(require("moment"));
const procesoTramite_service_1 = require("../../../../tramite/procesoTramite/service/procesoTramite.service");
const content_1 = require("./content");
const docHojaTramiteAdvancedDefinition = (expedienteId, dataSource) => __awaiter(void 0, void 0, void 0, function* () {
    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
    const procesoTramite = yield procesoTramite_service_1.procesoTramiteService.findProcesoTramite(expedienteId, dataSource);
    const content = yield (0, content_1.HojaTramiteAdvancedPdf)(procesoTramite, empresa);
    const download = yield (0, downloadLogo_utils_1.downloadImage)(empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    const currentDate = (0, moment_1.default)().tz("America/Lima");
    const createColumnItems = (items) => {
        return items.map(item => ({
            columns: [
                { text: item, fontSize: 9, margin: [5, 0, 0, 0] },
                { text: '\uf096', font: 'FontAwesome', fontSize: 18, margin: [0, 0, 0, 0] }
            ],
            columnGap: 5,
            margin: [0, 2, 0, 2]
        }));
    };
    const data = {
        pageSize: 'A4',
        pageMargins: [40, 120, 40, 60],
        header: {
            columns: [
                {
                    stack: [
                        {
                            image: 'data:image/jpg;base64,' + imageString,
                            width: 50, // Asegura que la imagen no sea muy grande
                            alignment: 'center',
                            margin: [0, 0, 0, 10] // Agrega un margen debajo de la imagen
                        },
                        {
                            text: empresa.nombre,
                            alignment: 'center',
                            bold: true,
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                        {
                            text: 'RUC: ' + empresa.ruc,
                            alignment: 'center',
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                        {
                            text: 'Dir: ' + empresa.direccion,
                            alignment: 'center',
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                    ],
                    width: 'auto',
                    alignment: 'center',
                    margin: [40, 5, 20, 0]
                },
                {
                    stack: [
                        {
                            text: 'HOJA DE TRAMITE ',
                            alignment: 'center',
                            fontSize: 14,
                            bold: true,
                        },
                        {
                            text: `EXPEDIENTE N° ${procesoTramite[0].expediente.nroDocumento} - ${(0, moment_1.default)().year()}`,
                            alignment: 'center',
                            fontSize: 14,
                            bold: true,
                        }
                    ],
                    margin: [20, 40, 20, 0]
                },
                {
                    stack: [
                        {
                            qr: `${procesoTramite[0].expediente.nroDocumento} - ${(0, moment_1.default)().year()}`,
                            fit: 100,
                            alignment: 'center',
                        },
                        {
                            text: `${procesoTramite[0].expediente.nroDocumento} - ${(0, moment_1.default)().year()}`,
                            alignment: 'center',
                            fontSize: 9,
                            bold: true,
                        }
                    ],
                    margin: [0, 20, 0, 0]
                }
            ]
        },
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        footer: function (currentPage, pageCount) {
            const column1 = createColumnItems(['1. Decidir', '2. Inspeccionar', '3. Inspeccionar', '4. Remitir antecedentes']);
            const column2 = createColumnItems(['5. Entrevista', '6. Proyectar resolucion', '7. Transcribir', '8. Coordinar accion']);
            const column3 = createColumnItems(['9. Preparar respuesta', '10. Archivar', '11. Atender', '12. Sesion de consejo']);
            return {
                stack: [
                    {
                        columns: [
                            { stack: column1, width: '33.33%', alignment: 'left' },
                            { stack: column2, width: '33.33%', alignment: 'left' },
                            { stack: column3, width: '33.33%', alignment: 'left' }
                        ]
                    },
                ],
                margin: [40, -40, 0, 0]
            };
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docHojaTramiteAdvancedDefinition = docHojaTramiteAdvancedDefinition;
//# sourceMappingURL=docdefinition.js.map