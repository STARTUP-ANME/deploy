"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HojaTramiteAdvancedPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const HojaTramiteAdvancedPdf = (proceso, empresa) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const body = [
            [
                { text: 'Pasa a ', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center', margin: [0, 0, 0, 0] },
                { text: 'Fecha', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center', margin: [0, 0, 0, 0] },
                { text: 'Indicacion', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center', margin: [0, 0, 0, 0] },
                { text: 'Folios', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center', margin: [0, 0, 0, 0] },
                { text: 'Remitido por', bold: true, fontSize: 9, color: '#ffffff', fillColor: '#9b9b9b', alignment: 'center', margin: [0, 0, 0, 0] }
            ],
        ];
        proceso.forEach(item => {
            body.push([
                {
                    text: `${item.origen.nombre}`, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: "center",
                    margin: [0, 0, 0, 0]
                },
                {
                    text: `${(0, moment_timezone_1.default)(item.fRegistro).tz("America/Lima").format('DD-MM-yyyy hh:mm a')}`, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: "",
                    margin: [0, 0, 0, 0]
                },
                {
                    text: `${item.asunto}`, fontSize: 9, fillColor: '',
                    bold: false,
                    alignment: "",
                    color: '',
                    margin: [0, 0, 0, 0]
                },
                {
                    text: item.expediente.folio.toString(), fontSize: 9, fillColor: '',
                    bold: false,
                    alignment: "",
                    color: '',
                    margin: [0, 0, 0, 0]
                },
                {
                    text: `${item.usuarioCrea.persona.nombres} ${item.usuarioCrea.persona.apePaterno} ${item.usuarioCrea.persona.apeMaterno}`, fontSize: 9,
                    bold: false,
                    fillColor: "",
                    color: '',
                    alignment: "",
                    margin: [0, 0, 0, 0]
                },
            ]);
        });
        const minRows = 10;
        while (body.length < minRows + 1) { // +1 para incluir el encabezado
            body.push([
                { text: '', fontSize: 9, bold: false, fillColor: "", color: '', alignment: "center", margin: [15, 12, 15, 12] },
                { text: '', fontSize: 9, bold: false, fillColor: "", color: '', alignment: "center", margin: [15, 12, 15, 12] },
                { text: '', fontSize: 9, bold: false, fillColor: "", color: '', alignment: "center", margin: [15, 12, 15, 12] },
                { text: '', fontSize: 9, bold: false, fillColor: "", color: '', alignment: "center", margin: [15, 12, 15, 12] },
                { text: '', fontSize: 9, bold: false, fillColor: "", color: '', alignment: "center", margin: [15, 12, 15, 12] },
            ]);
        }
        const content = [
            {
                table: {
                    widths: ['50%', '50%'],
                    body: [
                        [
                            {
                                text: 'Fecha y hora:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: proceso[0].fRegistro ? `${(0, moment_timezone_1.default)(proceso[0].fRegistro).tz("America/Lima").format('DD-MM-yyyy hh:mm a')}` : '',
                                bold: true,
                                fontSize: 9,
                            },
                        ],
                        [
                            {
                                text: 'Razon social / Nombres:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: `${proceso[0].expediente.remitente.nombres} ${proceso[0].expediente.remitente.apePaterno} ${proceso[0].expediente.remitente.apeMaterno}`,
                                bold: true,
                                fontSize: 9,
                            },
                        ],
                        [
                            {
                                text: 'Asunto:',
                                bold: true,
                                fontSize: 9,
                            },
                            {
                                text: proceso[0].expediente.asunto,
                                bold: true,
                                fontSize: 9,
                            }
                        ]
                    ],
                },
                layout: 'noBorders'
            },
            {
                table: {
                    headerRows: 1,
                    widths: ['20%', '20%', '20%', '20%', '20%'],
                    body: body,
                }
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.HojaTramiteAdvancedPdf = HojaTramiteAdvancedPdf;
//# sourceMappingURL=content.js.map