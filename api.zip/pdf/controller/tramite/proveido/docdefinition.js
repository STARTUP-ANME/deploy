"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docProveidoDefinition = void 0;
const style_1 = require("./style");
const content_1 = require("./content");
const procesoTramite_service_1 = require("../../../../tramite/procesoTramite/service/procesoTramite.service");
const docProveidoDefinition = (procesoTramiteId, dataSource) => __awaiter(void 0, void 0, void 0, function* () {
    const procesoTramite = yield procesoTramite_service_1.procesoTramiteService.findOneProcesoTramite(procesoTramiteId, dataSource);
    const content = yield (0, content_1.ProveidoPdf)(procesoTramite);
    const data = {
        pageSize: {
            width: 356, // 170.1 * 2 + 14.17 puntos (dos cuadros de 6 cm más un margen de 0.5 cm)
            height: 'auto' // Mantener 4 cm de alto por cada cuadro
        },
        pageMargins: [
            1, 1, 1, 1
        ],
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docProveidoDefinition = docProveidoDefinition;
//# sourceMappingURL=docdefinition.js.map