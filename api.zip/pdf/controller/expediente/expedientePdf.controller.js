"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedientePdfController = void 0;
const http_status_codes_1 = require("http-status-codes");
const genExpedientePdf_1 = require("./genExpedientePdf");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class ExpedientePdfController {
    constructor() {
        this.selloPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.body;
                if (expedienteId) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateSelloPdf(expedienteId, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=sello.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.recepcionadosPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { filter } = req.body;
                if (filter) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateRecepcionadosPdf(filter, dataSource);
                    const currentDate = (0, moment_timezone_1.default)(filter.fechaInicio).tz("America/Lima").format("DD_MM_YYYY");
                    res.setHeader('Content-disposition', `attachment; filename=Conformidad_Recepcion${currentDate}.pdf`);
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.ticketPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.body;
                if (expedienteId) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateTicketPdf(expedienteId, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=ticket.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.topExpedientesPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const topExpedienteFilterDto = req.body;
                if (topExpedienteFilterDto) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateTopExpedientesPdf(topExpedienteFilterDto, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=ticket.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.forPersonExpedientesPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { remitenteIds } = req.body;
                if (remitenteIds.length > 0) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateForPersonExpedientesPdf(remitenteIds, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=ticket.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
        this.dashboardPdf = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { unidadOrganicaId, from } = req.body;
                if (unidadOrganicaId > 0) {
                    const binaryResult = yield genExpedientePdf_1.generatorExpedientePdf.generateDashboardPdf(unidadOrganicaId, from, dataSource);
                    res.setHeader('Content-disposition', 'attachment; filename=ticket.pdf');
                    res.type('pdf').send(binaryResult);
                }
            }
            catch (error) {
                res.send(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: error });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ExpedientePdfController();
        return this.instance;
    }
}
exports.expedientePdfController = ExpedientePdfController.getInstance();
//# sourceMappingURL=expedientePdf.controller.js.map