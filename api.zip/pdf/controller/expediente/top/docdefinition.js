"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docTopDefinition = void 0;
const expediente_service_1 = require("../../../../tramite/expediente/service/expediente.service");
const style_1 = require("./style");
const empresa_service_1 = require("../../../../empresa/empresa/service/empresa.service");
const content_1 = require("./content");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const docTopDefinition = (topExpedienteFilterDto, dataSource) => __awaiter(void 0, void 0, void 0, function* () {
    const top = yield expediente_service_1.expedienteService.findTopExpediente(topExpedienteFilterDto, dataSource);
    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
    const content = yield (0, content_1.TopContent)(empresa, top);
    const download = yield (0, downloadLogo_utils_1.downloadImage)(empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    const data = {
        pageSize: 'A4',
        pageMargins: [10, 70, 10, 10],
        header: [
            {
                table: {
                    widths: ['30%', '70%'],
                    body: [
                        [
                            {
                                fillColor: '#4B4D85',
                                stack: [
                                    {
                                        image: 'data:image/jpg;base64,' + imageString,
                                        alignment: 'center',
                                        width: 30,
                                    },
                                    {
                                        text: empresa.nombre,
                                        bold: true,
                                        fontSize: 8,
                                        alignment: 'center',
                                        color: '#FFFFFF'
                                    }
                                ],
                                border: [false, false, false, false]
                            },
                            {
                                stack: [
                                    {
                                        text: `TOP ${top.length} EXPEDIENTES`,
                                        bold: true,
                                        color: '#FFFFFF',
                                        alignment: 'center',
                                        font: 'Montserrat',
                                        fontSize: 18
                                    },
                                    {
                                        text: `Fecha de emision: ${(0, moment_timezone_1.default)().format("DD-MM-YYYY")}`,
                                        bold: true,
                                        color: '#FFFFFF',
                                        alignment: 'center',
                                        fontSize: 10
                                    }
                                ],
                                fillColor: '#4B4D85',
                                margin: [0, 20, 0, 0],
                                border: [false, false, false, false]
                            }
                        ]
                    ]
                },
                layout: 'noBorders'
            }
        ],
        info: {
            title: 'TOP EXPEDIENTES',
            author: 'ANGEL',
            subject: 'TOP EXPEDIENTES',
            keywords: 'TOP',
        },
        content: content,
        defaultStyle: {
            font: 'Montserrat'
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docTopDefinition = docTopDefinition;
//# sourceMappingURL=docdefinition.js.map