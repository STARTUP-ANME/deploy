"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TopContent = void 0;
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const log_helper_1 = require("../../../../core/helpers/log.helper");
const TopContent = (empresa, topExpedientes) => __awaiter(void 0, void 0, void 0, function* () {
    const download = yield (0, downloadLogo_utils_1.downloadImage)(empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    try {
        const rows = topExpedientes.map((p, i) => {
            const cant = i + 1;
            return [
                { text: cant, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: p.tipoDocumento, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: p.documento, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: p.nombres, fontSize: 8, font: 'OpenSans', margin: [0, 2, 0, 2] },
                { text: p.total.toString(), alignment: 'right', fontSize: 8, margin: [0, 2, 0, 2] }
            ];
        });
        const content = [
            {
                table: {
                    headerRows: 1,
                    widths: ['5%', '10%', '20%', '55%', '10%'],
                    body: [
                        [
                            { text: 'N°', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'T. Doc.', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Documento', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Nombres', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Cant', bold: true, font: 'OpenSans', fontSize: 9 }
                        ],
                        ...rows
                    ]
                },
                layout: 'lightHorizontalLines'
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.TopContent = TopContent;
//# sourceMappingURL=content.js.map