"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForPersonContent = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const ForPersonContent = (expedientes) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    try {
        const rows = [];
        for (const [remitenteKey, lista] of Object.entries(expedientes)) {
            rows.push([
                {
                    fillColor: '#4B4D85',
                    color: '#FFFFFF',
                    text: remitenteKey,
                    colSpan: 6,
                    font: 'OpenSans',
                    fontSize: 9,
                    bold: true,
                    margin: [0, 1, 0, 1],
                    alignment: 'left',
                },
                {}, {}, {}, {}, {}
            ]);
            let contador = 1;
            for (const expediente of lista) {
                rows.push([
                    { text: contador.toString(), font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                    { text: `${expediente.nroDocumento}\n${(0, moment_timezone_1.default)(expediente.fechaRegistro).format("DD-MM-YYYY")}`, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                    { text: (_b = (_a = expediente.tipoDocumento) === null || _a === void 0 ? void 0 : _a.descripcion) !== null && _b !== void 0 ? _b : '', font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                    { text: expediente.descripcion, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                    { text: expediente.asunto.toString(), font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2], alignment: 'left' },
                    { text: expediente.folio, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2], alignment: 'center' }
                ]);
                contador++;
            }
        }
        const content = [
            {
                table: {
                    headerRows: 1,
                    widths: ['5%', '10%', '15%', '25%', '40%', '5%'],
                    body: [
                        [
                            { text: 'N°', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'N° Expe.', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Documento', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Descripcion', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Asunto', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Folios', bold: true, font: 'OpenSans', fontSize: 9 }
                        ],
                        ...rows
                    ]
                },
                layout: 'lightHorizontalLines'
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.ForPersonContent = ForPersonContent;
//# sourceMappingURL=content.js.map