"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardContent = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const pdf_expediente_enum_1 = require("../enum/pdf-expediente.enum");
const DashboardContent = (procesoTramites, from) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u;
    try {
        const rows = [];
        for (const proceso of procesoTramites) {
            let unidadOrganica = '';
            switch (from) {
                case pdf_expediente_enum_1.DashboardFrom.Recepcionados:
                case pdf_expediente_enum_1.DashboardFrom.PorRecibir:
                case pdf_expediente_enum_1.DashboardFrom.Copias:
                    unidadOrganica = (_a = proceso === null || proceso === void 0 ? void 0 : proceso.origen) === null || _a === void 0 ? void 0 : _a.nombre;
                    break;
                case pdf_expediente_enum_1.DashboardFrom.Atendidos:
                    unidadOrganica = (_b = proceso === null || proceso === void 0 ? void 0 : proceso.destino) === null || _b === void 0 ? void 0 : _b.nombre;
                    break;
            }
            rows.push([
                {
                    text: `${(_d = (_c = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _c === void 0 ? void 0 : _c.nroDocumento) !== null && _d !== void 0 ? _d : 'Sin documento'}\n${((_e = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _e === void 0 ? void 0 : _e.fechaRegistro)
                        ? (0, moment_timezone_1.default)(proceso.expediente.fechaRegistro).tz("America/Lima").format("DD-MM-YYYY")
                        : 'Sin fecha'}`, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2]
                },
                { text: (_h = (_g = (_f = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _f === void 0 ? void 0 : _f.tipoDocumento) === null || _g === void 0 ? void 0 : _g.descripcion) !== null && _h !== void 0 ? _h : '', font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: (_j = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _j === void 0 ? void 0 : _j.descripcion, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: `${(_l = (_k = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _k === void 0 ? void 0 : _k.remitente) === null || _l === void 0 ? void 0 : _l.nombres} ${(_p = (_o = (_m = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _m === void 0 ? void 0 : _m.remitente) === null || _o === void 0 ? void 0 : _o.apePaterno) !== null && _p !== void 0 ? _p : ''} ${(_s = (_r = (_q = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _q === void 0 ? void 0 : _q.remitente) === null || _r === void 0 ? void 0 : _r.apeMaterno) !== null && _s !== void 0 ? _s : ''}`, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2] },
                { text: (_t = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _t === void 0 ? void 0 : _t.asunto.toString(), font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2], alignment: 'left' },
                { text: (_u = proceso === null || proceso === void 0 ? void 0 : proceso.expediente) === null || _u === void 0 ? void 0 : _u.folio, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2], alignment: 'center' },
                { text: unidadOrganica, font: 'OpenSans', fontSize: 8, margin: [0, 2, 0, 2], alignment: 'left' }
            ]);
        }
        let unidadOrganica = '';
        switch (from) {
            case pdf_expediente_enum_1.DashboardFrom.Recepcionados:
            case pdf_expediente_enum_1.DashboardFrom.PorRecibir:
            case pdf_expediente_enum_1.DashboardFrom.Copias:
                unidadOrganica = 'Origen';
                break;
            case pdf_expediente_enum_1.DashboardFrom.Atendidos:
                unidadOrganica = 'Destino';
                break;
        }
        const content = [
            {
                table: {
                    headerRows: 1,
                    widths: ['10%', '10%', '10%', '20%', '25%', '7%', '18%'],
                    body: [
                        [
                            { text: 'N° Expe.', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Documento', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Descripcion', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Razon Social/Nombres', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Asunto', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: 'Folios', bold: true, font: 'OpenSans', fontSize: 9 },
                            { text: unidadOrganica, bold: true, font: 'OpenSans', fontSize: 9 }
                        ],
                        ...rows
                    ]
                },
                layout: 'lightHorizontalLines'
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.DashboardContent = DashboardContent;
//# sourceMappingURL=content.js.map