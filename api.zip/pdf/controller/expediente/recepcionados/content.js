"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecepcionadoPdf = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const RecepcionadoPdf = (proceso, empresa) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const body = [
            [
                { text: 'N° Expediente', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Folio', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Razón Social / Nombres', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Asunto', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Disposición de Alcaldía', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Área Destino', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' },
                { text: 'Firma', bold: true, fontSize: 9, fillColor: '#dedede', alignment: 'center' }
            ],
        ];
        proceso.forEach(item => {
            var _a, _b, _c, _d, _e, _f, _g, _h;
            body.push([
                {
                    text: `${item.expediente.nroDocumento} - ${item.expediente.anio} \n ${(0, moment_timezone_1.default)(item.fRegistro).tz('America/lima').format("DD-MM-YYYY hh:mm a")}`, fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: "center"
                },
                {
                    text: item.expediente.folio.toString(), fontSize: 6, fillColor: '',
                    bold: false,
                    alignment: ""
                },
                {
                    text: `${(_b = (_a = item.expediente) === null || _a === void 0 ? void 0 : _a.remitente) === null || _b === void 0 ? void 0 : _b.nombres} ${(_d = (_c = item.expediente) === null || _c === void 0 ? void 0 : _c.remitente) === null || _d === void 0 ? void 0 : _d.apePaterno} ${(_f = (_e = item.expediente) === null || _e === void 0 ? void 0 : _e.remitente) === null || _f === void 0 ? void 0 : _f.apeMaterno}`, fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: ""
                },
                {
                    text: (_g = item.expediente) === null || _g === void 0 ? void 0 : _g.asunto, fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: ""
                },
                {
                    text: '', fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: ""
                },
                {
                    text: `${(_h = item.destino) === null || _h === void 0 ? void 0 : _h.nombre} \n ${(0, moment_timezone_1.default)(item.fRegistro).tz("America/Lima").format("DD-MM-YYYY hh:mm a")}`, fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: "center"
                },
                {
                    text: '', fontSize: 6,
                    bold: false,
                    fillColor: "",
                    alignment: ""
                }
            ]);
        });
        const content = [
            {
                table: {
                    headerRows: 1,
                    widths: ['auto', 'auto', '*', '*', 'auto', '*', 'auto'],
                    body: body,
                }
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.RecepcionadoPdf = RecepcionadoPdf;
//# sourceMappingURL=content.js.map