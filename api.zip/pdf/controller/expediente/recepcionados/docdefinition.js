"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docRecepcionadoDefinition = void 0;
const content_1 = require("./content");
const style_1 = require("./style");
const empresa_service_1 = require("../../../../empresa/empresa/service/empresa.service");
const enum_1 = require("../../../../core/enum");
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const moment_1 = __importDefault(require("moment"));
const procesoTramite_service_1 = require("../../../../tramite/procesoTramite/service/procesoTramite.service");
const docRecepcionadoDefinition = (filter, dataSource) => __awaiter(void 0, void 0, void 0, function* () {
    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
    const procesoTramite = yield procesoTramite_service_1.procesoTramiteService.findSatateProcesoTramite(enum_1.EstadosTramite.Enviado, filter.fechaInicio, dataSource);
    const content = yield (0, content_1.RecepcionadoPdf)(procesoTramite, empresa);
    const download = yield (0, downloadLogo_utils_1.downloadImage)(empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    const currentDate = (0, moment_1.default)().tz("America/Lima");
    const data = {
        pageSize: 'A4',
        pageOrientation: 'landscape',
        pageMargins: [40, 120, 40, 60],
        header: {
            columns: [
                {
                    stack: [
                        {
                            image: 'data:image/jpg;base64,' + imageString,
                            width: 50, // Asegura que la imagen no sea muy grande
                            alignment: 'center',
                            margin: [0, 0, 0, 10] // Agrega un margen debajo de la imagen
                        },
                        {
                            text: empresa.nombre,
                            alignment: 'center',
                            bold: true,
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                        {
                            text: 'RUC: ' + empresa.ruc,
                            alignment: 'center',
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                        {
                            text: 'Dir: ' + empresa.direccion,
                            alignment: 'center',
                            fontSize: 10,
                            margin: [0, 0, 0, 0]
                        },
                    ],
                    width: 'auto',
                    alignment: 'center',
                    margin: [40, 5, 20, 0]
                },
                {
                    text: 'RELACIÓN DE EXPEDIENTES RECEPCIONADOS ' + (0, moment_1.default)(filter.fechaInicio).format('DD-MM-YYYY'),
                    alignment: 'center',
                    fontSize: 14,
                    bold: true,
                    margin: [20, 60, 20, 0]
                }
            ]
        },
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        footer: function (currentPage, pageCount) {
            return {
                text: 'Fecha de impresión : ' + currentDate.format("DD/MM/YYYY hh:mm a"),
                alignment: 'right',
                fontSize: 8,
                margin: [0, 0, 40, 20]
            };
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docRecepcionadoDefinition = docRecepcionadoDefinition;
//# sourceMappingURL=docdefinition.js.map