"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.styles = void 0;
exports.styles = {
    header: {
        fontSize: 18,
        bold: true,
    },
    subheader: {
        fontSize: 15,
        bold: true,
    },
    normal: {
        fontSize: 10,
    },
};
//# sourceMappingURL=index.js.map