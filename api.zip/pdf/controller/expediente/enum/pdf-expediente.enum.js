"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardFrom = void 0;
var DashboardFrom;
(function (DashboardFrom) {
    DashboardFrom["PorRecibir"] = "por_recibir";
    DashboardFrom["Recepcionados"] = "recepcionados";
    DashboardFrom["Copias"] = "copias";
    DashboardFrom["Atendidos"] = "atendidos";
})(DashboardFrom || (exports.DashboardFrom = DashboardFrom = {}));
//# sourceMappingURL=pdf-expediente.enum.js.map