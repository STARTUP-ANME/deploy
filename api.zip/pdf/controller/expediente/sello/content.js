"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SelloPdf = void 0;
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const SelloPdf = (expediente) => __awaiter(void 0, void 0, void 0, function* () {
    const download = yield (0, downloadLogo_utils_1.downloadImage)(expediente.empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    try {
        // const content: Content[] = [
        //     {
        //         columns: [
        //             {
        //                 image: 'data:image/jpg;base64,' + imageString, // Coloca aquí el logo en formato base64
        //                 width: 50,
        //             },
        //             [
        //                 { text: 'GERENCIA MUNICIPAL', alignment: 'center', fontSize: 12, bold: true },
        //                 { text: 'MUNICIPALIDAD DISTRITAL DE SAN JOSE DE LOS MOLINOS', alignment: 'center', fontSize: 8 },
        //                 { text: 'RUC: 20198806481', alignment: 'center', fontSize: 8 },
        //             ],
        //         ],
        //     },
        //     {
        //         text: 'DOCUMENTO RECIBIDO',
        //         fontSize: 14,
        //         alignment: 'center',
        //         margin: [0, 10, 0, 10],
        //         bold: true,
        //     },
        //     {
        //         columns: [
        //             { text: 'Fecha:', width: 'auto', bold: true },
        //             { text: '17/10/2024 08:00 a.m.', width: 'auto' },
        //             { text: 'Folio:', width: 'auto', bold: true, margin: [20, 0, 0, 0] },
        //             { text: '3333', width: 'auto' },
        //         ],
        //         margin: [0, 0, 0, 10],
        //     },
        //     {
        //         columns: [
        //             { text: 'Asunto:', width: 'auto', bold: true },
        //             { text: 'EE', width: 'auto' },
        //         ],
        //         margin: [0, 0, 0, 10],
        //     },
        //     {
        //         columns: [
        //             { text: 'Recibido Por:', width: 'auto', bold: true },
        //             { text: 'Administrador', width: 'auto' },
        //         ],
        //         margin: [0, 0, 0, 10],
        //     },
        //     {
        //         text: 'TD02828 - 2024',
        //         alignment: 'center',
        //         fontSize: 10,
        //         bold: true,
        //         margin: [0, 10, 0, 0],
        //     },
        //     {
        //         image: 'data:image/jpg;base64,' + imageString,
        //         width: 100,
        //         alignment: 'center',
        //         margin: [0, 10, 0, 0],
        //     }
        // ]
        const content = [
            {
                columns: [
                    {
                        width: '50%',
                        stack: [
                            {
                                table: {
                                    widths: ['30%', '70%'],
                                    body: [
                                        [
                                            {
                                                stack: [
                                                    {
                                                        image: 'data:image/jpg;base64,' + imageString,
                                                        alignment: 'center',
                                                        width: 25,
                                                    },
                                                    {
                                                        text: expediente.empresa.nombre,
                                                        alignment: 'center',
                                                        fontSize: 5,
                                                        bold: true,
                                                        noWrap: false,
                                                        margin: [0, 5, 0, 0]
                                                    },
                                                ],
                                                border: [true, true, false, false] // Borde en la parte superior e izquierda
                                            },
                                            {
                                                stack: [
                                                    {
                                                        text: expediente.origen.nombre,
                                                        alignment: 'center',
                                                        bold: true,
                                                        fontSize: 6,
                                                        margin: [0, 5, 0, 0]
                                                    },
                                                    {
                                                        qr: 'texto_o_url_para_el_qr',
                                                        alignment: 'center',
                                                        fit: 45
                                                    },
                                                ],
                                                border: [false, true, true, false] // Borde en la parte superior y derecha
                                            }
                                        ]
                                    ]
                                },
                            },
                            {
                                table: {
                                    widths: ['25%', '25%', '25%', '25%'],
                                    body: [
                                        [
                                            {
                                                text: 'RUC:',
                                                alignment: 'left',
                                                bold: true,
                                                fontSize: 6,
                                                border: [true, false, false, false] // Borde en el borde superior e izquierdo
                                            },
                                            {
                                                text: expediente.empresa.ruc,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 3,
                                                border: [false, false, true, false] // Borde en el borde inferior y derecho
                                            },
                                            {}, {}
                                        ],
                                        [
                                            {
                                                text: 'FECHA:',
                                                alignment: 'left',
                                                fontSize: 6,
                                                bold: true,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {
                                                text: (0, moment_timezone_1.default)(expediente.fechaRegistro).format("DD-MM-YYYY"),
                                                alignment: 'left',
                                                fontSize: 6,
                                                border: [false, false, false, false] // Sin bordes
                                            },
                                            {
                                                text: 'FOLIO:',
                                                alignment: 'left',
                                                fontSize: 6,
                                                bold: true,
                                                border: [false, false, false, false] // Sin bordes
                                            },
                                            {
                                                text: expediente.folio,
                                                fontSize: 6,
                                                alignment: 'left',
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            }
                                        ],
                                        [
                                            {
                                                text: 'ASUNTO:',
                                                fontSize: 6,
                                                alignment: 'left',
                                                bold: true,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {
                                                text: expediente.asunto,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 3,
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            },
                                            {}, {}
                                        ],
                                        [
                                            {
                                                text: 'RECIBIDO POR:',
                                                alignment: 'left',
                                                bold: true,
                                                fontSize: 6,
                                                colSpan: 2,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {},
                                            {
                                                text: expediente.remitente.nombres,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 2,
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            },
                                            {}
                                        ],
                                        [
                                            {
                                                text: 'DOCUMENTO RECIBIDO',
                                                alignment: 'center',
                                                bold: true,
                                                fontSize: 8,
                                                colSpan: 4,
                                                border: [true, false, true, true] // Borde inferior para la última fila
                                            },
                                            {}, {}, {}
                                        ]
                                    ]
                                }
                            }
                        ],
                        margin: [0, 0, 1, 0],
                    },
                    {
                        width: '50%',
                        stack: [
                            {
                                table: {
                                    widths: ['30%', '70%'],
                                    body: [
                                        [
                                            {
                                                stack: [
                                                    {
                                                        image: 'data:image/jpg;base64,' + imageString,
                                                        alignment: 'center',
                                                        width: 25,
                                                    },
                                                    {
                                                        text: expediente.empresa.nombre,
                                                        alignment: 'center',
                                                        fontSize: 5,
                                                        bold: true,
                                                        noWrap: false,
                                                        margin: [0, 5, 0, 0]
                                                    },
                                                ],
                                                border: [true, true, false, false] // Borde en la parte superior e izquierda
                                            },
                                            {
                                                stack: [
                                                    {
                                                        text: expediente.origen.nombre,
                                                        alignment: 'center',
                                                        bold: true,
                                                        fontSize: 6,
                                                        margin: [0, 5, 0, 0]
                                                    },
                                                    {
                                                        qr: 'texto_o_url_para_el_qr',
                                                        alignment: 'center',
                                                        fit: 45
                                                    },
                                                ],
                                                border: [false, true, true, false] // Borde en la parte superior y derecha
                                            }
                                        ]
                                    ]
                                },
                            },
                            {
                                table: {
                                    widths: ['25%', '25%', '25%', '25%'],
                                    body: [
                                        [
                                            {
                                                text: 'RUC:',
                                                alignment: 'left',
                                                bold: true,
                                                fontSize: 6,
                                                border: [true, false, false, false] // Borde en el borde superior e izquierdo
                                            },
                                            {
                                                text: expediente.empresa.ruc,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 3,
                                                border: [false, false, true, false] // Borde en el borde inferior y derecho
                                            },
                                            {}, {}
                                        ],
                                        [
                                            {
                                                text: 'FECHA:',
                                                alignment: 'left',
                                                fontSize: 6,
                                                bold: true,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {
                                                text: (0, moment_timezone_1.default)(expediente.fechaRegistro).format("DD-MM-YYYY"),
                                                alignment: 'left',
                                                fontSize: 6,
                                                border: [false, false, false, false] // Sin bordes
                                            },
                                            {
                                                text: 'FOLIO:',
                                                alignment: 'left',
                                                fontSize: 6,
                                                bold: true,
                                                border: [false, false, false, false] // Sin bordes
                                            },
                                            {
                                                text: expediente.folio,
                                                fontSize: 6,
                                                alignment: 'left',
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            }
                                        ],
                                        [
                                            {
                                                text: 'ASUNTO:',
                                                fontSize: 6,
                                                alignment: 'left',
                                                bold: true,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {
                                                text: expediente.asunto,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 3,
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            },
                                            {}, {}
                                        ],
                                        [
                                            {
                                                text: 'RECIBIDO POR:',
                                                alignment: 'left',
                                                bold: true,
                                                fontSize: 6,
                                                colSpan: 2,
                                                border: [true, false, false, false] // Borde en el borde izquierdo
                                            },
                                            {},
                                            {
                                                text: expediente.remitente.nombres,
                                                alignment: 'left',
                                                fontSize: 6,
                                                colSpan: 2,
                                                border: [false, false, true, false] // Borde en el borde derecho
                                            },
                                            {}
                                        ],
                                        [
                                            {
                                                text: 'DOCUMENTO RECIBIDO',
                                                alignment: 'center',
                                                bold: true,
                                                fontSize: 8,
                                                colSpan: 4,
                                                border: [true, false, true, true] // Borde inferior para la última fila
                                            },
                                            {}, {}, {}
                                        ]
                                    ]
                                },
                            }
                        ],
                        margin: [1, 0, 0, 0],
                    },
                ],
            },
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.SelloPdf = SelloPdf;
//# sourceMappingURL=content.js.map