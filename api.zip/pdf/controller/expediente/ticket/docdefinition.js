"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.docTicketDefinition = void 0;
const expediente_service_1 = require("../../../../tramite/expediente/service/expediente.service");
const style_1 = require("./style");
const content_1 = require("./content");
const empresa_service_1 = require("../../../../empresa/empresa/service/empresa.service");
const docTicketDefinition = (expedienteId, dataSource) => __awaiter(void 0, void 0, void 0, function* () {
    const expediente = yield expediente_service_1.expedienteService.findOneExpediente(expedienteId, dataSource);
    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
    const content = yield (0, content_1.TicketPdf)(empresa, expediente);
    const data = {
        pageSize: {
            width: 226.77,
            height: 'auto',
        },
        pageMargins: [5.66, 5.66, 5.66, 5.66],
        info: {
            title: 'F001-000001',
            author: 'JCM',
            subject: 'ticket',
            keywords: 'tck, sale',
        },
        content: content,
        defaultStyle: {
            font: 'Roboto'
        },
        styles: style_1.styles,
    };
    return data;
});
exports.docTicketDefinition = docTicketDefinition;
//# sourceMappingURL=docdefinition.js.map