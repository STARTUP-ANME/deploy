"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketPdf = void 0;
const downloadLogo_utils_1 = require("../../../utils/downloadLogo.utils");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const log_helper_1 = require("../../../../core/helpers/log.helper");
const TicketPdf = (empresa, expediente) => __awaiter(void 0, void 0, void 0, function* () {
    const download = yield (0, downloadLogo_utils_1.downloadImage)(empresa.imagen);
    const imageString = (0, downloadLogo_utils_1.convertImageToBase64)(download);
    try {
        const content = [
            {
                columns: [
                    {
                        width: '20%',
                        stack: [{
                                image: 'data:image/jpg;base64,' + imageString,
                                fit: [20, 20],
                                alignment: 'center',
                            }],
                        margin: [0, 0, 0, 0]
                    },
                    {
                        width: '80%',
                        stack: [
                            {
                                text: empresa.nombre,
                                bold: true,
                                fontSize: 8,
                                alignment: 'center'
                            },
                            {
                                text: `RUC: ${empresa.ruc}`,
                                bold: true,
                                fontSize: 8,
                                alignment: 'center'
                            },
                        ]
                    }
                ],
            },
            {
                text: expediente.origen.nombre,
                fontSize: 8,
                bold: true,
                margin: [0, 10, 0, 0],
                alignment: 'center'
            },
            {
                text: '___________________________________________________________________',
                fontSize: 7,
                bold: true,
                alignment: 'center'
            },
            {
                text: 'EXPEDIENTE EXTERNO',
                fontSize: 8,
                bold: true,
                margin: [0, 5, 0, 0],
                alignment: 'center'
            },
            {
                text: `${expediente.nroDocumento} - ${expediente.anio}`,
                fontSize: 8,
                bold: true,
                margin: [0, 0, 0, 0],
                alignment: 'center'
            },
            {
                text: '___________________________________________________________________',
                fontSize: 7,
                bold: true,
                alignment: 'center'
            },
            {
                table: {
                    widths: ['20%', '80%'],
                    body: [
                        [
                            {
                                text: 'FECHA:',
                                alignment: 'right',
                                fontSize: 8,
                                bold: true,
                                border: [false, false, false, false]
                            },
                            {
                                text: (0, moment_timezone_1.default)(expediente.fechaRegistro).tz("America/Lima").format("DD-MM-YYYY hh:mm A"),
                                alignment: 'left',
                                fontSize: 8,
                                border: [false, false, false, false]
                            }
                        ],
                        [
                            {
                                text: 'FOLIO:',
                                alignment: 'right',
                                fontSize: 8,
                                bold: true,
                                border: [false, false, false, false]
                            },
                            {
                                text: expediente.folio,
                                fontSize: 8,
                                alignment: 'left',
                                border: [false, false, false, false]
                            }
                        ],
                        [
                            {
                                text: 'ASUNTO:',
                                fontSize: 8,
                                alignment: 'right',
                                bold: true,
                                border: [false, false, false, false]
                            },
                            {
                                text: expediente.asunto,
                                alignment: 'left',
                                fontSize: 8,
                                border: [false, false, false, false]
                            },
                        ],
                        [
                            {
                                text: 'RECIBIDO: ',
                                alignment: 'right',
                                bold: true,
                                fontSize: 8,
                                border: [false, false, false, false]
                            },
                            {
                                text: `${expediente.usuario.persona.nombres} ${expediente.usuario.persona.apePaterno} ${expediente.usuario.persona.apeMaterno}`,
                                alignment: 'left',
                                fontSize: 8,
                                border: [false, false, false, false]
                            },
                        ],
                    ]
                }
            },
            {
                text: '___________________________________________________________________',
                fontSize: 7,
                bold: true,
                alignment: 'center'
            },
            {
                text: 'DOCUMENTO RECIBIDO',
                bold: true,
                fontSize: 8,
                alignment: 'center',
                margin: [0, 5, 0, 0]
            },
            {
                qr: `${empresa.ruc} - ${expediente.nroDocumento} - ${(0, moment_timezone_1.default)(expediente.fechaRegistro).tz("America/Lima").format("DD-MM-YYYY hh:mm A")}`,
                alignment: 'center',
                fit: 80,
                margin: [0, 10, 0, 10]
            },
            {
                text: 'Soluciones Tecnologicas M & C',
                bold: true,
                fontSize: 7,
                alignment: 'center'
            }
        ];
        return content;
    }
    catch (error) {
        log_helper_1.logger.error(`Error producido en ContentRangePdf: ${error.message}`);
        return [];
    }
});
exports.TicketPdf = TicketPdf;
//# sourceMappingURL=content.js.map