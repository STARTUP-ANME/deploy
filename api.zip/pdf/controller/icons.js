"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// export const IconFonts = {
//     normal: Buffer.from(vfsFonts.pdfMake.vfs['fontello.eot'], 'base64'),
//     bold: Buffer.from(vfsFonts.pdfMake.vfs['fontello.ttf'], 'base64'),
//     italics: Buffer.from(vfsFonts.pdfMake.vfs['fontello.woff'], 'base64'),
//     bolditalics: Buffer.from(vfsFonts.pdfMake.vfs['fontello.woff2'], 'base64')
// }
//# sourceMappingURL=icons.js.map