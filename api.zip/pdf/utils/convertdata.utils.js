"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dateFormat = exports.isNumberPositive = exports.getTextStatus = exports.wrapText = exports.convertNumberToTextSUNAT = void 0;
const moment_1 = __importDefault(require("moment"));
const convertNumberToTextSUNAT = (num) => {
    const parteEntera = Math.floor(num);
    const parteDecimal = Math.round((num - parteEntera) * 100);
    let resultado = convertirParteEntera(parteEntera);
    if (resultado === '') {
        resultado = 'cero';
    }
    if (parteDecimal > 0) {
        resultado += ` con ${parteDecimal}/100`;
    }
    return resultado;
};
exports.convertNumberToTextSUNAT = convertNumberToTextSUNAT;
const convertirParteEntera = (n) => {
    if (n < 0 || n > 9999) {
        return 'Número fuera de rango';
    }
    if (n === 0) {
        return '';
    }
    const unidades = [
        '',
        'uno',
        'dos',
        'tres',
        'cuatro',
        'cinco',
        'seis',
        'siete',
        'ocho',
        'nueve',
    ];
    const diezAVeinte = [
        'diez',
        'once',
        'doce',
        'trece',
        'catorce',
        'quince',
        'dieciséis',
        'diecisiete',
        'dieciocho',
        'diecinueve',
    ];
    const decenas = [
        '',
        'diez',
        'veinte',
        'treinta',
        'cuarenta',
        'cincuenta',
        'sesenta',
        'setenta',
        'ochenta',
        'noventa',
    ];
    const centenas = [
        '',
        'ciento',
        'doscientos',
        'trescientos',
        'cuatrocientos',
        'quinientos',
        'seiscientos',
        'setecientos',
        'ochocientos',
        'novecientos',
    ];
    let texto = '';
    if (n === 100) {
        return 'cien';
    }
    if (n >= 1000) {
        if (n >= 2000) {
            texto += unidades[Math.floor(n / 1000)] + ' mil ';
        }
        else {
            texto += 'mil ';
        }
        n %= 1000;
    }
    if (n >= 100) {
        texto += centenas[Math.floor(n / 100)] + ' ';
        n %= 100;
    }
    if (n >= 20) {
        texto += decenas[Math.floor(n / 10)] + ' ';
        n %= 10;
    }
    if (n >= 10 && n <= 19) {
        texto += diezAVeinte[n - 10];
        n = 0;
    }
    texto += unidades[n];
    return texto.trim();
};
const wrapText = (text, maxLength) => {
    const words = text.split(' ');
    const lines = [];
    let currentLine = '';
    for (const word of words) {
        if ((currentLine.length + word.length) <= maxLength) {
            currentLine += word + ' ';
        }
        else {
            lines.push(currentLine.trim());
            currentLine = word + ' ';
        }
    }
    lines.push(currentLine.trim());
    return lines;
};
exports.wrapText = wrapText;
const getTextStatus = (state) => {
    const status = {
        "1": "En proceso",
        "2": "Revisado",
        "3": "Aprobado",
        "4": "Denegado",
        "5": "Finalizado",
    };
    return status[state] || '';
};
exports.getTextStatus = getTextStatus;
const isNumberPositive = (value) => {
    let isPositive = true;
    if (value < 0) {
        isPositive = false;
    }
    return isPositive;
};
exports.isNumberPositive = isNumberPositive;
const dateFormat = (date) => {
    const format = (0, moment_1.default)(date).format('DD-MM-YYYY');
    return format;
};
exports.dateFormat = dateFormat;
//# sourceMappingURL=convertdata.utils.js.map