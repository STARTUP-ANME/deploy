"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertImageToBase64 = exports.downloadImage = void 0;
const axios_1 = __importDefault(require("axios"));
const log_helper_1 = require("../../core/helpers/log.helper");
const downloadImage = (url) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield (0, axios_1.default)({
            url,
            method: 'GET',
            responseType: 'arraybuffer',
        });
        return response.data;
    }
    catch (error) {
        log_helper_1.logger.error(`downloadImage ${error.message}`);
    }
});
exports.downloadImage = downloadImage;
const convertImageToBase64 = (imageBuffer) => {
    try {
        return imageBuffer.toString('base64');
    }
    catch (error) {
        log_helper_1.logger.error(`convertImageToBase64 ${error.message}`);
        return null;
    }
};
exports.convertImageToBase64 = convertImageToBase64;
//# sourceMappingURL=downloadLogo.utils.js.map