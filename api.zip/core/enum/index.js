"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EstadosTramite = exports.TipoExpediente = void 0;
var TipoExpediente;
(function (TipoExpediente) {
    TipoExpediente[TipoExpediente["Externo"] = 261] = "Externo";
    TipoExpediente[TipoExpediente["Interno"] = 262] = "Interno";
    TipoExpediente[TipoExpediente["MesaParteVirtual"] = 263] = "MesaParteVirtual";
})(TipoExpediente || (exports.TipoExpediente = TipoExpediente = {}));
var EstadosTramite;
(function (EstadosTramite) {
    EstadosTramite[EstadosTramite["Cancelado"] = 501] = "Cancelado";
    EstadosTramite[EstadosTramite["Observado"] = 502] = "Observado";
    EstadosTramite[EstadosTramite["Registrado"] = 503] = "Registrado";
    EstadosTramite[EstadosTramite["Enviado"] = 504] = "Enviado";
    EstadosTramite[EstadosTramite["Recibido"] = 505] = "Recibido";
    EstadosTramite[EstadosTramite["Copia"] = 506] = "Copia";
    EstadosTramite[EstadosTramite["Respuesta"] = 507] = "Respuesta";
    EstadosTramite[EstadosTramite["Atendidos"] = 508] = "Atendidos";
    EstadosTramite[EstadosTramite["Emitidos"] = 509] = "Emitidos";
    EstadosTramite[EstadosTramite["Espera"] = 510] = "Espera";
    EstadosTramite[EstadosTramite["Abandono"] = 511] = "Abandono";
    EstadosTramite[EstadosTramite["Activo"] = 512] = "Activo";
    EstadosTramite[EstadosTramite["Inactivo"] = 513] = "Inactivo";
    EstadosTramite[EstadosTramite["Eliminado"] = 514] = "Eliminado";
    EstadosTramite[EstadosTramite["Derivado"] = 515] = "Derivado";
    EstadosTramite[EstadosTramite["Finalizado"] = 516] = "Finalizado";
    EstadosTramite[EstadosTramite["Rechazado"] = 517] = "Rechazado";
    EstadosTramite[EstadosTramite["Archivado"] = 518] = "Archivado";
    EstadosTramite[EstadosTramite["Vinculado"] = 519] = "Vinculado";
    EstadosTramite[EstadosTramite["Desvinculado"] = 520] = "Desvinculado";
    EstadosTramite[EstadosTramite["ObservadoOtro"] = 521] = "ObservadoOtro";
})(EstadosTramite || (exports.EstadosTramite = EstadosTramite = {}));
//# sourceMappingURL=index.js.map