"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleTransaction = void 0;
const log_helper_1 = require("./log.helper");
const handleTransaction = (dataSource, transactionCallback) => __awaiter(void 0, void 0, void 0, function* () {
    const queryRunner = dataSource.createQueryRunner();
    yield queryRunner.connect();
    try {
        yield queryRunner.startTransaction();
        const result = yield transactionCallback(queryRunner);
        yield queryRunner.commitTransaction();
        return result;
    }
    catch (err) {
        yield queryRunner.rollbackTransaction();
        log_helper_1.logger.error(`transacciones: ${err.message}`);
        throw err;
    }
    finally {
        yield queryRunner.release();
    }
});
exports.handleTransaction = handleTransaction;
//# sourceMappingURL=transacction.handler.js.map