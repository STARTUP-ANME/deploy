"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logError = exports.logger = void 0;
const winston_1 = require("winston");
// Configuración del logger
exports.logger = (0, winston_1.createLogger)({
    level: 'info',
    format: winston_1.format.combine(winston_1.format.timestamp(), winston_1.format.json()),
    transports: [
        new winston_1.transports.Console(),
        new winston_1.transports.File({ filename: 'logs/combined.log' })
    ],
});
const logError = (error, name) => {
    var _a, _b, _c;
    const stackLines = ((_a = error.stack) === null || _a === void 0 ? void 0 : _a.split('\n')) || [];
    const functionName = ((_c = (_b = stackLines[1]) === null || _b === void 0 ? void 0 : _b.match(/at\s+(.*)\s+\(/)) === null || _c === void 0 ? void 0 : _c[1]) || name;
    // console.error(`Error in ${functionName}:`, error.message);
    // Aquí puedes guardar en un log el mensaje con el nombre de la función  
};
exports.logError = logError;
//# sourceMappingURL=log.helper.js.map