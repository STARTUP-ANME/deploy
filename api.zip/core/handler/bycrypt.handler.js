"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.compare = exports.encrypt = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
/**bcryptjs
 *
 * @param value texto plano
 * @returns retorna texto encriptado
 */
const encrypt = (value) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const salt = bcryptjs_1.default.genSaltSync();
        const hash = yield bcryptjs_1.default.hash(value, salt);
        return hash;
    }
    catch (error) {
        return error;
    }
});
exports.encrypt = encrypt;
/**
 *
 * @param value texto plano
 * @param valueHash texto encriptado
 * @returns retorna con un verdadero o falso
 */
const compare = (value, valueHash) => __awaiter(void 0, void 0, void 0, function* () {
    return yield bcryptjs_1.default.compare(value, valueHash);
});
exports.compare = compare;
//# sourceMappingURL=bycrypt.handler.js.map