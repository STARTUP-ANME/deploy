"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyJWTToken = exports.tokenSign = exports.TypeToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const enc_base64_1 = __importDefault(require("crypto-js/enc-base64"));
const crypto_js_1 = require("crypto-js");
var TypeToken;
(function (TypeToken) {
    TypeToken[TypeToken["secret"] = 0] = "secret";
    TypeToken[TypeToken["secret_refresh"] = 1] = "secret_refresh";
})(TypeToken || (exports.TypeToken = TypeToken = {}));
const tokenSign = (usuario) => __awaiter(void 0, void 0, void 0, function* () {
    let secret = process.env.JWT_SECRET;
    return jsonwebtoken_1.default.sign({
        usuarioId: usuario.usuarioId
    }, secret, {
        expiresIn: process.env.JWT_EXPIRE || "10h"
    });
});
exports.tokenSign = tokenSign;
/**
    * Verify the given token
    *
    * @param token
    * @private
    */
const verifyJWTToken = (token) => {
    // Split the token into parts
    const parts = token.split('.');
    const header = parts[0];
    const payload = parts[1];
    const signature = parts[2];
    // Re-sign and encode the header and payload using the secret
    const signatureCheck = _base64url((0, crypto_js_1.HmacSHA256)(header + '.' + payload, process.env.JWT_SECRET));
    // Verify that the resulting signature is valid
    return signature === signatureCheck;
};
exports.verifyJWTToken = verifyJWTToken;
/**
 * Return base64 encoded version of the given string
 *
 * @param source
 * @private
 */
const _base64url = (source) => {
    // Encode in classical base64
    let encodedSource = enc_base64_1.default.stringify(source);
    // Remove padding equal characters
    encodedSource = encodedSource.replace(/=+$/, '');
    // Replace characters according to base64url specifications
    encodedSource = encodedSource.replace(/\+/g, '-');
    encodedSource = encodedSource.replace(/\//g, '_');
    // Return the base64 encoded string
    return encodedSource;
};
//# sourceMappingURL=token.handler.js.map