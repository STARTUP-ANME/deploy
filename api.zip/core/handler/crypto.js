"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.decryptData = exports.encryptData = void 0;
const crypto_js_1 = __importDefault(require("crypto-js"));
const encryptData = (data, key) => {
    return crypto_js_1.default.AES.encrypt(JSON.stringify(data), key).toString();
};
exports.encryptData = encryptData;
const decryptData = (encryptedData, key) => {
    const bytes = crypto_js_1.default.AES.decrypt(encryptedData, key);
    return JSON.parse(bytes.toString(crypto_js_1.default.enc.Utf8));
};
exports.decryptData = decryptData;
//# sourceMappingURL=crypto.js.map