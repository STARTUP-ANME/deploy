"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatDomain = void 0;
const formatDomain = (domain) => {
    const [part1, part2, part3] = domain.split('.');
    const format = `${part1}-mpv.${part2}.${part3}`;
    return format;
};
exports.formatDomain = formatDomain;
//# sourceMappingURL=format-domain.js.map