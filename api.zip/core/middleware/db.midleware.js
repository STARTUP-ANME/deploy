"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dbMiddleware = void 0;
const entities_1 = require("entities");
// Middleware para conectar a la base de datos dependiendo del subdominio
const dbMiddleware = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    const subdomain = getSubdomain(req);
    //
    //loadDatabaseConfig(subdomain)    
    try {
        const dataSource = yield (0, entities_1.connectToDatabase)(subdomain);
        if (dataSource) {
            req['dbConnection'] = dataSource; // Guardar la instancia de DataSource para usarla más tarde
            next();
        }
        else {
            res.status(500).json({ message: 'No se pudo conectar a la base de datos' });
        }
    }
    catch (error) {
        res.status(500).json({ message: 'Error al conectar a la base de datos' });
    }
});
exports.dbMiddleware = dbMiddleware;
const getSubdomain = (req) => {
    var _a;
    // console.log("🚀 ~ getSubdomain ~ req:", req)
    const url = new URL((_a = req.headers) === null || _a === void 0 ? void 0 : _a.origin);
    console.log("🚀 ~ getSubdomain ~ url:", url);
    //
    //
    const domain = url.hostname;
    //
    //
    return domain ? domain : '';
};
//# sourceMappingURL=db.midleware.js.map