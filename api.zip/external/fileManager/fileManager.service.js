"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileManagerService = exports.FileManagerService = void 0;
const axios_1 = __importDefault(require("axios"));
const log_helper_1 = require("../../core/helpers/log.helper");
class FileManagerService {
    static getInstance() {
        if (!this.instance)
            this.instance = new FileManagerService();
        return this.instance;
    }
    constructor() {
        this.externalApi = process.env.API_FILE_MANAGER || '';
        this.apiClient = axios_1.default.create({
            baseURL: this.externalApi,
            timeout: 10000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
    // Método para enviar mensajes de WhatsApp
    upload(formData) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const endPoint = '/file/upload';
                const data = {
                    formData
                };
                const response = yield this.apiClient.post(endPoint, data);
                return response.data;
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                return null;
            }
        });
    }
}
exports.FileManagerService = FileManagerService;
exports.fileManagerService = FileManagerService.getInstance();
//# sourceMappingURL=fileManager.service.js.map