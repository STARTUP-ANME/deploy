"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoTramiteRoute = void 0;
const express_1 = require("express");
const tipoTramite_controller_1 = require("../controller/tipoTramite.controller");
exports.tipoTramiteRoute = (0, express_1.Router)();
exports.tipoTramiteRoute.get('/', tipoTramite_controller_1.tipoTramiteController.findTipoTramite);
exports.tipoTramiteRoute.post('/create', tipoTramite_controller_1.tipoTramiteController.createTipoTramite);
exports.tipoTramiteRoute.put('/update', tipoTramite_controller_1.tipoTramiteController.updateTipoTramite);
exports.tipoTramiteRoute.delete('/delete/:tipoTramiteId', tipoTramite_controller_1.tipoTramiteController.deleteTipoTramite);
//# sourceMappingURL=tipoTramite.routes.js.map