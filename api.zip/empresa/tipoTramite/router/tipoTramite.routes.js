"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoTramiteRoute = void 0;
const express_1 = require("express");
const tipoTramite_controller_1 = require("../controller/tipoTramite.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.tipoTramiteRoute = (0, express_1.Router)();
exports.tipoTramiteRoute.get('/', db_midleware_1.dbMiddleware, tipoTramite_controller_1.tipoTramiteController.findTipoTramite);
exports.tipoTramiteRoute.post('/create', db_midleware_1.dbMiddleware, tipoTramite_controller_1.tipoTramiteController.createTipoTramite);
exports.tipoTramiteRoute.put('/update', db_midleware_1.dbMiddleware, tipoTramite_controller_1.tipoTramiteController.updateTipoTramite);
exports.tipoTramiteRoute.delete('/delete/:tipoTramiteId', db_midleware_1.dbMiddleware, tipoTramite_controller_1.tipoTramiteController.deleteTipoTramite);
//# sourceMappingURL=tipoTramite.routes.js.map