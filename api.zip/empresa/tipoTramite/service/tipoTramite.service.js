"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoTramiteService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class TipoTramiteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TipoTramiteService();
        return this.instance;
    }
    findTipoTramite(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoTramiteModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        descripcion: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createTipoTramite(tipoTramite, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoTramiteModel).save(tipoTramite);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateTipoTramite(tipoTramite, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoTramiteModel).update({ tipoTramiteId: tipoTramite.tipoTramiteId }, {
                    descripcion: tipoTramite.descripcion,
                    valor: tipoTramite.valor,
                    valorII: tipoTramite.valorII
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteTipoTramite(tipoTramiteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoTramiteModel).update({ tipoTramiteId: tipoTramiteId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.tipoTramiteService = TipoTramiteService.getInstance();
//# sourceMappingURL=tipoTramite.service.js.map