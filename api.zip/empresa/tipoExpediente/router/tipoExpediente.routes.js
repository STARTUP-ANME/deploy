"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoExpedienteRoute = void 0;
const express_1 = require("express");
const tipoExpediente_controller_1 = require("../controller/tipoExpediente.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.tipoExpedienteRoute = (0, express_1.Router)();
exports.tipoExpedienteRoute.get('/', db_midleware_1.dbMiddleware, tipoExpediente_controller_1.tipoExpedienteController.findTipoExpediente);
exports.tipoExpedienteRoute.post('/create', db_midleware_1.dbMiddleware, tipoExpediente_controller_1.tipoExpedienteController.createTipoExpediente);
exports.tipoExpedienteRoute.put('/update', db_midleware_1.dbMiddleware, tipoExpediente_controller_1.tipoExpedienteController.updateTipoExpediente);
exports.tipoExpedienteRoute.delete('/delete/:tipoExpedienteId', db_midleware_1.dbMiddleware, tipoExpediente_controller_1.tipoExpedienteController.deleteTipoExpediente);
//# sourceMappingURL=tipoExpediente.routes.js.map