"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoExpedienteRoute = void 0;
const express_1 = require("express");
const tipoExpediente_controller_1 = require("../controller/tipoExpediente.controller");
exports.tipoExpedienteRoute = (0, express_1.Router)();
exports.tipoExpedienteRoute.get('/', tipoExpediente_controller_1.tipoExpedienteController.findTipoExpediente);
exports.tipoExpedienteRoute.post('/create', tipoExpediente_controller_1.tipoExpedienteController.createTipoExpediente);
exports.tipoExpedienteRoute.put('/update', tipoExpediente_controller_1.tipoExpedienteController.updateTipoExpediente);
exports.tipoExpedienteRoute.put('/delete/:tipoExpedienteId', tipoExpediente_controller_1.tipoExpedienteController.deleteTipoExpediente);
//# sourceMappingURL=tipoExpediente.routes.js.map