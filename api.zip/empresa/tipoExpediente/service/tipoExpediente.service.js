"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoExpedienteService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class TipoExpedienteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TipoExpedienteService();
        return this.instance;
    }
    findTipoExpediente(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoExpedienteModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        tipoExpedienteId: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createTipoExpediente(tipoExpediente, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoExpedienteModel).save(tipoExpediente);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateTipoExpediente(tipoExpediente, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoExpedienteModel).update({ tipoExpedienteId: tipoExpediente.tipoExpedienteId }, {
                    codigo: tipoExpediente.codigo,
                    descripcion: tipoExpediente.descripcion,
                    color: tipoExpediente.color
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteTipoExpediente(tipoExpedienteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoExpedienteModel).update({ tipoExpedienteId: tipoExpedienteId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.tipoExpedienteService = TipoExpedienteService.getInstance();
//# sourceMappingURL=tipoExpediente.service.js.map