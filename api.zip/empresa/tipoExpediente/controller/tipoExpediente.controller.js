"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoExpedienteController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const tipoExpediente_service_1 = require("../service/tipoExpediente.service");
class TipoExpedienteController {
    static getInstance() {
        if (!this.instance)
            this.instance = new TipoExpedienteController();
        return this.instance;
    }
    findTipoExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield tipoExpediente_service_1.tipoExpedienteService.findTipoExpediente();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createTipoExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { tipoExpediente } = req.body;
                const response = yield tipoExpediente_service_1.tipoExpedienteService.createTipoExpediente(tipoExpediente);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_TIPO_EXPEDIENTE, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateTipoExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { tipoExpediente } = req.body;
                const response = yield tipoExpediente_service_1.tipoExpedienteService.updateTipoExpediente(tipoExpediente);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_TIPO_EXPEDIENTE, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteTipoExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { tipoExpedienteId } = req.params;
                const response = yield tipoExpediente_service_1.tipoExpedienteService.deleteTipoExpediente(Number(tipoExpedienteId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_TIPO_EXPEDIENTE, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.tipoExpedienteController = TipoExpedienteController.getInstance();
//# sourceMappingURL=tipoExpediente.controller.js.map