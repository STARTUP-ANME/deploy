"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.divisaRoute = void 0;
const express_1 = require("express");
const divisas_controller_1 = require("../controller/divisas.controller");
exports.divisaRoute = (0, express_1.Router)();
exports.divisaRoute.get('/', divisas_controller_1.divisaController.findDivisa);
exports.divisaRoute.post('/create', divisas_controller_1.divisaController.createDivisa);
exports.divisaRoute.put('/update', divisas_controller_1.divisaController.updateDivisa);
exports.divisaRoute.delete('/delete/:divisaId', divisas_controller_1.divisaController.deleteDivisa);
//# sourceMappingURL=divisas.routes.js.map