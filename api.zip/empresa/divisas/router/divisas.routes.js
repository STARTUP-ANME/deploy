"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.divisaRoute = void 0;
const express_1 = require("express");
const divisas_controller_1 = require("../controller/divisas.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.divisaRoute = (0, express_1.Router)();
exports.divisaRoute.get('/', db_midleware_1.dbMiddleware, divisas_controller_1.divisaController.findDivisa);
exports.divisaRoute.post('/create', db_midleware_1.dbMiddleware, divisas_controller_1.divisaController.createDivisa);
exports.divisaRoute.put('/update', db_midleware_1.dbMiddleware, divisas_controller_1.divisaController.updateDivisa);
exports.divisaRoute.delete('/delete/:divisaId', db_midleware_1.dbMiddleware, divisas_controller_1.divisaController.deleteDivisa);
//# sourceMappingURL=divisas.routes.js.map