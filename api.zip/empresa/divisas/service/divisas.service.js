"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.divisaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class DivisaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DivisaService();
        return this.instance;
    }
    findDivisa() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.DivisaModel.find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        divisaId: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createDivisa(divisa) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.DivisaModel.save(divisa);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateDivisa(divisa) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.DivisaModel.update({ divisaId: divisa.divisaId }, {
                    descripcion: divisa.descripcion,
                    simbolo: divisa.simbolo
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteDivisa(divisaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.DivisaModel.update({ divisaId: divisaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.divisaService = DivisaService.getInstance();
//# sourceMappingURL=divisas.service.js.map