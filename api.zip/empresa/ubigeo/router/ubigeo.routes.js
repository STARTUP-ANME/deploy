"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ubigeoRoute = void 0;
const express_1 = require("express");
const ubigeo_controller_1 = require("../controller/ubigeo.controller");
exports.ubigeoRoute = (0, express_1.Router)();
exports.ubigeoRoute.get('/', ubigeo_controller_1.ubigeoController.findUbigeo);
//# sourceMappingURL=ubigeo.routes.js.map