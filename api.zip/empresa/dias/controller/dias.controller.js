"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.diasController = void 0;
const dias_service_1 = require("../service/dias.service");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class DiasController {
    static getInstance() {
        if (!this.instance)
            this.instance = new DiasController();
        return this.instance;
    }
    findDias(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const response = yield dias_service_1.diasService.findDias(dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createDias(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { dias } = req.body;
                const response = yield dias_service_1.diasService.createDias(dias, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_CARGO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateDias(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { dias } = req.body;
                const response = yield dias_service_1.diasService.updateDias(dias, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_CARGO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteDias(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { diaId } = req.params;
                const response = yield dias_service_1.diasService.deleteDias(Number(diaId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_CARGO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.diasController = DiasController.getInstance();
//# sourceMappingURL=dias.controller.js.map