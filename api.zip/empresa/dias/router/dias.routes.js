"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.diasRoute = void 0;
const express_1 = require("express");
const dias_controller_1 = require("../controller/dias.controller");
exports.diasRoute = (0, express_1.Router)();
exports.diasRoute.get('/', dias_controller_1.diasController.findDias);
exports.diasRoute.post('/create', dias_controller_1.diasController.createDias);
exports.diasRoute.put('/update', dias_controller_1.diasController.updateDias);
exports.diasRoute.delete('/delete/:diaId', dias_controller_1.diasController.deleteDias);
//# sourceMappingURL=dias.routes.js.map