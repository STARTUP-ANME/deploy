"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.diasRoute = void 0;
const express_1 = require("express");
const dias_controller_1 = require("../controller/dias.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.diasRoute = (0, express_1.Router)();
exports.diasRoute.get('/', db_midleware_1.dbMiddleware, dias_controller_1.diasController.findDias);
exports.diasRoute.post('/create', db_midleware_1.dbMiddleware, dias_controller_1.diasController.createDias);
exports.diasRoute.put('/update', db_midleware_1.dbMiddleware, dias_controller_1.diasController.updateDias);
exports.diasRoute.delete('/delete/:diaId', db_midleware_1.dbMiddleware, dias_controller_1.diasController.deleteDias);
//# sourceMappingURL=dias.routes.js.map