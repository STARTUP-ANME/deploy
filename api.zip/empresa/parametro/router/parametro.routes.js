"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parametroRoute = void 0;
const express_1 = require("express");
const parametro_controller_1 = require("../controller/parametro.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.parametroRoute = (0, express_1.Router)();
exports.parametroRoute.get('/', db_midleware_1.dbMiddleware, parametro_controller_1.parametroController.findParametro);
exports.parametroRoute.post('/create', db_midleware_1.dbMiddleware, parametro_controller_1.parametroController.createParametro);
exports.parametroRoute.put('/update', db_midleware_1.dbMiddleware, parametro_controller_1.parametroController.updateParametro);
exports.parametroRoute.put('/delete/:parametroId', db_midleware_1.dbMiddleware, parametro_controller_1.parametroController.deleteParametro);
//# sourceMappingURL=parametro.routes.js.map