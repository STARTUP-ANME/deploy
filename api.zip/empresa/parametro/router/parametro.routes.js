"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parametroRoute = void 0;
const express_1 = require("express");
const parametro_controller_1 = require("../controller/parametro.controller");
exports.parametroRoute = (0, express_1.Router)();
exports.parametroRoute.get('/', parametro_controller_1.parametroController.findParametro);
exports.parametroRoute.post('/create', parametro_controller_1.parametroController.createParametro);
exports.parametroRoute.put('/update', parametro_controller_1.parametroController.updateParametro);
exports.parametroRoute.put('/delete/:parametroId', parametro_controller_1.parametroController.deleteParametro);
//# sourceMappingURL=parametro.routes.js.map