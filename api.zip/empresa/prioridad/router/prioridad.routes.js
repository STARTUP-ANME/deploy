"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prioridadRoute = void 0;
const express_1 = require("express");
const prioridad_controller_1 = require("../controller/prioridad.controller");
exports.prioridadRoute = (0, express_1.Router)();
exports.prioridadRoute.get('/', prioridad_controller_1.prioridadController.findPrioridad);
exports.prioridadRoute.post('/create', prioridad_controller_1.prioridadController.createPrioridad);
exports.prioridadRoute.put('/update', prioridad_controller_1.prioridadController.updatePrioridad);
exports.prioridadRoute.delete('/delete/:prioridadId', prioridad_controller_1.prioridadController.deletePrioridad);
//# sourceMappingURL=prioridad.routes.js.map