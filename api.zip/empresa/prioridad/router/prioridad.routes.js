"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prioridadRoute = void 0;
const express_1 = require("express");
const prioridad_controller_1 = require("../controller/prioridad.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.prioridadRoute = (0, express_1.Router)();
exports.prioridadRoute.get('/', db_midleware_1.dbMiddleware, prioridad_controller_1.prioridadController.findPrioridad);
exports.prioridadRoute.post('/create', db_midleware_1.dbMiddleware, prioridad_controller_1.prioridadController.createPrioridad);
exports.prioridadRoute.put('/update', db_midleware_1.dbMiddleware, prioridad_controller_1.prioridadController.updatePrioridad);
exports.prioridadRoute.delete('/delete/:prioridadId', db_midleware_1.dbMiddleware, prioridad_controller_1.prioridadController.deletePrioridad);
//# sourceMappingURL=prioridad.routes.js.map