"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoDocumentoRoute = void 0;
const express_1 = require("express");
const tipoDocumento_controller_1 = require("../controller/tipoDocumento.controller");
exports.tipoDocumentoRoute = (0, express_1.Router)();
exports.tipoDocumentoRoute.get('/', tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumento);
exports.tipoDocumentoRoute.get('/identificacion', tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoIdentification);
exports.tipoDocumentoRoute.get('/contrato', tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoContrato);
exports.tipoDocumentoRoute.get('/tramite', tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoTramite);
exports.tipoDocumentoRoute.get('/correlativo', tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoCorrelativo);
exports.tipoDocumentoRoute.post('/create', tipoDocumento_controller_1.tipoDocumentoController.createTipoDocumento);
exports.tipoDocumentoRoute.put('/update', tipoDocumento_controller_1.tipoDocumentoController.updateTipoDocumento);
exports.tipoDocumentoRoute.delete('/delete/:tipoDocumentoId', tipoDocumento_controller_1.tipoDocumentoController.deleteTipoDocumento);
//# sourceMappingURL=tipoDocumento.routes.js.map