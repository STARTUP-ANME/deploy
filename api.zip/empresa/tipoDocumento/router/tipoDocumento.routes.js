"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoDocumentoRoute = void 0;
const express_1 = require("express");
const tipoDocumento_controller_1 = require("../controller/tipoDocumento.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.tipoDocumentoRoute = (0, express_1.Router)();
exports.tipoDocumentoRoute.get('/', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumento);
exports.tipoDocumentoRoute.get('/identificacion', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoIdentification);
exports.tipoDocumentoRoute.get('/contrato', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoContrato);
exports.tipoDocumentoRoute.get('/tramite', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoTramite);
exports.tipoDocumentoRoute.get('/correlativo', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.findTipoDocumentoCorrelativo);
exports.tipoDocumentoRoute.post('/create', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.createTipoDocumento);
exports.tipoDocumentoRoute.put('/update', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.updateTipoDocumento);
exports.tipoDocumentoRoute.post('/por-defecto', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.updatePorDefecto);
exports.tipoDocumentoRoute.delete('/delete/:tipoDocumentoId', db_midleware_1.dbMiddleware, tipoDocumento_controller_1.tipoDocumentoController.deleteTipoDocumento);
//# sourceMappingURL=tipoDocumento.routes.js.map