"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoDocumentoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const tipoDocumento_enum_1 = require("entities/src/core/enums/tipoDocumento.enum");
class TipoDocumentoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TipoDocumentoService();
        return this.instance;
    }
    findTipoDocumento(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        tipoDocumentoId: 'ASC'
                    },
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findTipoDocumentoIdentificacion(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).find({
                    where: {
                        audAnulado: '0',
                        tipo: tipoDocumento_enum_1.TipoDocumento.Identificacion
                    },
                    relations: {
                        tipoPersona: true,
                        tipoPersonaDocumentos: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findTipoDocumentoContrato(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).find({
                    where: {
                        audAnulado: '0',
                        tipo: tipoDocumento_enum_1.TipoDocumento.Contrato
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findTipoDocumentoTramite(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).find({
                    where: {
                        audAnulado: '0',
                        tipo: tipoDocumento_enum_1.TipoDocumento.Tramite
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findTipoDocumentoCorrelativo(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).find({
                    where: {
                        audAnulado: '0',
                        tipo: tipoDocumento_enum_1.TipoDocumento.Correlativo
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createTipoDocumento(tipoDocumento, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).save(tipoDocumento);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateTipoDocumento(tipoDocumento, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).update({ tipoDocumentoId: tipoDocumento.tipoDocumentoId }, {
                    tipo: tipoDocumento.tipo,
                    descripcion: tipoDocumento.descripcion,
                    caracteres: tipoDocumento.caracteres
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteTipoDocumento(tipoDocumentoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TipoDocumentoModel).update({ tipoDocumentoId: tipoDocumentoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.tipoDocumentoService = TipoDocumentoService.getInstance();
//# sourceMappingURL=tipoDocumento.service.js.map