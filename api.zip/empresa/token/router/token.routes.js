"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tokenRoute = void 0;
const express_1 = require("express");
const token_controller_1 = require("../controller/token.controller");
exports.tokenRoute = (0, express_1.Router)();
exports.tokenRoute.get('/', token_controller_1.tokenController.findToken);
exports.tokenRoute.post('/create', token_controller_1.tokenController.createToken);
exports.tokenRoute.put('/update', token_controller_1.tokenController.updateToken);
exports.tokenRoute.delete('/delete/:tokenId', token_controller_1.tokenController.deleteToken);
//# sourceMappingURL=token.routes.js.map