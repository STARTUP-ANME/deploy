"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tokenService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class TokenService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TokenService();
        return this.instance;
    }
    findToken(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TokenModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        tokenId: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createToken(Token, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TokenModel).save(Token);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateToken(token, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TokenModel).update({ tokenId: token.tokenId }, {
                    token: token.token
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteToken(tokenId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.TokenModel).update({ tokenId: tokenId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.tokenService = TokenService.getInstance();
//# sourceMappingURL=token.service.js.map