"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.empresaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class EmpresaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new EmpresaService();
        return this.instance;
    }
    findEmpresa(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).find({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneEmpresa(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).findOne({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createEmpresa(empresa, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).save(empresa);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'create empresa');
            }
        });
    }
    updateEmpresa(empresa, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).update({ empresaId: empresa.empresaId }, {
                    abrev: empresa.abrev,
                    nombre: empresa.nombre,
                    ruc: empresa.ruc,
                    direccion: empresa.direccion,
                    imagen: empresa.imagen,
                    fut: empresa.fut,
                    ubigeoId: empresa.ubigeoId,
                    plazoAdmin: empresa.plazoAdmin,
                    plazoLegal: empresa.plazoLegal,
                    mesaParteId: empresa.mesaParteId,
                    porVencer: empresa.porVencer,
                    email: empresa.email,
                    contrasena: empresa.contrasena,
                    servidor: empresa.servidor,
                    puerto: empresa.puerto,
                    ssl: empresa.ssl,
                    plantillaProveido: empresa.plantillaProveido,
                    horaInicio: empresa.horaInicio,
                    horaFin: empresa.horaFin,
                    isPrintCargoExterno: empresa.isPrintCargoExterno,
                    isPrintCargoInterno: empresa.isPrintCargoInterno,
                    licencia: empresa.licencia,
                    validar: empresa.validar,
                    rutaMunicipalidad: empresa.rutaMunicipalidad,
                    manual: empresa.manual
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateLogoEmpresa(empresaId, imagen, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).update({ empresaId: empresaId }, {
                    imagen
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteEmpresa(empresaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.EmpresaModel).update({ empresaId: empresaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.empresaService = EmpresaService.getInstance();
//# sourceMappingURL=empresa.service.js.map