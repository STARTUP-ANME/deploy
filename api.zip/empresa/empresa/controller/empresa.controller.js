"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.empresaController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const empresa_service_1 = require("../service/empresa.service");
class EmpresaController {
    static getInstance() {
        if (!this.instance)
            this.instance = new EmpresaController();
        return this.instance;
    }
    findEmpresa(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const response = yield empresa_service_1.empresaService.findEmpresa(dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createEmpresa(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const empresa = req.body;
                const response = yield empresa_service_1.empresaService.createEmpresa(empresa, dataSource);
                if (response.empresaId > 0) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_EMPRESA, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateEmpresa(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { empresa } = req.body;
                const response = yield empresa_service_1.empresaService.updateEmpresa(empresa, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_EMPRESA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateLogoEmpresa(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { empresaId, imagen } = req.body;
                const response = yield empresa_service_1.empresaService.updateLogoEmpresa(empresaId, imagen, dataSource);
                if ((response === null || response === void 0 ? void 0 : response.affected) > 0) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_LOGO_EMPRESA, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_LOGO_EMPRESA });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteEmpresa(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            try {
                const { empresaId } = req.params;
                const response = yield empresa_service_1.empresaService.deleteEmpresa(Number(empresaId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_EMPRESA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.empresaController = EmpresaController.getInstance();
//# sourceMappingURL=empresa.controller.js.map