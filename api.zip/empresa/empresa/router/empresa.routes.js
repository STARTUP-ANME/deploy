"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.empresaRoute = void 0;
const express_1 = require("express");
const empresa_controller_1 = require("../controller/empresa.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.empresaRoute = (0, express_1.Router)();
exports.empresaRoute.get('/', db_midleware_1.dbMiddleware, empresa_controller_1.empresaController.findEmpresa);
exports.empresaRoute.post('/', db_midleware_1.dbMiddleware, empresa_controller_1.empresaController.createEmpresa);
exports.empresaRoute.put('/update', db_midleware_1.dbMiddleware, empresa_controller_1.empresaController.updateEmpresa);
exports.empresaRoute.post('/logo_update', db_midleware_1.dbMiddleware, empresa_controller_1.empresaController.updateLogoEmpresa);
exports.empresaRoute.put('/delete/:empresaId', db_midleware_1.dbMiddleware, empresa_controller_1.empresaController.deleteEmpresa);
//# sourceMappingURL=empresa.routes.js.map