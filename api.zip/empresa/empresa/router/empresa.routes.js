"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.empresaRoute = void 0;
const express_1 = require("express");
const empresa_controller_1 = require("../controller/empresa.controller");
exports.empresaRoute = (0, express_1.Router)();
exports.empresaRoute.get('/', empresa_controller_1.empresaController.findEmpresa);
exports.empresaRoute.post('/', empresa_controller_1.empresaController.createEmpresa);
exports.empresaRoute.put('/update', empresa_controller_1.empresaController.updateEmpresa);
exports.empresaRoute.put('/delete/:empresaId', empresa_controller_1.empresaController.deleteEmpresa);
//# sourceMappingURL=empresa.routes.js.map