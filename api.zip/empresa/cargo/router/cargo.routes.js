"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cargoRoute = void 0;
const express_1 = require("express");
const cargo_controller_1 = require("../controller/cargo.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.cargoRoute = (0, express_1.Router)();
exports.cargoRoute.get('/', db_midleware_1.dbMiddleware, cargo_controller_1.cargoController.findCargo);
exports.cargoRoute.post('/create', db_midleware_1.dbMiddleware, cargo_controller_1.cargoController.createCargo);
exports.cargoRoute.put('/update', db_midleware_1.dbMiddleware, cargo_controller_1.cargoController.updateCargo);
exports.cargoRoute.delete('/delete/:cargoId', db_midleware_1.dbMiddleware, cargo_controller_1.cargoController.deleteCargo);
//# sourceMappingURL=cargo.routes.js.map