"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cargoRoute = void 0;
const express_1 = require("express");
const cargo_controller_1 = require("../controller/cargo.controller");
exports.cargoRoute = (0, express_1.Router)();
exports.cargoRoute.get('/', cargo_controller_1.cargoController.findCargo);
exports.cargoRoute.post('/create', cargo_controller_1.cargoController.createCargo);
exports.cargoRoute.put('/update', cargo_controller_1.cargoController.updateCargo);
exports.cargoRoute.delete('/delete/:cargoId', cargo_controller_1.cargoController.deleteCargo);
//# sourceMappingURL=cargo.routes.js.map