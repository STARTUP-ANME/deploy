"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configuracionRoute = void 0;
const express_1 = require("express");
const configuracion_controller_1 = require("../controller/configuracion.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.configuracionRoute = (0, express_1.Router)();
exports.configuracionRoute.get('/', db_midleware_1.dbMiddleware, configuracion_controller_1.configuracionController.findConfiguracion);
exports.configuracionRoute.post('/create', db_midleware_1.dbMiddleware, configuracion_controller_1.configuracionController.createConfiguracion);
exports.configuracionRoute.put('/update', db_midleware_1.dbMiddleware, configuracion_controller_1.configuracionController.updateConfiguracion);
exports.configuracionRoute.put('/delete/:configuracionId', db_midleware_1.dbMiddleware, configuracion_controller_1.configuracionController.deleteConfiguracion);
//# sourceMappingURL=configuracion.routes.js.map