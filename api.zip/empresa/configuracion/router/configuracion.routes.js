"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configuracionRoute = void 0;
const express_1 = require("express");
const configuracion_controller_1 = require("../controller/configuracion.controller");
exports.configuracionRoute = (0, express_1.Router)();
exports.configuracionRoute.get('/', configuracion_controller_1.configuracionController.findConfiguracion);
exports.configuracionRoute.post('/create', configuracion_controller_1.configuracionController.createConfiguracion);
exports.configuracionRoute.put('/update', configuracion_controller_1.configuracionController.updateConfiguracion);
exports.configuracionRoute.put('/delete/:configuracionId', configuracion_controller_1.configuracionController.deleteConfiguracion);
//# sourceMappingURL=configuracion.routes.js.map