"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoRoute = void 0;
const express_1 = require("express");
const proceso_controller_1 = require("../controller/proceso.controller");
exports.procesoRoute = (0, express_1.Router)();
exports.procesoRoute.get('/', proceso_controller_1.procesoController.findProceso);
exports.procesoRoute.post('/create', proceso_controller_1.procesoController.createProceso);
exports.procesoRoute.put('/update', proceso_controller_1.procesoController.updateProceso);
exports.procesoRoute.put('/delete/:procesoId', proceso_controller_1.procesoController.deleteProceso);
//# sourceMappingURL=proceso.routes.js.map