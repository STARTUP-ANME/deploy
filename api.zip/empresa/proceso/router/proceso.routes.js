"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoRoute = void 0;
const express_1 = require("express");
const proceso_controller_1 = require("../controller/proceso.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.procesoRoute = (0, express_1.Router)();
exports.procesoRoute.get('/', db_midleware_1.dbMiddleware, proceso_controller_1.procesoController.findProceso);
exports.procesoRoute.post('/create', db_midleware_1.dbMiddleware, proceso_controller_1.procesoController.createProceso);
exports.procesoRoute.put('/update', db_midleware_1.dbMiddleware, proceso_controller_1.procesoController.updateProceso);
exports.procesoRoute.put('/delete/:procesoId', db_midleware_1.dbMiddleware, proceso_controller_1.procesoController.deleteProceso);
//# sourceMappingURL=proceso.routes.js.map