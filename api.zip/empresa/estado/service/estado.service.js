"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.estadoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class EstadoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new EstadoService();
        return this.instance;
    }
    findEstado() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EstadoModel.find({
                    where: {
                        audAnulado: '0'
                    },
                    order: {
                        estadoId: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createEstado(estado) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EstadoModel.save(estado);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateEstado(estado) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EstadoModel.update({ estadoId: estado.estadoId }, {
                    codigo: estado.codigo,
                    descripcion: estado.descripcion,
                    color: estado.color,
                    tipo: estado.tipo
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteEstado(estadoId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EstadoModel.update({ estadoId: estadoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.estadoService = EstadoService.getInstance();
//# sourceMappingURL=estado.service.js.map