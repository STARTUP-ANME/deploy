"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.estadoRoute = void 0;
const express_1 = require("express");
const estado_controller_1 = require("../controller/estado.controller");
exports.estadoRoute = (0, express_1.Router)();
exports.estadoRoute.get('/', estado_controller_1.estadoController.findEstado);
exports.estadoRoute.post('/create', estado_controller_1.estadoController.createEstado);
exports.estadoRoute.put('/update', estado_controller_1.estadoController.updateEstado);
exports.estadoRoute.delete('/delete/:estadoId', estado_controller_1.estadoController.deleteEstado);
//# sourceMappingURL=estado.routes.js.map