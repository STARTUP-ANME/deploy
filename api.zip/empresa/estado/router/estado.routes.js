"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.estadoRoute = void 0;
const express_1 = require("express");
const estado_controller_1 = require("../controller/estado.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.estadoRoute = (0, express_1.Router)();
exports.estadoRoute.get('/', db_midleware_1.dbMiddleware, estado_controller_1.estadoController.findEstado);
exports.estadoRoute.post('/create', db_midleware_1.dbMiddleware, estado_controller_1.estadoController.createEstado);
exports.estadoRoute.put('/update', db_midleware_1.dbMiddleware, estado_controller_1.estadoController.updateEstado);
exports.estadoRoute.delete('/delete/:estadoId', db_midleware_1.dbMiddleware, estado_controller_1.estadoController.deleteEstado);
//# sourceMappingURL=estado.routes.js.map