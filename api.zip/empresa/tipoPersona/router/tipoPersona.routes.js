"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoPersonaRoute = void 0;
const express_1 = require("express");
const tipoPersona_controller_1 = require("../controller/tipoPersona.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.tipoPersonaRoute = (0, express_1.Router)();
exports.tipoPersonaRoute.get('/', db_midleware_1.dbMiddleware, tipoPersona_controller_1.tipoPersonaController.findTipoPersona);
exports.tipoPersonaRoute.post('/create', db_midleware_1.dbMiddleware, tipoPersona_controller_1.tipoPersonaController.createTipoPersona);
exports.tipoPersonaRoute.put('/update', db_midleware_1.dbMiddleware, tipoPersona_controller_1.tipoPersonaController.updateTipoPersona);
exports.tipoPersonaRoute.delete('/delete/:tipoPersonaId', db_midleware_1.dbMiddleware, tipoPersona_controller_1.tipoPersonaController.deleteTipoPersona);
//# sourceMappingURL=tipoPersona.routes.js.map