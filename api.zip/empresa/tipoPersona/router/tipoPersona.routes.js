"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tipoPersonaRoute = void 0;
const express_1 = require("express");
const tipoPersona_controller_1 = require("../controller/tipoPersona.controller");
exports.tipoPersonaRoute = (0, express_1.Router)();
exports.tipoPersonaRoute.get('/', tipoPersona_controller_1.tipoPersonaController.findTipoPersona);
exports.tipoPersonaRoute.post('/create', tipoPersona_controller_1.tipoPersonaController.createTipoPersona);
exports.tipoPersonaRoute.put('/update', tipoPersona_controller_1.tipoPersonaController.updateTipoPersona);
exports.tipoPersonaRoute.delete('/delete/:tipoPersonaId', tipoPersona_controller_1.tipoPersonaController.deleteTipoPersona);
//# sourceMappingURL=tipoPersona.routes.js.map