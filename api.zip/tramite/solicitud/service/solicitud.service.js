"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.solicitudService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class SolicitudService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SolicitudService();
        return this.instance;
    }
    createTransaction(solicitud, dataSource, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const solicitudEntity = dataSource.getRepository(entities_1.SolicitudMPVModel).create(solicitud);
                const response = yield queryRunner.manager.save(solicitudEntity);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                (0, log_helper_1.logError)(error, 'createSede');
                throw error;
            }
        });
    }
    findOne(solicitudId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const solicitud = yield dataSource.getRepository(entities_1.SolicitudMPVModel).findOne({
                    where: {
                        solicitudId
                    }
                });
                return solicitud;
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                throw error;
            }
        });
    }
}
exports.solicitudService = SolicitudService.getInstance();
//# sourceMappingURL=solicitud.service.js.map