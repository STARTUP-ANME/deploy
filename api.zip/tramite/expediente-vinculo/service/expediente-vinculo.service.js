"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteVinculadoService = void 0;
const log_helper_1 = require("../../../core/helpers/log.helper");
const enum_1 = require("../../../core/enum");
const entities_1 = require("entities");
const expediente_service_1 = require("../../expediente/service/expediente.service");
const procesoTramite_service_1 = require("../../procesoTramite/service/procesoTramite.service");
class ExpedienteVinculadoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ExpedienteVinculadoService();
        return this.instance;
    }
    find(expedienteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.ExpedienteVinculadoModel).find({
                    where: {
                        expedienteId
                    },
                    relations: {
                        expediente: {
                            remitente: true
                        }
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    save(expedienteVinculados, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = dataSource.createQueryRunner();
            yield queryRunner.connect();
            try {
                yield queryRunner.startTransaction();
                const expedienteVinculadoEntity = queryRunner.manager.create(entities_1.ExpedienteVinculadoModel, expedienteVinculados);
                yield queryRunner.manager.save(expedienteVinculadoEntity);
                //! Obtenmos el identificador del padre del vinculado y asignamos el valor de [viculados]
                const procesoTramiteId = expedienteVinculados[0].parentId;
                yield procesoTramite_service_1.procesoTramiteService.updateHasLinks(procesoTramiteId, queryRunner);
                yield Promise.all(expedienteVinculados.map(vinculado => expediente_service_1.expedienteService.changeState(vinculado.vinculoId, enum_1.EstadosTramite.Vinculado, queryRunner)));
                yield Promise.all(expedienteVinculados.map(vinculado => procesoTramite_service_1.procesoTramiteService.updateEstado(vinculado.procesoId, enum_1.EstadosTramite.Vinculado, queryRunner)));
                yield queryRunner.commitTransaction();
            }
            catch (error) {
                yield queryRunner.rollbackTransaction();
                throw error;
            }
            finally {
                yield queryRunner.release();
            }
        });
    }
}
exports.expedienteVinculadoService = ExpedienteVinculadoService.getInstance();
//# sourceMappingURL=expediente-vinculo.service.js.map