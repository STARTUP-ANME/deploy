"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteVinculadoRoute = void 0;
const express_1 = require("express");
const expediente_vinculo_controller_1 = require("../controller/expediente-vinculo.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.expedienteVinculadoRoute = (0, express_1.Router)();
exports.expedienteVinculadoRoute.get('/', db_midleware_1.dbMiddleware, expediente_vinculo_controller_1.expedienteVinculadoController.find);
exports.expedienteVinculadoRoute.post('/', db_midleware_1.dbMiddleware, expediente_vinculo_controller_1.expedienteVinculadoController.save);
//# sourceMappingURL=expediente-vinculo.routes.js.map