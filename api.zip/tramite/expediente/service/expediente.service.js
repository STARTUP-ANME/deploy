"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const transacction_handler_1 = require("../../../core/helpers/transacction.handler");
const archivoAdjunto_service_1 = require("../../archivoAdjunto/service/archivoAdjunto.service");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const correlativo_service_1 = require("../../correlativo/service/correlativo.service");
const enum_1 = require("../../../core/enum");
const persona_service_1 = require("../../persona/service/persona.service");
class ExpedienteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ExpedienteService();
        return this.instance;
    }
    findExpediente(expedienteFilter, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = dataSource.getRepository(entities_1.ExpedienteModel).createQueryBuilder('expediente')
                    .leftJoinAndSelect('expediente.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.estado', 'estado')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .where('expediente.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('expediente.tipoExpedienteId = :tipoExpedienteId', { tipoExpedienteId: enum_1.TipoExpediente.Externo });
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaInicio) && (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaFin)) {
                    queryBuilder.andWhere(`DATE(expediente.fechaRegistro AT TIME ZONE 'America/Lima') BETWEEN :fechaInicio AND :fechaFin`, {
                        fechaInicio: expedienteFilter.fechaInicio,
                        fechaFin: expedienteFilter.fechaFin
                    });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.estadoId) > 0) {
                    queryBuilder.andWhere("expediente.estadoId = :estadoId", { estadoId: expedienteFilter.estadoId });
                }
                if (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.numero) {
                    queryBuilder.andWhere("expediente.nroDocumento = :nroDocumento", { nroDocumento: expedienteFilter.numero });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.origenId) > 0) {
                    queryBuilder.andWhere("expediente.origenId = :origenId", { origenId: expedienteFilter.origenId });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.remitenteId) > 0) {
                    queryBuilder.andWhere("expediente.remitenteId = :remitenteId", { remitenteId: expedienteFilter.remitenteId });
                }
                if (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.procedimientoId) {
                    queryBuilder.andWhere("expediente.procedimientoId = :procedimientoId", { procedimientoId: expedienteFilter.procedimientoId });
                    queryBuilder.andWhere("expediente.expedienteId != :expedienteId", { expedienteId: expedienteFilter.expedienteId });
                    queryBuilder.andWhere("expediente.estadoId != :estadoId", { estadoId: enum_1.EstadosTramite.Finalizado });
                }
                queryBuilder.orderBy("expediente.expedienteId", 'DESC');
                return yield queryBuilder.getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    /**
     * - busqueda por tipo de expediente y nro de docuemtno
     */
    findByTypeExpediente(fechaInicio, fechaFin, tipoExpedienteId, nroDocumento, unidadOrganicaId, personaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = dataSource.getRepository(entities_1.ExpedienteModel).createQueryBuilder('expediente')
                    .leftJoinAndSelect('expediente.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.estado', 'estado')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .where('expediente.audAnulado = :audAnulado', { audAnulado: '0' });
                if ((nroDocumento === '' || !nroDocumento) && fechaInicio && fechaFin && parseInt(personaId.toString()) === 0) {
                    queryBuilder.andWhere(`DATE(expediente.fechaRegistro AT TIME ZONE 'America/Lima') BETWEEN :fechaInicio AND :fechaFin`, {
                        fechaInicio: fechaInicio,
                        fechaFin: fechaFin
                    });
                }
                if (nroDocumento) {
                    queryBuilder.andWhere('expediente.nroDocumento LIKE :nroDocumento', { nroDocumento: `%${nroDocumento}%` });
                }
                if (parseInt(personaId.toString()) > 0) {
                    queryBuilder.andWhere('expediente.remitenteId = :remitenteId', { remitenteId: personaId });
                }
                // queryBuilder.andWhere("expediente.origenId = :origenId", { origenId: unidadOrganicaId })
                queryBuilder.andWhere("expediente.tipoExpedienteId = :tipoExpedienteId", { tipoExpedienteId: tipoExpedienteId })
                    .orderBy("expediente.expedienteId", 'ASC');
                return yield queryBuilder.getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
            }
        });
    }
    findOneExpediente(expedienteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteModel).findOne({
                    where: {
                        expedienteId,
                        audAnulado: '0',
                    },
                    relations: {
                        tipoDocumento: true,
                        remitente: true,
                        estado: true,
                        prioridad: true,
                        empresa: true,
                        origen: true,
                        archivoAdjuntos: true,
                        procedimiento: true,
                        representante: true,
                        usuario: {
                            persona: true
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    saveExpedienteTrans(expediente, archivoAdjuntos, persona, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield (0, transacction_handler_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                const savedExpediente = yield this.saveExpediente(expediente, queryRunner);
                if ((archivoAdjuntos === null || archivoAdjuntos === void 0 ? void 0 : archivoAdjuntos.length) > 0) {
                    const _archivoAdjuntos = [...archivoAdjuntos].map(p => (Object.assign(Object.assign({}, p), { expedienteId: expediente.expedienteId > 0 ? expediente.expedienteId : savedExpediente.expedienteId })));
                    yield Promise.all(_archivoAdjuntos.map(permiso => archivoAdjunto_service_1.archivoAdjuntoService.createArchivoAdjunto(permiso, queryRunner)));
                }
                yield persona_service_1.personaService.updatePersonaBasic(persona, queryRunner);
                if (!(expediente === null || expediente === void 0 ? void 0 : expediente.expedienteId)) {
                    yield correlativo_service_1.correlativoService.incrementCorrelativo(enum_1.TipoExpediente.Externo, expediente.anio, queryRunner);
                }
                if (!savedExpediente) {
                    throw new Error("No guardadi");
                }
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_EXPEDIENTE, data: savedExpediente };
            }));
            return result;
        });
    }
    saveMasiveExpediente(expedientes, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.transaction((transactionalEntityManager) => __awaiter(this, void 0, void 0, function* () {
                    const savedExpedientes = yield transactionalEntityManager.save(entities_1.ExpedienteModel, expedientes);
                    for (const element of savedExpedientes) {
                        if (element.expedienteId) {
                            yield transactionalEntityManager.increment(entities_1.CorrelativoModel, { tipoExpedienteId: enum_1.TipoExpediente.Externo, anio: element.anio }, 'correlativo', 1);
                        }
                    }
                    return savedExpedientes;
                }));
            }
            catch (error) {
                log_helper_1.logger.error(error, 'saveMasiveExpedienteTransaction');
                return null;
            }
        });
    }
    saveExpediente(expediente, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _expediente = queryRunner.manager.create(entities_1.ExpedienteModel, expediente);
                return yield queryRunner.manager.save(_expediente);
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                (0, log_helper_1.logError)(error, 'createExpediente');
                throw error;
            }
        });
    }
    changeState(expedienteId, estadoId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.update(entities_1.ExpedienteModel, { expedienteId }, { estadoId });
            }
            catch (error) {
                (0, log_helper_1.logError)(error, 'createExpediente');
                throw error;
            }
        });
    }
    restart(expedienteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteModel).update({ expedienteId }, {
                    estadoId: enum_1.EstadosTramite.Registrado,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteExpediente(expedienteId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteModel).update({ expedienteId: expedienteId }, {
                    estadoId: enum_1.EstadosTramite.Anulado
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    userExistExpediente(usuarioId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteModel).exists({
                    where: {
                        usuarioId
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.expedienteService = ExpedienteService.getInstance();
//# sourceMappingURL=expediente.service.js.map