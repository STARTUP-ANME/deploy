"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteRoute = void 0;
const express_1 = require("express");
const expediente_controller_1 = require("../controller/expediente.controller");
exports.expedienteRoute = (0, express_1.Router)();
exports.expedienteRoute.post('/all', expediente_controller_1.expedienteController.findExpediente);
exports.expedienteRoute.get('/consulta', expediente_controller_1.expedienteController.findByTypeExpediente);
exports.expedienteRoute.get('/one/:expedienteId', expediente_controller_1.expedienteController.findOneExpediente);
exports.expedienteRoute.post('/', expediente_controller_1.expedienteController.saveExpediente);
exports.expedienteRoute.post('/masive', expediente_controller_1.expedienteController.saveMasiveExpediente);
exports.expedienteRoute.post('/restart', expediente_controller_1.expedienteController.restart);
exports.expedienteRoute.delete('/:expedienteId', expediente_controller_1.expedienteController.deleteExpediente);
//# sourceMappingURL=expediente.routes.js.map