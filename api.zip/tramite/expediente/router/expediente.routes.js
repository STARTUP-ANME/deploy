"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteRoute = void 0;
const express_1 = require("express");
const expediente_controller_1 = require("../controller/expediente.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.expedienteRoute = (0, express_1.Router)();
exports.expedienteRoute.post('/all', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findExpediente);
exports.expedienteRoute.get('/consulta', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findByTypeExpediente);
exports.expedienteRoute.get('/one/:expedienteId', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findOneExpediente);
exports.expedienteRoute.post('/', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.saveExpediente);
exports.expedienteRoute.post('/masive', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.saveMasiveExpediente);
exports.expedienteRoute.post('/restart', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.restart);
exports.expedienteRoute.delete('/:expedienteId', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.deleteExpediente);
//# sourceMappingURL=expediente.routes.js.map