"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteRoute = void 0;
const express_1 = require("express");
const expediente_controller_1 = require("../controller/expediente.controller");
exports.expedienteRoute = (0, express_1.Router)();
exports.expedienteRoute.get('/', expediente_controller_1.expedienteController.findExpediente);
exports.expedienteRoute.post('/', expediente_controller_1.expedienteController.saveExpediente);
exports.expedienteRoute.put('/delete/:expedienteId', expediente_controller_1.expedienteController.deleteExpediente);
//# sourceMappingURL=expediente.routes.js.map