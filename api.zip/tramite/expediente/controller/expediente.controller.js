"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteController = void 0;
const http_status_codes_1 = require("http-status-codes");
const expediente_service_1 = require("../service/expediente.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class ExpedienteController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ExpedienteController();
        return this.instance;
    }
    findExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const expedienteFilter = req.body;
                const response = yield expediente_service_1.expedienteService.findExpediente(expedienteFilter);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findOneExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const expedienteId = req.params.expedienteId;
                const response = yield expediente_service_1.expedienteService.findOneExpediente(expedienteId);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    saveExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { expediente, archivoAdjuntos, persona } = req.body;
                const response = yield expediente_service_1.expedienteService.saveExpedienteTrans(expediente, archivoAdjuntos, persona);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    saveMasiveExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { expedientes } = req.body;
                const response = yield expediente_service_1.expedienteService.saveMasiveExpediente(expedientes);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_EXPEDIENTE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_CREATE_EXPEDIENTE });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    deleteExpediente(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { expedienteId } = req.params;
                const response = yield expediente_service_1.expedienteService.deleteExpediente(Number(expedienteId));
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_TIPO_EXPEDIENTE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_SEDE, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.expedienteController = ExpedienteController.getInstance();
//# sourceMappingURL=expediente.controller.js.map