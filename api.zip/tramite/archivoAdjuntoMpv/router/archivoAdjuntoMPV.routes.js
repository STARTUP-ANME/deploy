"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoMPVRoute = void 0;
const express_1 = require("express");
const archivoAdjuntoMPV_controller_1 = require("../controller/archivoAdjuntoMPV.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.archivoAdjuntoMPVRoute = (0, express_1.Router)();
exports.archivoAdjuntoMPVRoute.get('/:expedienteMPVId', db_midleware_1.dbMiddleware, archivoAdjuntoMPV_controller_1.archivoAdjuntoController.findArchivosAdjuntoMPV);
exports.archivoAdjuntoMPVRoute.delete('/:archivoExpedienteId', db_midleware_1.dbMiddleware, archivoAdjuntoMPV_controller_1.archivoAdjuntoController.deleteArchivosAdjuntoMPV);
//# sourceMappingURL=archivoAdjuntoMPV.routes.js.map