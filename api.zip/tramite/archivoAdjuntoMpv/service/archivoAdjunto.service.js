"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class ArchivoAdjuntoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ArchivoAdjuntoService();
        return this.instance;
    }
    findArchivosAdjuntoMPV(expedienteMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.ArchivoAdjuntoMPVModel).find({
                    where: {
                        expedienteMPVId: expedienteMPVId
                    },
                    relations: {
                        origen: true,
                        expedienteMpv: {
                            estado: true
                        }
                    },
                    select: {
                        expedienteMpv: {
                            expedienteMPVId: true,
                            estado: {
                                descripcion: true
                            }
                        }
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.error(`Error by findArchivoAdjunto mpv: ${error.message}`);
            }
        });
    }
    createArchivoAdjuntoMPV(archivoAdjuntoMPV, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _archivo = entities_1.ArchivoAdjuntoMPVModel.create(archivoAdjuntoMPV);
                return yield queryRunner.manager.save(_archivo);
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createArchivoAdjunto');
            }
        });
    }
    deleteArchivoAdjuntoMPV(archivoAdjuntoMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.ArchivoAdjuntoMPVModel).delete({ archivoAdjuntoMpvId: archivoAdjuntoMPVId });
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'deleteArchivoAdjunto');
            }
        });
    }
}
exports.archivoAdjuntoService = ArchivoAdjuntoService.getInstance();
//# sourceMappingURL=archivoAdjunto.service.js.map