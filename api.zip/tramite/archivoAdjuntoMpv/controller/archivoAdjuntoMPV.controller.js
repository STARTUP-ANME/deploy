"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const archivoAdjuntoMPV_service_1 = require("../service/archivoAdjuntoMPV.service");
class ArchivoAdjuntoController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ArchivoAdjuntoController();
        return this.instance;
    }
    findArchivosAdjuntoMPV(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const expedienteMPVId = req.params.expedienteMPVId;
                const response = yield archivoAdjuntoMPV_service_1.archivoAdjuntoMPVService.findArchivosAdjuntoMPV(expedienteMPVId, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    deleteArchivosAdjuntoMPV(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const archivoExpedienteId = req.params.archivoExpedienteId;
                const response = yield archivoAdjuntoMPV_service_1.archivoAdjuntoMPVService.deleteArchivoAdjuntoMPV(archivoExpedienteId, dataSource);
                if ((response === null || response === void 0 ? void 0 : response.affected) > 0) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ARCHIVO_ADJUNTO });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ARCHIVO_ADJUNTO });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
}
exports.archivoAdjuntoController = ArchivoAdjuntoController.getInstance();
//# sourceMappingURL=archivoAdjuntoMPV.controller.js.map