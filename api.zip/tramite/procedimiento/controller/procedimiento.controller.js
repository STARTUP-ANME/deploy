"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procedimientoController = void 0;
const http_status_codes_1 = require("http-status-codes");
const procedimiento_service_1 = require("../service/procedimiento.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class ProcedimientoController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcedimientoController();
        return this.instance;
    }
    findProcedimiento(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const response = yield procedimiento_service_1.procedimientoService.findProcedimiento(dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findByTipoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { tipoTramiteId } = req.query;
                const dataSource = req['dbConnection'];
                const response = yield procedimiento_service_1.procedimientoService.findByTipoTramite(tipoTramiteId, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findOneProcedimiento(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procedimientoId } = req.query;
                const response = yield procedimiento_service_1.procedimientoService.findOneProcedimiento(Number(procedimientoId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findProcedimientoForUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { unidadOrganicaId } = req.query;
                const response = yield procedimiento_service_1.procedimientoService.findProcedimientoForUnidad(Number(unidadOrganicaId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createProcedimiento(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procedimiento } = req.body;
                const response = yield procedimiento_service_1.procedimientoService.createProcedimiento(procedimiento, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_PROCEDIMIENTO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateProcedimiento(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procedimiento } = req.body;
                const response = yield procedimiento_service_1.procedimientoService.updateProcedimiento(procedimiento, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_PROCEDIMIENTO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteProcedimiento(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procedimientoId } = req.params;
                const response = yield procedimiento_service_1.procedimientoService.deleteProcedimiento(Number(procedimientoId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_PROCEDIMIENTO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.procedimientoController = ProcedimientoController.getInstance();
//# sourceMappingURL=procedimiento.controller.js.map