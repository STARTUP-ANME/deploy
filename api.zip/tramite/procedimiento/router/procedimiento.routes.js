"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procedimientoRoute = void 0;
const express_1 = require("express");
const procedimiento_controller_1 = require("../controller/procedimiento.controller");
exports.procedimientoRoute = (0, express_1.Router)();
exports.procedimientoRoute.get('/', procedimiento_controller_1.procedimientoController.findProcedimiento);
exports.procedimientoRoute.get('/one', procedimiento_controller_1.procedimientoController.findOneProcedimiento);
exports.procedimientoRoute.get('/unidad', procedimiento_controller_1.procedimientoController.findProcedimientoForUnidad);
exports.procedimientoRoute.post('/create', procedimiento_controller_1.procedimientoController.createProcedimiento);
exports.procedimientoRoute.put('/update', procedimiento_controller_1.procedimientoController.updateProcedimiento);
exports.procedimientoRoute.put('/delete/:procedimientoId', procedimiento_controller_1.procedimientoController.deleteProcedimiento);
//# sourceMappingURL=procedimiento.routes.js.map