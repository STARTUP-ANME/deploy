"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procedimientoRoute = void 0;
const express_1 = require("express");
const procedimiento_controller_1 = require("../controller/procedimiento.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.procedimientoRoute = (0, express_1.Router)();
exports.procedimientoRoute.get('/', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.findProcedimiento);
exports.procedimientoRoute.get('/one', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.findOneProcedimiento);
exports.procedimientoRoute.get('/unidad', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.findProcedimientoForUnidad);
exports.procedimientoRoute.post('/create', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.createProcedimiento);
exports.procedimientoRoute.put('/update', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.updateProcedimiento);
exports.procedimientoRoute.put('/delete/:procedimientoId', db_midleware_1.dbMiddleware, procedimiento_controller_1.procedimientoController.deleteProcedimiento);
//# sourceMappingURL=procedimiento.routes.js.map