"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procedimientoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class ProcedimientoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcedimientoService();
        return this.instance;
    }
    findProcedimiento(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        tipoTramite: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneProcedimiento(procedimientoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).findOne({
                    where: {
                        procedimientoId: procedimientoId,
                        audAnulado: '0'
                    },
                    relations: {
                        unidadOrganica: true,
                        tipoTramite: true
                    },
                    select: {
                        unidadOrganica: {
                            unidadOrganicaId: true,
                            nombre: true
                        },
                        tipoTramite: {
                            tipoTramiteId: true,
                            descripcion: true
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findProcedimientoForUnidad(unidadOrganicaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).find({
                    where: Object.assign(Object.assign({}, (unidadOrganicaId !== 0 && { unidadOrganicaId })), { audAnulado: '0' }),
                    relations: {
                        unidadOrganica: true,
                        tipoTramite: true
                    },
                    select: {
                        unidadOrganica: {
                            unidadOrganicaId: true,
                            nombre: true
                        },
                        tipoTramite: {
                            tipoTramiteId: true,
                            descripcion: true
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createProcedimiento(procedimiento, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).save(procedimiento);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createProcedimiento');
            }
        });
    }
    updateProcedimiento(procedimiento, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).update({ procedimientoId: procedimiento.procedimientoId }, {
                    descripcion: procedimiento.descripcion,
                    plazo: procedimiento.plazo,
                    unidadOrganicaId: procedimiento.unidadOrganicaId,
                    tipoTramiteId: procedimiento.tipoTramiteId
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteProcedimiento(procedimientoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ProcedimientoModel).update({ procedimientoId: procedimientoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.procedimientoService = ProcedimientoService.getInstance();
//# sourceMappingURL=procedimiento.service.js.map