"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const enum_1 = require("../../../core/enum");
const typeorm_1 = require("typeorm");
const archivoAdjunto_service_1 = require("../../archivoAdjunto/service/archivoAdjunto.service");
class ProcesoTramiteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcesoTramiteService();
        return this.instance;
    }
    findProcesoTramite(expedienteId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.find({
                    where: {
                        audAnulado: '0',
                        expedienteId,
                    },
                    relations: {
                        expediente: true,
                        origen: true,
                        destino: true,
                        estado: true,
                        usuarioCrea: {
                            persona: true
                        },
                        usuarioRecibe: true,
                        tipoDocumento: true,
                        referencia: true
                    },
                    order: {
                        procesoTramiteId: 'ASC'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneProcesoTramite(procesoTramiteId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.createQueryBuilder('procesoTramite')
                    .leftJoinAndSelect('procesoTramite.expediente', 'expediente')
                    .leftJoinAndSelect('procesoTramite.origen', 'origen')
                    .leftJoinAndSelect('procesoTramite.destino', 'destino')
                    .leftJoinAndSelect('procesoTramite.estado', 'estado')
                    .leftJoinAndSelect('procesoTramite.usuarioCrea', 'usuarioCrea')
                    .leftJoinAndSelect('procesoTramite.usuarioRecibe', 'usuarioRecibe')
                    .leftJoinAndSelect('procesoTramite.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('procesoTramite.referencia', 'referencia')
                    .leftJoinAndSelect('usuarioCrea.persona', 'personaCrea') // Alias cambiado a personaCrea
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .leftJoinAndSelect('expediente.origen', 'origenExpediente')
                    .leftJoinAndSelect('expediente.tipoDocumento', 'tipoDocumentoExpediente')
                    .leftJoinAndSelect('destino.encargadoUO', 'encargadoUO')
                    .leftJoinAndSelect('encargadoUO.persona', 'personaEncargado') // Alias cambiado a personaEncargado
                    .leftJoinAndSelect('origen.encargadoUO', 'encargadoUOOrigen')
                    .leftJoinAndSelect('encargadoUOOrigen.persona', 'personaOrigen') // Alias cambiado a personaEncargado
                    .leftJoinAndSelect('expediente.tipoExpediente', 'tipoExpediente')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere("procesoTramite.procesoTramiteId = :procesoTramiteId", {
                    procesoTramiteId
                })
                    .getOne();
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findSatateProcesoTramite(estado, fRegistro) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.createQueryBuilder('procesoTramite')
                    .leftJoinAndSelect('procesoTramite.expediente', 'expediente')
                    .leftJoinAndSelect('procesoTramite.origen', 'origen')
                    .leftJoinAndSelect('procesoTramite.destino', 'destino')
                    .leftJoinAndSelect('procesoTramite.estado', 'estado')
                    .leftJoinAndSelect('procesoTramite.usuarioCrea', 'usuarioCrea')
                    .leftJoinAndSelect('procesoTramite.usuarioRecibe', 'usuarioRecibe')
                    .leftJoinAndSelect('procesoTramite.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('procesoTramite.referencia', 'referencia')
                    .leftJoinAndSelect('usuarioCrea.persona', 'persona')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId = :estadoId', { estadoId: estado })
                    .andWhere("DATE(procesoTramite.fRegistro AT TIME ZONE :timezone) = :targetDate", {
                    timezone: "America/Lima",
                    targetDate: fRegistro,
                })
                    .getMany();
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findProcesoTramiteByUOrganica(typeTab, unidadOrganicaId, tipoExpedienteId, nro) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = entities_1.ProcesoTramiteModel.createQueryBuilder('procesoTramite')
                    .leftJoinAndSelect('procesoTramite.expediente', 'expediente')
                    .leftJoinAndSelect('procesoTramite.origen', 'origen')
                    .leftJoinAndSelect('procesoTramite.destino', 'destino')
                    .leftJoinAndSelect('procesoTramite.estado', 'estado')
                    .leftJoinAndSelect('procesoTramite.usuarioCrea', 'usuarioCrea')
                    .leftJoinAndSelect('procesoTramite.usuarioRecibe', 'usuarioRecibe')
                    .leftJoinAndSelect('procesoTramite.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('procesoTramite.referencia', 'referencia')
                    .leftJoinAndSelect('usuarioCrea.persona', 'persona')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .leftJoinAndSelect('expediente.tipoExpediente', 'tipoExpediente')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' });
                if (typeTab === enum_1.TypeTab.Recepcionado) {
                    console.log("RECEPCIONADO");
                    queryBuilder.andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                        .andWhere('procesoTramite.usuarioRecibeId IS NOT NULL')
                        .andWhere('(procesoTramite.isComplete IS NULL OR procesoTramite.isComplete = FALSE)')
                        .andWhere('procesoTramite.destinoId = :destinoId', {
                        destinoId: unidadOrganicaId
                    });
                }
                if (typeTab === enum_1.TypeTab.PorRecibir) {
                    console.log("POR RECIBIR  :::: ");
                    queryBuilder.andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                        .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                        .andWhere('procesoTramite.tipoEnvioId = 1')
                        .andWhere('procesoTramite.destinoId = :destinoId', {
                        destinoId: unidadOrganicaId
                    });
                }
                if (typeTab === enum_1.TypeTab.ExpedienteAtendido) {
                    console.log("EXPEDIENTE ATENDIDO", unidadOrganicaId);
                    queryBuilder.andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                        .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                        .andWhere('procesoTramite.isComplete IS NULL')
                        .andWhere('procesoTramite.origenId = :origenId', {
                        origenId: unidadOrganicaId
                    });
                    // queryBuilder.andWhere(new Brackets(qb=>{
                    //     qb.where('procesoTramite.estadoId = :estadoId',{estadoId: EstadosTramite.Enviado})
                    //     .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                    //     .andWhere('procesoTramite.isComplete IS NULL')
                    // }));
                }
                if (typeTab === enum_1.TypeTab.Copias) {
                    console.log("COPIASSSS", unidadOrganicaId);
                    queryBuilder.andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado] })
                        .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                        .andWhere('procesoTramite.isComplete IS NULL')
                        .andWhere('procesoTramite.tipoEnvioId = 2')
                        .andWhere('procesoTramite.destinoId = :destinoId', {
                        destinoId: unidadOrganicaId
                    });
                }
                console.log(tipoExpedienteId);
                queryBuilder.andWhere('expediente.tipoExpedienteId = :tipoExpedienteId', { tipoExpedienteId });
                if (nro) {
                    queryBuilder.andWhere('expediente.nroDocumento LIKE :nroDocumento', { nroDocumento: `%${nro}%` });
                }
                return yield queryBuilder
                    .orderBy('procesoTramite.procesoTramiteId', 'DESC')
                    .getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createProcesoTramite(procesoTramites, expedienteId, archivoAdjuntos) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = entities_1.AppDataSource.createQueryRunner();
            // Iniciamos la transacción
            yield queryRunner.startTransaction();
            try {
                // Guardamos los procesos dentro de la transacción
                const response = yield queryRunner.manager.save(entities_1.ProcesoTramiteModel, procesoTramites);
                // Modificamos un valor en otra tabla dentro de la misma transacción
                yield queryRunner.manager.update(entities_1.ExpedienteModel, { expedienteId }, { estadoId: procesoTramites[0].estadoId });
                if (procesoTramites && procesoTramites.length > 0) {
                    const estadoId = procesoTramites[0].estadoId;
                    const procesoTramiteId = procesoTramites[0].referenciaId;
                    if (estadoId !== enum_1.EstadosTramite.Enviado) {
                        yield queryRunner.manager.update(entities_1.ProcesoTramiteModel, { procesoTramiteId }, { isComplete: true });
                    }
                }
                if ((archivoAdjuntos === null || archivoAdjuntos === void 0 ? void 0 : archivoAdjuntos.length) > 0) {
                    const _archivoAdjuntos = archivoAdjuntos.map(p => (Object.assign(Object.assign({}, p), { expedienteId })));
                    // Ejecutamos las operaciones en paralelo para crear los archivos adjuntos
                    yield Promise.all(_archivoAdjuntos.map(permiso => archivoAdjunto_service_1.archivoAdjuntoService.createArchivoAdjunto(permiso, queryRunner)));
                }
                // Confirmamos la transacción
                yield queryRunner.commitTransaction();
                return response;
            }
            catch (error) {
                // En caso de error, revertimos los cambios
                yield queryRunner.rollbackTransaction();
                console.log("🚀 ~ ProcesoTramiteService ~ createProcesoTramite ~ error:", error);
                (0, log_helper_1.logError)(error, 'createProcesoTramite');
                throw error;
            }
            finally {
                // Liberamos el QueryRunner
                yield queryRunner.release();
            }
        });
    }
    updateProcesoTramite(procesoTramite) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.update({ procesoTramiteId: procesoTramite.procesoTramiteId }, {});
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    recepcionar(procesoTramites) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const updatePromises = procesoTramites.map(procesoTramite => entities_1.ProcesoTramiteModel.update({ procesoTramiteId: procesoTramite.procesoTramiteId }, {
                    fRecibido: procesoTramite.fRecibido,
                    usuarioRecibeId: procesoTramite.usuarioRecibeId,
                    // estadoId: EstadosTramite.Recepcionado
                }));
                const responses = yield Promise.all(updatePromises);
                return responses;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return { success: false, error };
            }
        });
    }
    anularEnvio(procesoTramiteId) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("🚀 ~ ProcesoTramiteService ~ anularEnvio ~ procesoTramiteId:", procesoTramiteId);
            const queryRunner = entities_1.AppDataSource.createQueryRunner();
            yield queryRunner.connect(); // Conectar al query runner
            yield queryRunner.startTransaction(); // Iniciar la transacción
            try {
                const procesoTramite = yield queryRunner.manager.findOne(entities_1.ProcesoTramiteModel, {
                    where: {
                        procesoTramiteId
                    }
                });
                if (procesoTramite && procesoTramite.referenciaId) {
                    const procesoTramiteRef = yield queryRunner.manager.findOne(entities_1.ProcesoTramiteModel, {
                        where: {
                            procesoTramiteId: procesoTramite.referenciaId
                        }
                    });
                    yield queryRunner.manager.update(entities_1.ExpedienteModel, {
                        expedienteId: procesoTramiteRef.expedienteId
                    }, {
                        estadoId: procesoTramiteRef.estadoId
                    });
                    yield queryRunner.manager.update(entities_1.ProcesoTramiteModel, {
                        procesoTramiteId: procesoTramiteRef.procesoTramiteId
                    }, {
                        isComplete: false
                    });
                    yield queryRunner.manager.delete(entities_1.ProcesoTramiteModel, { procesoTramiteId });
                }
                else {
                    yield queryRunner.manager.update(entities_1.ProcesoTramiteModel, {
                        procesoTramiteId: procesoTramite.procesoTramiteId
                    }, {
                        isComplete: false
                    });
                }
                yield queryRunner.commitTransaction();
            }
            catch (error) {
                log_helper_1.logger.error(error); // Revertir la transacción en caso de error
                yield queryRunner.rollbackTransaction();
                throw error;
            }
            finally {
                // Liberar el query runner
                yield queryRunner.release();
            }
        });
    }
    rechazar(rechazarProceso) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = entities_1.AppDataSource.createQueryRunner();
            yield queryRunner.connect(); // Conectar al query runner
            yield queryRunner.startTransaction(); // Iniciar la transacción
            try {
                for (const item of rechazarProceso) {
                    const { expedienteId, procesoTramiteId } = item;
                    const total = yield entities_1.ProcesoTramiteModel.count({
                        where: {
                            expedienteId
                        }
                    });
                    if (total === 1) {
                        yield queryRunner.manager.delete(entities_1.ProcesoTramiteModel, { expedienteId });
                        yield queryRunner.manager.update(entities_1.ExpedienteModel, { expedienteId }, {
                            estadoId: enum_1.EstadosTramite.Registrado
                        });
                    }
                    else {
                        yield queryRunner.manager.update(entities_1.ProcesoTramiteModel, { procesoTramiteId }, {
                            fRecibido: null,
                            isComplete: null,
                            usuarioRecibeId: null
                        });
                    }
                }
                yield queryRunner.commitTransaction();
            }
            catch (error) {
                console.error(error.message);
                log_helper_1.logger.error(error);
                // Revertir la transacción en caso de error
                yield queryRunner.rollbackTransaction();
            }
            finally {
                // Liberar el query runner
                yield queryRunner.release();
            }
        });
    }
    information(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("🚀 ~ ProcesoTramiteService ~ information ~ unidadOrganicaId:", unidadOrganicaId);
            try {
                const porRecibir = yield entities_1.ProcesoTramiteModel
                    .createQueryBuilder('procesoTramite')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                    .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                    .andWhere('procesoTramite.tipoEnvioId = 1')
                    .andWhere('procesoTramite.destinoId = :destinoId', {
                    destinoId: unidadOrganicaId
                })
                    .getCount();
                const recepcionados = yield entities_1.ProcesoTramiteModel
                    .createQueryBuilder('procesoTramite')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                    .andWhere('procesoTramite.usuarioRecibeId IS NOT NULL')
                    .andWhere('(procesoTramite.isComplete IS NULL OR procesoTramite.isComplete = FALSE)')
                    .andWhere('procesoTramite.destinoId = :destinoId', {
                    destinoId: unidadOrganicaId
                })
                    .getCount();
                const copias = yield entities_1.ProcesoTramiteModel
                    .createQueryBuilder('procesoTramite')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Derivado] })
                    .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                    .andWhere('procesoTramite.isComplete IS NULL')
                    .andWhere('procesoTramite.tipoEnvioId = 2')
                    .andWhere('procesoTramite.destinoId = :destinoId', {
                    destinoId: unidadOrganicaId
                })
                    .getCount();
                const atendidos = yield entities_1.ProcesoTramiteModel
                    .createQueryBuilder('procesoTramite')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId IN (:...estadoIds)', { estadoIds: [enum_1.EstadosTramite.Enviado, enum_1.EstadosTramite.Derivado, enum_1.EstadosTramite.Respuesta, enum_1.EstadosTramite.Observado, enum_1.EstadosTramite.Rechazado] })
                    .andWhere('procesoTramite.usuarioRecibeId IS NULL')
                    .andWhere('procesoTramite.isComplete IS NULL')
                    .andWhere('procesoTramite.origenId = :origenId', {
                    origenId: unidadOrganicaId
                })
                    .getCount();
                const [estados] = yield this.getEstados(unidadOrganicaId);
                const pendientes = estados.pendientes;
                const porVencer = estados.por_vencer;
                const vencidas = estados.vencidos;
                return {
                    porRecibir,
                    recepcionados,
                    copias,
                    atendidos,
                    pendientes,
                    porVencer,
                    vencidas
                };
            }
            catch (error) {
                console.log(error.message);
                log_helper_1.logger.error(error);
            }
        });
    }
    // Función para obtener estados
    getEstados(destinoId) {
        return __awaiter(this, void 0, void 0, function* () {
            const estadosQuery = `
        SELECT 
        COUNT(CASE 
            WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') > DATE(NOW() AT TIME ZONE 'America/Lima') + INTERVAL '3 day' THEN 1
        END) AS pendientes,
        COUNT(CASE 
            WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') 
                BETWEEN DATE(NOW() AT TIME ZONE 'America/Lima') 
                AND DATE(NOW() AT TIME ZONE 'America/Lima') + INTERVAL '3 day' THEN 1
        END) AS por_vencer,
        COUNT(CASE 
            WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') < DATE(NOW() AT TIME ZONE 'America/Lima') - INTERVAL '1 day' THEN 1
        END) AS vencidas
        FROM tramite.proceso_tramite pt
        INNER JOIN tramite.expediente e ON e."expedienteId" = pt."expedienteId"
        WHERE pt."destinoId" = $1
        AND pt."usuarioRecibeId" IS NOT NULL
        AND pt."isComplete" IS NULL;
    `;
            return yield entities_1.ProcesoTramiteModel.query(estadosQuery, [destinoId]);
        });
    }
    deleteProcesoTramite(expedienteId) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = entities_1.AppDataSource.createQueryRunner();
            yield queryRunner.connect(); // Conectar al query runner
            yield queryRunner.startTransaction(); // Iniciar la transacción
            try {
                // Actualizar ProcesoTramiteModel
                yield queryRunner.manager.update(entities_1.ProcesoTramiteModel, {
                    expedienteId,
                    referenciaId: null
                }, {
                    fRecibido: null,
                    usuarioRecibeId: null,
                    isComplete: false
                });
                // Eliminar ProcesoTramiteModel con referenciaId no nulo
                const response = yield queryRunner.manager.delete(entities_1.ProcesoTramiteModel, {
                    expedienteId,
                    referenciaId: (0, typeorm_1.Not)(null)
                });
                console.log(response);
                // Confirmar la transacción
                yield queryRunner.commitTransaction();
                return response;
            }
            catch (error) {
                console.error(error.message);
                log_helper_1.logger.error(error);
                // Revertir la transacción en caso de error
                yield queryRunner.rollbackTransaction();
            }
            finally {
                // Liberar el query runner
                yield queryRunner.release();
            }
        });
    }
}
exports.procesoTramiteService = ProcesoTramiteService.getInstance();
//# sourceMappingURL=procesoTramite.service.js.map