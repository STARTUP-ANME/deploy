"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const enum_1 = require("../../../core/enum");
class ProcesoTramiteService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcesoTramiteService();
        return this.instance;
    }
    findProcesoTramite(expedienteId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.find({
                    where: {
                        audAnulado: '0',
                        expedienteId,
                    },
                    relations: {
                        expediente: true,
                        origen: true,
                        destino: true,
                        estado: true,
                        usuarioCrea: {
                            persona: true
                        },
                        usuarioRecibe: true,
                        tipoDocumento: true,
                        referencia: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findSatateProcesoTramite(estado, fRegistro) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("🚀 ~ ProcesoTramiteService ~ findSatateProcesoTramite ~ fRegistro:", fRegistro);
            try {
                const response = yield entities_1.ProcesoTramiteModel.createQueryBuilder('procesoTramite')
                    .leftJoinAndSelect('procesoTramite.expediente', 'expediente')
                    .leftJoinAndSelect('procesoTramite.origen', 'origen')
                    .leftJoinAndSelect('procesoTramite.destino', 'destino')
                    .leftJoinAndSelect('procesoTramite.estado', 'estado')
                    .leftJoinAndSelect('procesoTramite.usuarioCrea', 'usuarioCrea')
                    .leftJoinAndSelect('procesoTramite.usuarioRecibe', 'usuarioRecibe')
                    .leftJoinAndSelect('procesoTramite.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('procesoTramite.referencia', 'referencia')
                    .leftJoinAndSelect('usuarioCrea.persona', 'persona')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .where('procesoTramite.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('procesoTramite.estadoId = :estadoId', { estadoId: estado })
                    .andWhere("DATE(procesoTramite.fRegistro AT TIME ZONE :timezone) = :targetDate", {
                    timezone: "America/Lima",
                    targetDate: fRegistro,
                })
                    .getMany();
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createProcesoTramite(procesoTramites, expedienteId) {
        return __awaiter(this, void 0, void 0, function* () {
            yield entities_1.AppDataSource.transaction((transactionalEntityManager) => __awaiter(this, void 0, void 0, function* () {
                try {
                    // Guardamos los procesos dentro de la transacción
                    const response = yield transactionalEntityManager.save(entities_1.ProcesoTramiteModel, procesoTramites);
                    // Modificamos un valor en otra tabla dentro de la misma transacción
                    yield transactionalEntityManager.update(entities_1.ExpedienteModel, { expedienteId }, { estadoId: enum_1.EstadosTramite.Enviado });
                    return response;
                }
                catch (error) {
                    (0, log_helper_1.logError)(error, 'createProcesoTramite');
                }
            }));
        });
    }
    updateProcesoTramite(procesoTramite) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.update({ procesoTramiteId: procesoTramite.procesoTramiteId }, {});
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteProcesoTramite(procesoTramiteId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.ProcesoTramiteModel.update({ procesoTramiteId: procesoTramiteId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.procesoTramiteService = ProcesoTramiteService.getInstance();
//# sourceMappingURL=procesoTramite.service.js.map