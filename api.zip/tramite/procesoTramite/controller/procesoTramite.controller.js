"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteController = void 0;
const http_status_codes_1 = require("http-status-codes");
const procesoTramite_service_1 = require("../service/procesoTramite.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class ProcesoTramiteController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcesoTramiteController();
        return this.instance;
    }
    findProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.query;
                const response = yield procesoTramite_service_1.procesoTramiteService.findProcesoTramite(Number(expedienteId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    findOneProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramiteId } = req.query;
                const response = yield procesoTramite_service_1.procesoTramiteService.findOneProcesoTramite(Number(procesoTramiteId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    findProcesoTramiteByUOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { typeTab, unidadOrganicaId, tipoExpedienteId, nro } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.findProcesoTramiteByUOrganica(typeTab, unidadOrganicaId, tipoExpedienteId, nro, dataSource);
                console.log(response.length > 0 ? response[0].procesoTramiteId : 0);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    information(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const { unidadOrganicaId } = req.query;
            const response = yield procesoTramite_service_1.procesoTramiteService.information(unidadOrganicaId, dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(response);
        });
    }
    createProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramites, expedienteId, archivoAdjuntos } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.createProcesoTramite(procesoTramites, expedienteId, archivoAdjuntos, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_REQUISITOS, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramite } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.updateProcesoTramite(procesoTramite, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_REQUISITOS, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    recepcionar(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramites } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.recepcionar(procesoTramites, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_REQUISITOS, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: 'Error en recepcionar' });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    rechazar(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { rechazarProceso } = req.body;
                yield procesoTramite_service_1.procesoTramiteService.rechazar(rechazarProceso, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'Rechazado correctamente' });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    anularEnvio(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { procesoTramiteId } = req.body;
                yield procesoTramite_service_1.procesoTramiteService.anularEnvio(procesoTramiteId, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'Anulado' });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { expedienteId } = req.params;
                const response = yield procesoTramite_service_1.procesoTramiteService.deleteProcesoTramite(Number(expedienteId), dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_TIPO_EXPEDIENTE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_REQUISITOS });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.procesoTramiteController = ProcesoTramiteController.getInstance();
//# sourceMappingURL=procesoTramite.controller.js.map