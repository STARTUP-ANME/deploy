"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteController = void 0;
const http_status_codes_1 = require("http-status-codes");
const procesoTramite_service_1 = require("../service/procesoTramite.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class ProcesoTramiteController {
    static getInstance() {
        if (!this.instance)
            this.instance = new ProcesoTramiteController();
        return this.instance;
    }
    findProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { expedienteId } = req.query;
                const response = yield procesoTramite_service_1.procesoTramiteService.findProcesoTramite(Number(expedienteId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    createProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { procesoTramites, expedienteId } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.createProcesoTramite(procesoTramites, expedienteId);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_REQUISITOS, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { procesoTramite } = req.body;
                const response = yield procesoTramite_service_1.procesoTramiteService.updateProcesoTramite(procesoTramite);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_REQUISITOS, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteProcesoTramite(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { procesoTramiteId } = req.params;
                const response = yield procesoTramite_service_1.procesoTramiteService.deleteProcesoTramite(Number(procesoTramiteId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_REQUISITOS, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.procesoTramiteController = ProcesoTramiteController.getInstance();
//# sourceMappingURL=procesoTramite.controller.js.map