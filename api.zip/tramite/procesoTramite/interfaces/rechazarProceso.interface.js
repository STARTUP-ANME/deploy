"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=rechazarProceso.interface.js.map