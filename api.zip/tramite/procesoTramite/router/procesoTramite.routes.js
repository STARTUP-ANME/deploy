"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteRoute = void 0;
const express_1 = require("express");
const procesoTramite_controller_1 = require("../controller/procesoTramite.controller");
exports.procesoTramiteRoute = (0, express_1.Router)();
exports.procesoTramiteRoute.get('/', procesoTramite_controller_1.procesoTramiteController.findProcesoTramite);
exports.procesoTramiteRoute.get('/one', procesoTramite_controller_1.procesoTramiteController.findOneProcesoTramite);
exports.procesoTramiteRoute.post('/by_uorganica', procesoTramite_controller_1.procesoTramiteController.findProcesoTramiteByUOrganica);
exports.procesoTramiteRoute.post('/', procesoTramite_controller_1.procesoTramiteController.createProcesoTramite);
exports.procesoTramiteRoute.post('/recepcionar', procesoTramite_controller_1.procesoTramiteController.recepcionar);
exports.procesoTramiteRoute.post('/rechazar', procesoTramite_controller_1.procesoTramiteController.rechazar);
exports.procesoTramiteRoute.post('/anular-envio', procesoTramite_controller_1.procesoTramiteController.anularEnvio);
exports.procesoTramiteRoute.get('/information', procesoTramite_controller_1.procesoTramiteController.information);
exports.procesoTramiteRoute.put('/', procesoTramite_controller_1.procesoTramiteController.updateProcesoTramite);
exports.procesoTramiteRoute.delete('/:expedienteId', procesoTramite_controller_1.procesoTramiteController.deleteProcesoTramite);
//# sourceMappingURL=procesoTramite.routes.js.map