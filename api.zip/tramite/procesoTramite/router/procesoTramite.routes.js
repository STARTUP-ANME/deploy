"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.procesoTramiteRoute = void 0;
const express_1 = require("express");
const procesoTramite_controller_1 = require("../controller/procesoTramite.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.procesoTramiteRoute = (0, express_1.Router)();
exports.procesoTramiteRoute.get('/', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.findProcesoTramite);
exports.procesoTramiteRoute.get('/one', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.findOneProcesoTramite);
exports.procesoTramiteRoute.post('/by_uorganica', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.findProcesoTramiteByUOrganica);
exports.procesoTramiteRoute.post('/', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.createProcesoTramite);
exports.procesoTramiteRoute.post('/recepcionar', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.recepcionar);
exports.procesoTramiteRoute.post('/rechazar', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.rechazar);
exports.procesoTramiteRoute.post('/anular-envio', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.anularEnvio);
exports.procesoTramiteRoute.get('/information', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.information);
exports.procesoTramiteRoute.put('/', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.updateProcesoTramite);
exports.procesoTramiteRoute.delete('/:expedienteId', db_midleware_1.dbMiddleware, procesoTramite_controller_1.procesoTramiteController.deleteProcesoTramite);
//# sourceMappingURL=procesoTramite.routes.js.map