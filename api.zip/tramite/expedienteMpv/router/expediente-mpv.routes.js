"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteMpvRoute = void 0;
const express_1 = require("express");
const expediente_mpv_controller_1 = require("../controller/expediente-mpv.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.expedienteMpvRoute = (0, express_1.Router)();
exports.expedienteMpvRoute.post('/all', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.findExpediente);
exports.expedienteMpvRoute.get('/consulta', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.findByTypeExpediente);
exports.expedienteMpvRoute.get('/one/:expedienteId', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.findOneExpediente);
exports.expedienteMpvRoute.post('/', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.saveExpediente);
exports.expedienteMpvRoute.post('/masive', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.saveMasiveExpediente);
exports.expedienteMpvRoute.post('/restart', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.restart);
exports.expedienteMpvRoute.delete('/:expedienteId', db_midleware_1.dbMiddleware, expediente_mpv_controller_1.expedienteMpvController.deleteExpediente);
//# sourceMappingURL=expediente-mpv.routes.js.map