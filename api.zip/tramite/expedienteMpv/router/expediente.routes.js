"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteMPVRoute = void 0;
const express_1 = require("express");
const expediente_controller_1 = require("../controller/expediente.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.expedienteMPVRoute = (0, express_1.Router)();
exports.expedienteMPVRoute.post('/all', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findExpedienteMPV);
exports.expedienteMPVRoute.get('/consulta', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findByTypeExpedienteMPV);
exports.expedienteMPVRoute.get('/one/:expedienteId', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.findOneExpedienteMPV);
exports.expedienteMPVRoute.post('/', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.saveExpedienteMPV);
exports.expedienteMPVRoute.post('/masive', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.saveMasiveExpedienteMPV);
exports.expedienteMPVRoute.post('/restart', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.restartMPV);
exports.expedienteMPVRoute.delete('/:expedienteId', db_midleware_1.dbMiddleware, expediente_controller_1.expedienteController.deleteExpedienteMPV);
//# sourceMappingURL=expediente.routes.js.map