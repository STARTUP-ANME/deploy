"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentEmailService = void 0;
class ContentEmailService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ContentEmailService();
        return this.instance;
    }
    solicitudRegistrada(empresa, persona, asunto, observaciones, nombreCompleto, fecha, code) {
        const html = `<!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Solicitud Registrada</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.5;
                    color: #333;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
                h1 {
                    text-align: center;
                    color: #007BFF;
                }
                .section-title {
                    font-size: 1.2em;
                    margin-top: 20px;
                    color: #0056b3;
                    text-transform: uppercase;
                    border-bottom: 2px solid #007BFF;
                    padding-bottom: 5px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 10px;
                }
                th, td {
                    padding: 10px;
                    border: 1px solid #ddd;
                    text-align: left;
                }
                th {
                    background-color: #f8f9fa;
                }
                .note {
                    font-size: 0.9em;
                    color: #555;
                    margin-top: 20px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>${empresa.nombre}</h1>
                <p>Hola, <strong>${persona.nombres}</strong></p>
                <p>Su solicitud ha sido registrada con los siguientes datos:</p>

                <div>
                    <p class="section-title">Datos Interesado</p>
                    <table>
                        <tr>
                            <th>N° Solicitud</th>
                            <td>${code}</td>
                        </tr>
                        <tr>
                            <th>Tipo Documento</th>
                            <td>${persona.tipoDocumento.descripcion}</td>
                        </tr>
                        <tr>
                            <th>N° Documento</th>
                            <td>${persona.documento}</td>
                        </tr>
                        <tr>
                            <th>Nombres</th>
                            <td>${persona.nombres}</td>
                        </tr>
                        <tr>
                            <th>Apellidos</th>
                            <td>${persona.apePaterno} ${persona.apeMaterno}</td>
                        </tr>
                        <tr>
                            <th>Correo</th>
                            <td>${persona.email}</td>
                        </tr>
                        <tr>
                            <th>Celular</th>
                            <td>${persona.telefono}</td>
                        </tr>
                        <tr>
                            <th>Dirección</th>
                            <td>${persona.direccion}</td>
                        </tr>
                    </table>
                </div>

                <div>
                    <p class="section-title">Datos Documento</p>
                    <table>
                        <tr>
                            <th>Información Requerida</th>
                            <td>${observaciones}</td>
                        </tr>
                        <tr>
                            <th>Procedimiento</th>
                            <td>${asunto}</td>
                        </tr>          
                        <tr>
                            <th>Formato de Respuesta</th>
                            <td>Correo electrónico</td>
                        </tr>
                    </table>
                </div>

                <p><strong>Hora Registro:</strong> ${fecha}</p>

                <p class="note">
                    <strong>NOTA:</strong> El ingreso de la presente documentación, no implica la aceptación de lo solicitado. 
                    Una vez que su solicitud sea verificada se le notificará al correo electrónico registrado con su número 
                    de expediente generado. Si su solicitud presenta inconsistencias en los datos diligenciados o el documento 
                    digitalizado no es legible, su solicitud será OBSERVADA y deberá verificar los motivos del observado y 
                    realizar una nueva solicitud teniendo en cuenta haber corregido las causales de lo observado.
                </p>

                <p>Gracias,</p>
                <p>Atentamente,</p>
                <p><strong>${nombreCompleto}</strong><br>
                Unidad de Trámite Documentario - ${empresa.abrev}</p>
            </div>
        </body>
        </html>
        `;
        return html;
    }
}
exports.contentEmailService = ContentEmailService.getInstance();
//# sourceMappingURL=content-solicitud-email.service.js.map