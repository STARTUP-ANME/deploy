"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentRecepcionadoEmailService = void 0;
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class ContentRecepcionadoEmailService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ContentRecepcionadoEmailService();
        return this.instance;
    }
    template(empresa, expedienteMPV, persona) {
        var _a, _b;
        const html = `<!DOCTYPE html>
        <html lang="es">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Recepción de Expediente</title>
        <style>
            body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
            }
            .container {
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            }
            h2 {
            color: #2C3E50;
            text-align: center;
            }
            .section {
            margin-bottom: 20px;
            }
            .section h3 {
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 5px;
            margin-bottom: 10px;
            color: #34495E;
            }
            .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            }
            .info-table td {
            padding: 8px;
            border: 1px solid #ddd;
            }
            .info-table tr:nth-child(even) {
            background-color: #f9f9f9;
            }
            .note {
            font-size: 14px;
            color: #7f8c8d;
            line-height: 1.5;
            margin-bottom: 20px;
            }
            .footer {
            text-align: center;
            font-size: 14px;
            color: #7f8c8d;
            }
        </style>
        </head>
        <body>
        <div class="container">
            <h2>${empresa.nombre}</h2>
            <p>Hola, <strong>${persona.nombres} ${persona.apePaterno} ${persona.apeMaterno}</strong></p>
            <p>Su expediente ha sido <strong>RECEPCIONADO</strong> con los siguientes datos:</p>
            
            <div class="section">
            <h3>DATOS DEL EXPEDIENTE</h3>
            <table class="info-table">
                <tr>
                <td><strong>N° Expediente</strong></td>
                <td>${expedienteMPV.nroDocumento}</td>
                </tr>
                <tr>
                <td><strong>Fecha y Hora</strong></td>
                <td>${(0, moment_timezone_1.default)(expedienteMPV.fechaRegistro).tz("America/Lima").format('DD/MM/YYYY hh:mm A')}</td>
                </tr>
                <tr>
                <td><strong>Folios</strong></td>
                <td>${expedienteMPV.folio}</td>
                </tr>
                <tr>
                <td><strong>Asunto</strong></td>
                <td>${expedienteMPV.asunto}</td>
                </tr>
                <tr>
                <td><strong>Procedimiento</strong></td>
                <td>${(_a = expedienteMPV === null || expedienteMPV === void 0 ? void 0 : expedienteMPV.procedimiento) === null || _a === void 0 ? void 0 : _a.descripcion}</td>
                </tr>
                <tr>
                <td><strong>Unidad Relacionada</strong></td>
                <td>--</td>
                </tr>
                <tr>
                <td><strong>Codigo de verificacion</strong></td>
                <td>${(_b = expedienteMPV === null || expedienteMPV === void 0 ? void 0 : expedienteMPV.solicitudMpv) === null || _b === void 0 ? void 0 : _b.codigo}</td>
                </tr>
            </table>
            </div>

            <div class="section">
            <h3>DATOS DEL INTERESADO</h3>
            <table class="info-table">
                <tr>
                <td><strong>Tipo Documento</strong></td>
                <td>${persona.tipoDocumento.descripcion}</td>
                </tr>
                <tr>
                <td><strong>N° Documento</strong></td>
                <td>${persona.documento}</td>
                </tr>
                <tr>
                <td><strong>Nombres</strong></td>
                <td>${persona.nombres}</td>
                </tr>                
                <tr>
                <td><strong>Apellidos</strong></td>
                <td>${persona.apePaterno} ${persona.apeMaterno}</td>
                </tr>
                <tr>
                <td><strong>Correo</strong></td>
                <td>${persona.email}</td>
                </tr>
                <tr>
                <td><strong>Celular</strong></td>
                <td>${persona.telefono}</td>
                </tr>
            </table>
            </div>

            <p class="note">
            <strong>NOTA:</strong> Con su código de verificación podrá realizar el seguimiento a su expediente de manera individual. También podrá registrar y/o realizar seguimiento de su expediente desde su bandeja de trabajo de sus expedientes presentados de manera física y virtual.
            </p>

            <p class="footer">
            Atentamente,<br>
            ${expedienteMPV.usuario.persona.nombres} ${expedienteMPV.usuario.persona.apePaterno} ${expedienteMPV.usuario.persona.apeMaterno};<br>
            Unidad de Trámite Documentario - ${empresa.abrev};
            </p>
        </div>
        </body>
        </html>
        `;
        return html;
    }
}
exports.contentRecepcionadoEmailService = ContentRecepcionadoEmailService.getInstance();
//# sourceMappingURL=content-recepcionado-email.service.js.map