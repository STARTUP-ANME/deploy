"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contentObservadoEmailService = void 0;
class ContentObservadoEmailService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ContentObservadoEmailService();
        return this.instance;
    }
    template(empresa, expedienteMPV, observaciones) {
        const { remitente } = expedienteMPV;
        let html = `<!DOCTYPE html>
        <html lang="es">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Solicitud Observada</title>
        <style>
            body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
            }
            .container {
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            }
            h2 {
            color: #C0392B;
            text-align: center;
            }
            .section {
            margin-bottom: 20px;
            }
            .section h3 {
            border-bottom: 2px solid #C0392B;
            padding-bottom: 5px;
            margin-bottom: 10px;
            color: #C0392B;
            }
            .bullet-list {
            margin: 10px 0 20px 20px;
            }
            .bullet-list li {
            margin-bottom: 8px;
            }
            .note {
            font-size: 14px;
            color: #7f8c8d;
            line-height: 1.5;
            margin-bottom: 20px;
            }
            .footer {
            text-align: center;
            font-size: 14px;
            color: #7f8c8d;
            }
        </style>
        </head>
        <body>
        <div class="container">
            <h2>${empresa.nombre}</h2>
            <p>Hola, <strong>${remitente.nombres} ${remitente.apePaterno}</strong></p>
            <p>La solicitud <strong> ${expedienteMPV.solicitudMpv.codigo};</strong> presentada ha sido <strong>OBSERVADA</strong>, por lo siguiente:</p>
            
            <div class="section">
            <h3>Observaciones</h3>
            <ul class="bullet-list">`;
        observaciones.forEach(element => {
            html += `<li>${element}</li>`;
        });
        html += `</ul>
            </div>

            <p class="note">
            Por tanto, deberá subsanar las observaciones y realizar una nueva solicitud considerando lo antes señalado.
            </p>

            <p class="footer">
            Atentamente,<br>
            ${expedienteMPV.usuario.persona.nombres} ${expedienteMPV.usuario.persona.apePaterno} ${expedienteMPV.usuario.persona.apeMaterno};<br>
            Unidad de Trámite Documentario - ${empresa.abrev};
            </p>
        </div>
        </body>
        </html>

        `;
        return html;
    }
}
exports.contentObservadoEmailService = ContentObservadoEmailService.getInstance();
//# sourceMappingURL=content-observado-email.service.js.map