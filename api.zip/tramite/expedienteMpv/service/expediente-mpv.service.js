"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expedienteMpvService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const correlativo_service_1 = require("../../correlativo/service/correlativo.service");
const enum_1 = require("../../../core/enum");
const persona_service_1 = require("../../persona/service/persona.service");
const email_service_1 = require("../../../email/service/email.service");
const empresa_service_1 = require("../../../empresa/empresa/service/empresa.service");
const procedimiento_service_1 = require("../../procedimiento/service/procedimiento.service");
const usuario_service_1 = require("../../../sistema/usuario/services/usuario.service");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const archivoAdjuntoMPV_service_1 = require("../../archivoAdjuntoMpv/service/archivoAdjuntoMPV.service");
const solicitud_service_1 = require("../../solicitud/service/solicitud.service");
const content_solicitud_email_service_1 = require("./content-solicitud-email.service");
const content_observado_email_service_1 = require("./content-observado-email.service");
const content_recepcionado_email_service_1 = require("./content-recepcionado-email.service");
const expediente_service_1 = require("../../expediente/service/expediente.service");
class ExpedienteMpvService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ExpedienteMpvService();
        return this.instance;
    }
    findExpediente(expedienteFilter, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = dataSource.getRepository(entities_1.ExpedienteMPVModel).createQueryBuilder('expedienteMPV')
                    .leftJoinAndSelect('expedienteMPV.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('expedienteMPV.remitente', 'remitente')
                    .leftJoinAndSelect('expedienteMPV.estado', 'estado')
                    .leftJoinAndSelect('expedienteMPV.expediente', 'expediente')
                    .leftJoinAndSelect('expedienteMPV.prioridad', 'prioridad')
                    .where('expedienteMPV.audAnulado = :audAnulado', { audAnulado: '0' });
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaInicio) && (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaFin)) {
                    queryBuilder.andWhere(`DATE(expedienteMPV.fechaRegistro AT TIME ZONE 'America/Lima') BETWEEN :fechaInicio AND :fechaFin`, {
                        fechaInicio: expedienteFilter.fechaInicio,
                        fechaFin: expedienteFilter.fechaFin
                    });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.estadoId) > 0) {
                    queryBuilder.andWhere("expedienteMPV.estadoId = :estadoId", { estadoId: expedienteFilter.estadoId });
                }
                if (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.numero) {
                    queryBuilder.andWhere("expedienteMPV.nroDocumento = :nroDocumento", { nroDocumento: expedienteFilter.numero });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.origenId) > 0) {
                    queryBuilder.andWhere("expedienteMPV.origenId = :origenId", { origenId: expedienteFilter.origenId });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.remitenteId) > 0) {
                    queryBuilder.andWhere("expedienteMPV.remitenteId = :remitenteId", { remitenteId: expedienteFilter.remitenteId });
                }
                queryBuilder.orderBy("expedienteMPV.expedienteMPVId", 'DESC');
                return yield queryBuilder.getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findExpedienteRelatedPerson(expedienteFilter, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = dataSource.getRepository(entities_1.ExpedienteMPVModel).createQueryBuilder('expediente')
                    .leftJoinAndSelect('expediente.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.estado', 'estado')
                    .leftJoinAndSelect('expediente.solicitudMpv', 'solicitudMpv')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .where('expediente.audAnulado = :audAnulado', { audAnulado: '0' })
                    .andWhere('expediente.remitenteId = :remitenteId', { remitenteId: expedienteFilter.personaRegistradorId }); //
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaInicio) && (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.fechaFin)) {
                    queryBuilder.andWhere(`DATE(expediente.fechaRegistro AT TIME ZONE 'America/Lima') BETWEEN :fechaInicio AND :fechaFin`, {
                        fechaInicio: expedienteFilter.fechaInicio,
                        fechaFin: expedienteFilter.fechaFin
                    });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.estadoId) > 0) {
                    queryBuilder.andWhere("expediente.estadoId = :estadoId", { estadoId: expedienteFilter.estadoId });
                }
                if (expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.numero) {
                    queryBuilder.andWhere("expediente.nroDocumento = :nroDocumento", { nroDocumento: expedienteFilter.numero });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.origenId) > 0) {
                    queryBuilder.andWhere("expediente.origenId = :origenId", { origenId: expedienteFilter.origenId });
                }
                if ((expedienteFilter === null || expedienteFilter === void 0 ? void 0 : expedienteFilter.remitenteId) > 0) {
                    queryBuilder.andWhere("expediente.remitenteId = :remitenteId", { remitenteId: expedienteFilter.remitenteId });
                }
                queryBuilder.orderBy("expediente.expedienteMPVId", 'DESC');
                return yield queryBuilder.getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    /**
     * - busqueda por tipo de expediente y nro de docuemtno
     */
    findByTypeExpediente(fechaInicio, fechaFin, tipoExpedienteId, nroDocumento, unidadOrganicaId, personaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const queryBuilder = dataSource.getRepository(entities_1.ExpedienteMPVModel).createQueryBuilder('expediente')
                    .leftJoinAndSelect('expediente.tipoDocumento', 'tipoDocumento')
                    .leftJoinAndSelect('expediente.remitente', 'remitente')
                    .leftJoinAndSelect('expediente.estado', 'estado')
                    .leftJoinAndSelect('expediente.prioridad', 'prioridad')
                    .where('expediente.audAnulado = :audAnulado', { audAnulado: '0' });
                if ((nroDocumento === '' || !nroDocumento) && fechaInicio && fechaFin && parseInt(personaId.toString()) === 0) {
                    queryBuilder.andWhere(`DATE(expediente.fechaRegistro AT TIME ZONE 'America/Lima') BETWEEN :fechaInicio AND :fechaFin`, {
                        fechaInicio: fechaInicio,
                        fechaFin: fechaFin
                    });
                }
                if (nroDocumento) {
                    queryBuilder.andWhere('expediente.nroDocumento LIKE :nroDocumento', { nroDocumento: `%${nroDocumento}%` });
                }
                if (parseInt(personaId.toString()) > 0) {
                    queryBuilder.andWhere('expediente.remitenteId = :remitenteId', { remitenteId: personaId });
                }
                // queryBuilder.andWhere("expediente.origenId = :origenId", { origenId: unidadOrganicaId })
                queryBuilder.andWhere("expediente.tipoExpedienteId = :tipoExpedienteId", { tipoExpedienteId: tipoExpedienteId })
                    .orderBy("expediente.expedienteMPVId", 'ASC');
                return yield queryBuilder.getMany();
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
            }
        });
    }
    findOneExpediente(expedienteMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).findOne({
                    where: {
                        expedienteMPVId,
                        audAnulado: '0',
                    },
                    relations: {
                        tipoDocumento: true,
                        remitente: true,
                        estado: true,
                        prioridad: true,
                        empresa: true,
                        archivoAdjuntosMpv: true,
                        procedimiento: true,
                        tipoTramiteMpv: true,
                        solicitudMpv: true,
                        usuario: {
                            persona: {
                                tipoDocumento: true
                            }
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    observado(expedienteMPVId, observaciones, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = dataSource.createQueryRunner();
            yield queryRunner.connect();
            try {
                yield queryRunner.startTransaction();
                yield queryRunner.manager.update(entities_1.ExpedienteMPVModel, { expedienteMPVId }, {
                    observaciones,
                    estadoId: enum_1.EstadosTramite.Observado
                });
                const expedienteMPV = yield this.findOneExpediente(expedienteMPVId, dataSource);
                const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
                const contentEmail = content_observado_email_service_1.contentObservadoEmailService.template(empresa, expedienteMPV, observaciones.split(/\r?\n/));
                yield this.sendEmail(expedienteMPV.remitente, empresa, contentEmail);
                yield queryRunner.commitTransaction();
            }
            catch (error) {
                yield queryRunner.rollbackTransaction();
                throw error;
            }
            finally {
                yield queryRunner.release();
            }
        });
    }
    recibido(expedienteMPVId, expediente, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = dataSource.createQueryRunner();
            yield queryRunner.connect();
            try {
                yield queryRunner.startTransaction();
                const anio = (0, moment_timezone_1.default)().tz("America/Lima").year();
                const correlativo = yield correlativo_service_1.correlativoService.findOneCorrelativo(enum_1.TipoExpediente.MesaParteVirtual, anio, dataSource);
                const nroDocumento = `${correlativo.prefijo}${correlativo.correlativo.toString().padStart(correlativo.longitud, '0')}`;
                yield queryRunner.manager.update(entities_1.ExpedienteMPVModel, { expedienteMPVId }, {
                    nroDocumento,
                    estadoId: enum_1.EstadosTramite.Registrado
                });
                let expedienteMPV = yield this.findOneExpediente(expedienteMPVId, dataSource);
                const persona = yield persona_service_1.personaService.findOnePersona(expedienteMPV.remitenteId, dataSource);
                const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
                expediente = Object.assign(Object.assign({}, expediente), { nroDocumento });
                yield expediente_service_1.expedienteService.saveExpediente(expediente, queryRunner);
                expedienteMPV = Object.assign(Object.assign({}, expedienteMPV), { nroDocumento });
                const contentEmail = content_recepcionado_email_service_1.contentRecepcionadoEmailService.template(empresa, expedienteMPV, persona);
                yield this.sendEmail(expedienteMPV.remitente, empresa, contentEmail);
                yield correlativo_service_1.correlativoService.incrementCorrelativo(enum_1.TipoExpediente.MesaParteVirtual, anio, queryRunner);
                yield queryRunner.commitTransaction();
            }
            catch (error) {
                //
                yield queryRunner.rollbackTransaction();
                throw error;
            }
            finally {
                yield queryRunner.release();
            }
        });
    }
    changeEstado(expedienteMPVId, estadoId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield queryRunner.manager.update(entities_1.ExpedienteMPVModel, { expedienteMPVId }, {
                    estadoId
                });
            }
            catch (error) {
                throw error;
            }
        });
    }
    saveExpedienteTrans(expediente, archivoAdjuntos, persona, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const queryRunner = dataSource.createQueryRunner();
            yield queryRunner.connect();
            try {
                yield queryRunner.startTransaction();
                const solictud = {
                    solicitudId: 0,
                    token: '',
                    fecha: expediente.fechaRegistro,
                    codigo: this.generateRandomCode(),
                    valido: false
                };
                const solicitud = yield solicitud_service_1.solicitudService.createTransaction(solictud, dataSource, queryRunner);
                expediente.solicitudId = solicitud.solicitudId;
                const savedExpediente = yield this.saveExpediente(expediente, dataSource, queryRunner);
                if ((archivoAdjuntos === null || archivoAdjuntos === void 0 ? void 0 : archivoAdjuntos.length) > 0) {
                    const _archivoAdjuntos = [...archivoAdjuntos].map(p => (Object.assign(Object.assign({}, p), { expedienteMPVId: expediente.expedienteMPVId > 0 ? expediente.expedienteMPVId : savedExpediente.expedienteMPVId })));
                    yield Promise.all(_archivoAdjuntos.map(permiso => archivoAdjuntoMPV_service_1.archivoAdjuntoMPVService.createArchivoAdjuntoMPV(permiso, queryRunner)));
                }
                yield persona_service_1.personaService.updatePersonaBasic(persona, queryRunner);
                // if (!expediente?.expedienteMPVId) {
                //     await correlativoService.incrementCorrelativo(TipoExpediente.MesaParteVirtual, expediente.anio, queryRunner)
                // }
                if (!savedExpediente) {
                    throw new Error("No guardadi");
                }
                yield this.sendSolicitudEmail(persona, expediente, dataSource, solicitud);
                yield queryRunner.commitTransaction();
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_EXPEDIENTE, data: savedExpediente };
            }
            catch (error) {
                yield queryRunner.rollbackTransaction();
            }
            finally {
                yield queryRunner.release();
            }
        });
    }
    generateRandomCode() {
        const code = Math.floor(10000 + Math.random() * 90000);
        return code.toString();
    }
    sendSolicitudEmail(persona, expedienteMPV, dataSource, solicitud) {
        return __awaiter(this, void 0, void 0, function* () {
            const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
            const _persona = yield persona_service_1.personaService.findOnePersona(persona.personaId, dataSource);
            const personaFusion = Object.assign(Object.assign({}, _persona), { nombres: persona.nombres, apeMaterno: persona.apeMaterno, apePaterno: persona.apePaterno, email: persona.email, telefono: persona.telefono, direccion: persona.direccion });
            const observaciones = expedienteMPV.observaciones;
            const procedimiento = yield procedimiento_service_1.procedimientoService.findOneProcedimiento(expedienteMPV.procedimientoId, dataSource);
            const usuario = yield usuario_service_1.usuarioService.findUsuarioOne(expedienteMPV.usuarioId, dataSource);
            const nombreCompleto = `${usuario.persona.nombres} ${usuario.persona.apePaterno} ${usuario.persona.apeMaterno}`;
            const fecha = (0, moment_timezone_1.default)(expedienteMPV.fechaRegistro).tz("America/Lima").format('DD/MM/YYYY hh:mm A');
            const content = content_solicitud_email_service_1.contentEmailService.solicitudRegistrada(empresa, personaFusion, procedimiento.descripcion, observaciones, nombreCompleto, fecha, solicitud.solicitudId.toString().padStart(5, '0'));
            this.sendEmail(persona, empresa, content);
        });
    }
    sendEmail(persona, empresa, content) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const emailConfig = {
                    configEmailId: 0,
                    name: empresa.nombre,
                    user: empresa.email,
                    pass: empresa.contrasena,
                    host: empresa.servidor,
                    port: empresa.puerto,
                    secure: empresa.ssl,
                    companyId: empresa.empresaId,
                };
                const emails = [{
                        recipient: persona.email,
                        subject: `${empresa.abrev} - Mesa de Partes Virtual,`,
                        content: content,
                        name: persona.nombres,
                        account: empresa.nombre
                    }];
                return yield email_service_1.emailService.sendEmail(emailConfig, emails, '');
            }
            catch (error) {
                throw error;
            }
        });
    }
    saveMasiveExpediente(expedientes, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.transaction((transactionalEntityManager) => __awaiter(this, void 0, void 0, function* () {
                    const savedExpedientes = yield transactionalEntityManager.save(entities_1.ExpedienteMPVModel, expedientes);
                    for (const element of savedExpedientes) {
                        if (element.expedienteMPVId) {
                            yield transactionalEntityManager.increment(entities_1.CorrelativoModel, { tipoExpedienteId: enum_1.TipoExpediente.Externo, anio: element.anio }, 'correlativo', 1);
                        }
                    }
                    return savedExpedientes;
                }));
            }
            catch (error) {
                log_helper_1.logger.error(error, 'saveMasiveExpedienteTransaction');
                return null;
            }
        });
    }
    saveExpediente(expediente, dataSource, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _expediente = dataSource.getRepository(entities_1.ExpedienteMPVModel).create(expediente);
                return yield queryRunner.manager.save(_expediente);
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                (0, log_helper_1.logError)(error, 'createExpediente');
            }
        });
    }
    restart(expedienteMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).update({ expedienteMPVId }, {
                    estadoId: enum_1.EstadosTramite.Registrado,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteExpediente(expedienteMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).update({ expedienteMPVId: expedienteMPVId }, {
                    estadoId: enum_1.EstadosTramite.Anulado
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    userExistExpediente(usuarioId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).exists({
                    where: {
                        usuarioId
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneExpedienteBySolicitudId(nroDocumento, year, codigo, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).findOne({
                    where: {
                        nroDocumento,
                        anio: year,
                        solicitudMpv: {
                            codigo: codigo
                        }
                    },
                    relations: {
                        expediente: {
                            procesoTramites: {
                                estado: true,
                                origen: true,
                                destino: true,
                                usuarioCrea: {
                                    persona: true
                                },
                                usuarioRecibe: {
                                    persona: true
                                }
                            },
                            origen: true
                        },
                        solicitudMpv: true,
                        estado: true,
                        remitente: true,
                        tipoDocumento: true
                    },
                    select: {}
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("error solicitud expediente ");
                return {};
            }
        });
    }
    findOne(expedienteMPVId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.ExpedienteMPVModel).findOne({
                    where: {
                        expedienteMPVId: expedienteMPVId
                    },
                    relations: {
                        expediente: {
                            procesoTramites: {
                                estado: true,
                                origen: true,
                                destino: true,
                                usuarioCrea: {
                                    persona: true
                                },
                                usuarioRecibe: {
                                    persona: true
                                }
                            },
                            origen: true
                        },
                        estado: true,
                        remitente: true,
                        tipoDocumento: true
                    },
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("find one expediente ");
                return {};
            }
        });
    }
}
exports.expedienteMpvService = ExpedienteMpvService.getInstance();
//# sourceMappingURL=expediente-mpv.service.js.map