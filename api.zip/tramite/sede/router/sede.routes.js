"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sedeRoute = void 0;
const express_1 = require("express");
const sede_controller_1 = require("../controller/sede.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.sedeRoute = (0, express_1.Router)();
exports.sedeRoute.get('/', db_midleware_1.dbMiddleware, sede_controller_1.sedeController.findSede);
exports.sedeRoute.post('/create', db_midleware_1.dbMiddleware, sede_controller_1.sedeController.createSede);
exports.sedeRoute.put('/update', db_midleware_1.dbMiddleware, sede_controller_1.sedeController.updateSede);
exports.sedeRoute.put('/delete/:sedeId', db_midleware_1.dbMiddleware, sede_controller_1.sedeController.deleteSede);
//# sourceMappingURL=sede.routes.js.map