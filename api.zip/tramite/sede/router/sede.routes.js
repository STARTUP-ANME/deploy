"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sedeRoute = void 0;
const express_1 = require("express");
const sede_controller_1 = require("../controller/sede.controller");
exports.sedeRoute = (0, express_1.Router)();
exports.sedeRoute.get('/', sede_controller_1.sedeController.findSede);
exports.sedeRoute.post('/create', sede_controller_1.sedeController.createSede);
exports.sedeRoute.put('/update', sede_controller_1.sedeController.updateSede);
exports.sedeRoute.put('/delete/:sedeId', sede_controller_1.sedeController.deleteSede);
//# sourceMappingURL=sede.routes.js.map