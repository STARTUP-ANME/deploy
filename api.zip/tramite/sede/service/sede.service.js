"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sedeService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class SedeService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SedeService();
        return this.instance;
    }
    findSede() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.SedeModel.find({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createSede(sede) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.SedeModel.save(sede);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createSede');
            }
        });
    }
    updateSede(sede) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.SedeModel.update({ sedeId: sede.sedeId }, {
                    nombre: sede.nombre,
                    direccion: sede.direccion,
                    abreviacion: sede.abreviacion,
                    ubigeoId: sede.ubigeoId,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteSede(sedeId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.SedeModel.update({ sedeId: sedeId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.sedeService = SedeService.getInstance();
//# sourceMappingURL=sede.service.js.map