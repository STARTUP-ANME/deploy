"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unidadOrganicaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const typeorm_1 = require("typeorm");
class UnidadOrganicaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UnidadOrganicaService();
        return this.instance;
    }
    findUnidadOrganica(sedeId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).find({
                    where: {
                        sedeId,
                        audAnulado: '0',
                        nivel: (0, typeorm_1.Not)(1),
                    },
                    relations: {
                        sede: true,
                        subunidades: true,
                        encargadoUO: {
                            persona: true
                        },
                        usuarioUOrganicas: {
                            usuario: true
                        }
                    },
                    select: {
                        encargadoUO: {
                            encargadoUOId: true,
                            estado: true,
                            persona: {
                                personaId: true,
                                nombres: true,
                                apePaterno: true,
                                apeMaterno: true
                            }
                        },
                        usuarioUOrganicas: true
                    }
                });
                response.forEach(element => {
                    element.encargadoUO = element.encargadoUO.filter(p => p.estado);
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneUnidadOrganica(unidadOrganicaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).findOne({
                    where: {
                        unidadOrganicaId: unidadOrganicaId,
                        audAnulado: '0'
                    },
                    relations: {
                        sede: true,
                        procedimientos: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findAllUnidadOrganica(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        sede: true,
                        subunidades: true,
                        encargadoUO: {
                            persona: true
                        }
                    },
                    select: {
                        encargadoUO: {
                            encargadoUOId: true,
                            persona: {
                                personaId: true,
                                nombres: true,
                                apePaterno: true,
                                apeMaterno: true
                            }
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForParentId(relacionId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).find({
                    where: {
                        audAnulado: '0',
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForNivel(nivel, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).find({
                    where: {
                        audAnulado: '0',
                        nivel: nivel
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneUnidadOrganicaForNivelAndRelacion(nivel, relacionId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).findOne({
                    where: {
                        audAnulado: '0',
                        nivel: nivel,
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForNivelAndRelacion(nivel, relacionId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).find({
                    where: {
                        audAnulado: '0',
                        nivel: nivel,
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaThree(sedeId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield dataSource.query(`
            WITH RECURSIVE unidad_organica_cte AS (
                -- Selecciona las unidades de nivel raíz
                SELECT 
                    u."unidadOrganicaId", 
                    u."abreviatura", 
                    u."nombre", 
                    u."nivel", 
                    u."relacionId", 
                    u."ordenId",
                    u."estado",
                    u."tupa",
                    u."audAnulado",
                    ARRAY[u."unidadOrganicaId"] AS path,  -- Define la ruta para ordenar jerárquicamente
                    1 AS depth  -- La profundidad actual (empieza desde la raíz)
                FROM 
                    tramite.unidad_organica u
                WHERE 
                    u."nivel" = 1 AND
                    u."sedeId" = $1 AND
                    u."audAnulado" = '0'
                UNION ALL
    
                -- Recursivamente obtén cada unidad dependiente, agregándola a la ruta
                SELECT 
                    child."unidadOrganicaId", 
                    child."abreviatura", 
                    child."nombre", 
                    child."nivel", 
                    child."relacionId", 
                    child."ordenId",
                    child."estado",
                    child."tupa",
                    child."audAnulado",
                    parent.path || child."unidadOrganicaId",  -- Agrega el ID actual a la ruta de la unidad padre
                    parent.depth + 1  -- Incrementa la profundidad
                FROM 
                    tramite.unidad_organica child
                INNER JOIN 
                    unidad_organica_cte parent ON child."relacionId" = parent."unidadOrganicaId"
                WHERE
					child."audAnulado" = '0'
            )
    
            SELECT 
                *
            FROM 
                unidad_organica_cte
            ORDER BY 
                path;`, [sedeId]);
            return response;
        });
    }
    findUnidadOrganicaThreeTupa(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield dataSource.query(`
            WITH RECURSIVE unidad_organica_cte AS (
                -- Selecciona las unidades de nivel raíz
                SELECT 
                    u."unidadOrganicaId", 
                    u."abreviatura", 
                    u."nombre", 
                    u."nivel", 
                    u."relacionId", 
                    u."ordenId",
                    u."estado",
                    u."tupa",
                    u."audAnulado",
                    ARRAY[u."unidadOrganicaId"] AS path,  -- Define la ruta para ordenar jerárquicamente
                    1 AS depth  -- La profundidad actual (empieza desde la raíz)
                FROM 
                    tramite.unidad_organica u
                WHERE 
                    u."nivel" = 1 AND
                    u.tupa is TRUE AND
                    u."audAnulado" = '0'
                UNION ALL
    
                -- Recursivamente obtén cada unidad dependiente, agregándola a la ruta
                SELECT 
                    child."unidadOrganicaId", 
                    child."abreviatura", 
                    child."nombre", 
                    child."nivel", 
                    child."relacionId", 
                    child."ordenId",
                    child."estado",
                    child."tupa",
                    child."audAnulado",
                    parent.path || child."unidadOrganicaId",  -- Agrega el ID actual a la ruta de la unidad padre
                    parent.depth + 1  -- Incrementa la profundidad
                FROM 
                    tramite.unidad_organica child
                INNER JOIN 
                    unidad_organica_cte parent ON child."relacionId" = parent."unidadOrganicaId"
				WHERE 
					child.tupa IS TRUE
            )
    
            SELECT 
                *
            FROM 
                unidad_organica_cte
			WHERE 
        		tupa IS TRUE
            ORDER BY 
                path;`);
            return response;
        });
    }
    createUnidadOrganica(unidadOrganica, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).save(unidadOrganica);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateUnidadOrganica(unidadOrganica, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).update({ unidadOrganicaId: unidadOrganica.unidadOrganicaId }, {
                    abreviatura: unidadOrganica.abreviatura,
                    nombre: unidadOrganica.nombre,
                    estado: unidadOrganica.estado,
                    nivel: unidadOrganica.nivel,
                    relacionId: unidadOrganica.relacionId,
                    ordenId: unidadOrganica.ordenId,
                    tupa: unidadOrganica.tupa,
                    sedeId: unidadOrganica.sedeId,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteUnidadOrganica(unidadOrganicaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UnidadOrganicaModel).update({ unidadOrganicaId: unidadOrganicaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.unidadOrganicaService = UnidadOrganicaService.getInstance();
//# sourceMappingURL=unidadOrganica.service.js.map