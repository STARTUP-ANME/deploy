"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unidadOrganicaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const typeorm_1 = require("typeorm");
class UnidadOrganicaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UnidadOrganicaService();
        return this.instance;
    }
    findUnidadOrganica(sedeId) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log("🚀 ~ UnidadOrganicaService ~ findUnidadOrganica ~ sedeId:", sedeId);
            try {
                const response = yield entities_1.UnidadOrganicaModel.find({
                    where: {
                        sedeId,
                        audAnulado: '0',
                        nivel: (0, typeorm_1.Not)(1)
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneUnidadOrganica(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.findOne({
                    where: {
                        unidadOrganicaId: unidadOrganicaId,
                        audAnulado: '0'
                    },
                    relations: {
                        sede: true,
                        procedimientos: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findAllUnidadOrganica() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForParentId(relacionId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.find({
                    where: {
                        audAnulado: '0',
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForNivel(nivel) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.find({
                    where: {
                        audAnulado: '0',
                        nivel: nivel
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneUnidadOrganicaForNivelAndRelacion(nivel, relacionId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.findOne({
                    where: {
                        audAnulado: '0',
                        nivel: nivel,
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findUnidadOrganicaForNivelAndRelacion(nivel, relacionId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.find({
                    where: {
                        audAnulado: '0',
                        nivel: nivel,
                        relacionId: relacionId
                    },
                    relations: {
                        sede: true,
                        subunidades: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createUnidadOrganica(unidadOrganica) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.save(unidadOrganica);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createUnidadOrganica');
            }
        });
    }
    updateUnidadOrganica(unidadOrganica) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.update({ unidadOrganicaId: unidadOrganica.unidadOrganicaId }, {
                    abreviatura: unidadOrganica.abreviatura,
                    nombre: unidadOrganica.nombre,
                    estado: unidadOrganica.estado,
                    nivel: unidadOrganica.nivel,
                    relacionId: unidadOrganica.relacionId,
                    ordenId: unidadOrganica.ordenId,
                    tupa: unidadOrganica.tupa,
                    sedeId: unidadOrganica.sedeId,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteUnidadOrganica(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.UnidadOrganicaModel.update({ unidadOrganicaId: unidadOrganicaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.unidadOrganicaService = UnidadOrganicaService.getInstance();
//# sourceMappingURL=unidadOrganica.service.js.map