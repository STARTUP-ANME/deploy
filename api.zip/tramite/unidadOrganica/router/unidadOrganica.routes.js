"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unidadOrganicaRoute = void 0;
const express_1 = require("express");
const unidadOrganica_controller_1 = require("../controller/unidadOrganica.controller");
exports.unidadOrganicaRoute = (0, express_1.Router)();
exports.unidadOrganicaRoute.get('/', unidadOrganica_controller_1.unidadOrganicaController.findUnidadOrganica);
exports.unidadOrganicaRoute.post('/create', unidadOrganica_controller_1.unidadOrganicaController.createUnidadOrganica);
exports.unidadOrganicaRoute.put('/update', unidadOrganica_controller_1.unidadOrganicaController.updateUnidadOrganica);
exports.unidadOrganicaRoute.put('/delete/:unidadOrganicaId', unidadOrganica_controller_1.unidadOrganicaController.deleteUnidadOrganica);
//# sourceMappingURL=unidadOrganica.routes.js.map