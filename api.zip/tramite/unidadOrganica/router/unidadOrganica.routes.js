"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unidadOrganicaRoute = void 0;
const express_1 = require("express");
const unidadOrganica_controller_1 = require("../controller/unidadOrganica.controller");
exports.unidadOrganicaRoute = (0, express_1.Router)();
exports.unidadOrganicaRoute.get('/', unidadOrganica_controller_1.unidadOrganicaController.findUnidadOrganica);
exports.unidadOrganicaRoute.get('/all', unidadOrganica_controller_1.unidadOrganicaController.findAllUnidadOrganica);
exports.unidadOrganicaRoute.get('/parent', unidadOrganica_controller_1.unidadOrganicaController.findUnidadOrganicaForParentId);
exports.unidadOrganicaRoute.get('/nivel', unidadOrganica_controller_1.unidadOrganicaController.findUnidadOrganicaForNivel);
exports.unidadOrganicaRoute.get('/one_nivel_relacion', unidadOrganica_controller_1.unidadOrganicaController.findOneUnidadOrganicaForNivelAndRelacion);
exports.unidadOrganicaRoute.get('/nivel_relacion', unidadOrganica_controller_1.unidadOrganicaController.findUnidadOrganicaForNivelAndRelacion);
exports.unidadOrganicaRoute.get('/one', unidadOrganica_controller_1.unidadOrganicaController.findOneUnidadOrganica);
exports.unidadOrganicaRoute.post('/create', unidadOrganica_controller_1.unidadOrganicaController.createUnidadOrganica);
exports.unidadOrganicaRoute.put('/update', unidadOrganica_controller_1.unidadOrganicaController.updateUnidadOrganica);
exports.unidadOrganicaRoute.put('/delete/:unidadOrganicaId', unidadOrganica_controller_1.unidadOrganicaController.deleteUnidadOrganica);
//# sourceMappingURL=unidadOrganica.routes.js.map