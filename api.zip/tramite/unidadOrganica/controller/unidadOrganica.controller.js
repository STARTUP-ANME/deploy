"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unidadOrganicaController = void 0;
const http_status_codes_1 = require("http-status-codes");
const unidadOrganica_service_1 = require("../service/unidadOrganica.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class UnidadOrganicaController {
    static getInstance() {
        if (!this.instance)
            this.instance = new UnidadOrganicaController();
        return this.instance;
    }
    findUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const sedeId = req.query.sedeId;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findUnidadOrganica(sedeId);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findAllUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findAllUnidadOrganica();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findOneUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { unidadOrganicaId } = req.query;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findOneUnidadOrganica(Number(unidadOrganicaId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findUnidadOrganicaForParentId(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { parentId } = req.query;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findUnidadOrganicaForParentId(Number(parentId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findUnidadOrganicaForNivel(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { nivel } = req.query;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findUnidadOrganicaForNivel(Number(nivel));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findOneUnidadOrganicaForNivelAndRelacion(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { nivel, relacionId } = req.query;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findOneUnidadOrganicaForNivelAndRelacion(Number(nivel), Number(relacionId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findUnidadOrganicaForNivelAndRelacion(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { nivel, relacionId } = req.query;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.findUnidadOrganicaForNivelAndRelacion(Number(nivel), Number(relacionId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { unidadOrganica } = req.body;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.createUnidadOrganica(unidadOrganica);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_UNIDAD_ORGANICA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { unidadOrganica } = req.body;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.updateUnidadOrganica(unidadOrganica);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_UNIDAD_ORGANICA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { unidadOrganicaId } = req.params;
                const response = yield unidadOrganica_service_1.unidadOrganicaService.deleteUnidadOrganica(Number(unidadOrganicaId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_UNIDAD_ORGANICA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.unidadOrganicaController = UnidadOrganicaController.getInstance();
//# sourceMappingURL=unidadOrganica.controller.js.map