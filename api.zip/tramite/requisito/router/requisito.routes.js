"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requisitoRoute = void 0;
const express_1 = require("express");
const requisito_controller_1 = require("../controller/requisito.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.requisitoRoute = (0, express_1.Router)();
exports.requisitoRoute.get('/', db_midleware_1.dbMiddleware, requisito_controller_1.requisitoController.findRequisito);
exports.requisitoRoute.post('/create', db_midleware_1.dbMiddleware, requisito_controller_1.requisitoController.createRequisito);
exports.requisitoRoute.put('/update', db_midleware_1.dbMiddleware, requisito_controller_1.requisitoController.updateRequisito);
exports.requisitoRoute.put('/delete/:requisitoId', db_midleware_1.dbMiddleware, requisito_controller_1.requisitoController.deleteRequisito);
//# sourceMappingURL=requisito.routes.js.map