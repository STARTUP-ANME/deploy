"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requisitoRoute = void 0;
const express_1 = require("express");
const requisito_controller_1 = require("../controller/requisito.controller");
exports.requisitoRoute = (0, express_1.Router)();
exports.requisitoRoute.get('/', requisito_controller_1.requisitoController.findRequisito);
exports.requisitoRoute.post('/create', requisito_controller_1.requisitoController.createRequisito);
exports.requisitoRoute.put('/update', requisito_controller_1.requisitoController.updateRequisito);
exports.requisitoRoute.put('/delete/:requisitoId', requisito_controller_1.requisitoController.deleteRequisito);
//# sourceMappingURL=requisito.routes.js.map