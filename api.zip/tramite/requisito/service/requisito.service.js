"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requisitoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class RequisitoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new RequisitoService();
        return this.instance;
    }
    findRequisito(procedimientoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RequisitoModel).find({
                    where: {
                        audAnulado: '0',
                        rubro: {
                            procedimientoId: procedimientoId
                        }
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createRequisito(requisito, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RequisitoModel).save(requisito);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createRequisito');
            }
        });
    }
    updateRequisito(requisito, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RequisitoModel).update({ requisitoId: requisito.requisitoId }, {
                    rubroId: requisito.rubroId,
                    referencial: requisito.referencial,
                    total: requisito.total,
                    cantidad: requisito.cantidad,
                    porcentaje: requisito.porcentaje,
                    expedienteId: requisito.expedienteId,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteRequisito(requisitoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RequisitoModel).update({ requisitoId: requisitoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.requisitoService = RequisitoService.getInstance();
//# sourceMappingURL=requisito.service.js.map