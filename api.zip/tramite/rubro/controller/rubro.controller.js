"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rubroController = void 0;
const http_status_codes_1 = require("http-status-codes");
const rubro_service_1 = require("../service/rubro.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class RubroController {
    static getInstance() {
        if (!this.instance)
            this.instance = new RubroController();
        return this.instance;
    }
    findRubro(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { procedimientoId } = req.query;
                const response = yield rubro_service_1.rubroService.findRubro(Number(procedimientoId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createRubro(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { rubro } = req.body;
                const response = yield rubro_service_1.rubroService.createRubro(rubro);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_RUBRO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateRubro(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { rubro } = req.body;
                const response = yield rubro_service_1.rubroService.updateRubro(rubro);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_RUBRO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteRubro(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { rubroId } = req.params;
                const response = yield rubro_service_1.rubroService.deleteRubro(Number(rubroId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_RUBRO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.rubroController = RubroController.getInstance();
//# sourceMappingURL=rubro.controller.js.map