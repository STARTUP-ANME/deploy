"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rubroService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class RubroService {
    static getInstance() {
        if (!this.instance)
            this.instance = new RubroService();
        return this.instance;
    }
    findRubro(procedimientoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RubroModel).find({
                    where: {
                        audAnulado: '0',
                        procedimientoId: procedimientoId
                    },
                    relations: {
                        procedimiento: true,
                        partidaPresupuestal: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createRubro(rubro, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RubroModel).save(rubro);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createRubro');
            }
        });
    }
    updateRubro(rubro, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RubroModel).update({ rubroId: rubro.rubroId }, {
                    procedimientoId: rubro.procedimientoId,
                    partidaId: rubro.partidaId,
                    descripcion: rubro.descripcion,
                    tipo: rubro.tipo,
                    monto: rubro.monto,
                    obligatorio: rubro.obligatorio
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteRubro(rubroId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RubroModel).update({ rubroId: rubroId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.rubroService = RubroService.getInstance();
//# sourceMappingURL=rubro.service.js.map