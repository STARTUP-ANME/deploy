"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rubroRoute = void 0;
const express_1 = require("express");
const rubro_controller_1 = require("../controller/rubro.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.rubroRoute = (0, express_1.Router)();
exports.rubroRoute.get('/', db_midleware_1.dbMiddleware, rubro_controller_1.rubroController.findRubro);
exports.rubroRoute.post('/create', db_midleware_1.dbMiddleware, rubro_controller_1.rubroController.createRubro);
exports.rubroRoute.put('/update', db_midleware_1.dbMiddleware, rubro_controller_1.rubroController.updateRubro);
exports.rubroRoute.put('/delete/:rubroId', db_midleware_1.dbMiddleware, rubro_controller_1.rubroController.deleteRubro);
//# sourceMappingURL=rubro.routes.js.map