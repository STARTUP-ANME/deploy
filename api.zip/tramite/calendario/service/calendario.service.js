"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.calendarioService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class CalendarioService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CalendarioService();
        return this.instance;
    }
    findCalendario() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CalendarioModel.find({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createCalendario(calendario) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CalendarioModel.save(calendario);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createCalendario');
            }
        });
    }
    updateCalendario(calendario) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CalendarioModel.update({ calendarioId: calendario.calendarioId }, {
                    title: calendario.title,
                    start: calendario.start,
                    end: calendario.end,
                    year: calendario.year,
                    month: calendario.month,
                    day: calendario.day,
                    color: calendario.color,
                    textcolor: calendario.textcolor,
                    massive: calendario.massive,
                    allDay: calendario.allDay
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteCalendario(calendarioId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CalendarioModel.update({ calendarioId: calendarioId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.calendarioService = CalendarioService.getInstance();
//# sourceMappingURL=calendario.service.js.map