"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.calendarioService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const transacction_handler_1 = require("../../../core/helpers/transacction.handler");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class CalendarioService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CalendarioService();
        return this.instance;
    }
    findCalendario(year, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CalendarioModel).find({
                    where: {
                        audAnulado: '0',
                        year
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    getAllDaysOfYear(year) {
        try {
            const calendario = [];
            const startDate = (0, moment_timezone_1.default)().year(year).startOf('year');
            const endDate = (0, moment_timezone_1.default)().year(year).endOf('year');
            let currentDate = startDate.clone();
            while (currentDate.isSameOrBefore(endDate)) {
                calendario.push({
                    calendarioId: 0,
                    title: "",
                    start: currentDate.toDate(),
                    end: currentDate.toDate(),
                    year: currentDate.year(),
                    month: currentDate.month() + 1, // El mes es 0-indexado, por lo que sumamos 1
                    day: currentDate.day(),
                    color: "",
                    textcolor: "",
                    massive: false,
                    allDay: false,
                });
                currentDate.add(1, 'day');
            }
            return calendario;
        }
        catch (error) {
            log_helper_1.logger.error((0, log_helper_1.logError)(error));
        }
    }
    createEventsTrans(calendarios, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield (0, transacction_handler_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                yield Promise.all(calendarios.map(cal => this.createCalendario(cal, queryRunner)));
                return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_CALENDARIO };
            }));
            return result;
        });
    }
    createCalendario(calendario, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _calendario = queryRunner.manager.create(entities_1.CalendarioModel, calendario);
                return yield queryRunner.manager.save(_calendario);
            }
            catch (error) {
                (0, log_helper_1.logError)(error, 'createCalendario');
            }
        });
    }
    updateCalendario(calendarios, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Mapeamos las promesas de actualización para cada calendario
                const updatePromises = calendarios.map(calendario => {
                    return dataSource.getRepository(entities_1.CalendarioModel).update({ calendarioId: calendario.calendarioId }, // Filtro por calendarioId
                    {
                        title: calendario.title,
                        color: calendario.color,
                        textcolor: calendario.textcolor,
                    });
                });
                // Ejecutamos todas las actualizaciones en paralelo
                const responses = yield Promise.all(updatePromises);
                return responses; // Retornamos todas las respuestas
            }
            catch (error) {
                log_helper_1.logger.error(error);
                throw error; // Lanza el error para manejarlo en otra parte si es necesario
            }
        });
    }
    deleteCalendario(calendarioId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CalendarioModel).update({ calendarioId: calendarioId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.calendarioService = CalendarioService.getInstance();
//# sourceMappingURL=calendario.service.js.map