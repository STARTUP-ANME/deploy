"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.calendarioController = void 0;
const http_status_codes_1 = require("http-status-codes");
const calendario_service_1 = require("../service/calendario.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const log_helper_1 = require("../../../core/helpers/log.helper");
class CalendarioController {
    static getInstance() {
        if (!this.instance)
            this.instance = new CalendarioController();
        return this.instance;
    }
    findCalendario(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const year = req.params.year;
                const response = yield calendario_service_1.calendarioService.findCalendario(year, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createEvents(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { calendarios } = req.body;
                const response = yield calendario_service_1.calendarioService.createEventsTrans(calendarios, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                log_helper_1.logger.error((0, log_helper_1.logError)(error));
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateCalendario(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { calendarios } = req.body;
                const response = yield calendario_service_1.calendarioService.updateCalendario(calendarios, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_CALENDARIO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteCalendario(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { calendarioId } = req.params;
                const response = yield calendario_service_1.calendarioService.deleteCalendario(Number(calendarioId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_CALENDARIO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.calendarioController = CalendarioController.getInstance();
//# sourceMappingURL=calendario.controller.js.map