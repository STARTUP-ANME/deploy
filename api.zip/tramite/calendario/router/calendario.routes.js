"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calendarioRoute = void 0;
const express_1 = require("express");
const calendario_controller_1 = require("../controller/calendario.controller");
exports.calendarioRoute = (0, express_1.Router)();
exports.calendarioRoute.get('/:year', calendario_controller_1.calendarioController.findCalendario);
exports.calendarioRoute.post('/create', calendario_controller_1.calendarioController.createEvents);
exports.calendarioRoute.post('/update', calendario_controller_1.calendarioController.updateCalendario);
exports.calendarioRoute.delete('/:calendarioId', calendario_controller_1.calendarioController.deleteCalendario);
//# sourceMappingURL=calendario.routes.js.map