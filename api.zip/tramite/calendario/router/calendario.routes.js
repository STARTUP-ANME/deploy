"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calendarioRoute = void 0;
const express_1 = require("express");
const calendario_controller_1 = require("../controller/calendario.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.calendarioRoute = (0, express_1.Router)();
exports.calendarioRoute.get('/:year', db_midleware_1.dbMiddleware, calendario_controller_1.calendarioController.findCalendario);
exports.calendarioRoute.post('/create', db_midleware_1.dbMiddleware, calendario_controller_1.calendarioController.createEvents);
exports.calendarioRoute.post('/update', db_midleware_1.dbMiddleware, calendario_controller_1.calendarioController.updateCalendario);
exports.calendarioRoute.delete('/:calendarioId', db_midleware_1.dbMiddleware, calendario_controller_1.calendarioController.deleteCalendario);
//# sourceMappingURL=calendario.routes.js.map