"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.partidaPresupuestalRoute = void 0;
const express_1 = require("express");
const partidaPresupuestal_controller_1 = require("../controller/partidaPresupuestal.controller");
exports.partidaPresupuestalRoute = (0, express_1.Router)();
exports.partidaPresupuestalRoute.get('/', partidaPresupuestal_controller_1.partidaPresupuestalController.findPartidaPresupuestal);
exports.partidaPresupuestalRoute.post('/create', partidaPresupuestal_controller_1.partidaPresupuestalController.createPartidaPresupuestal);
exports.partidaPresupuestalRoute.put('/update', partidaPresupuestal_controller_1.partidaPresupuestalController.updatePartidaPresupuestal);
exports.partidaPresupuestalRoute.put('/delete/:partidaPresupuestalId', partidaPresupuestal_controller_1.partidaPresupuestalController.deletePartidaPresupuestal);
//# sourceMappingURL=partidaPresupuestal.routes.js.map