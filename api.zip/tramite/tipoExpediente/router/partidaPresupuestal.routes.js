"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.partidaPresupuestalRoute = void 0;
const express_1 = require("express");
const partidaPresupuestal_controller_1 = require("../controller/partidaPresupuestal.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.partidaPresupuestalRoute = (0, express_1.Router)();
exports.partidaPresupuestalRoute.get('/', db_midleware_1.dbMiddleware, partidaPresupuestal_controller_1.partidaPresupuestalController.findPartidaPresupuestal);
exports.partidaPresupuestalRoute.post('/create', db_midleware_1.dbMiddleware, partidaPresupuestal_controller_1.partidaPresupuestalController.createPartidaPresupuestal);
exports.partidaPresupuestalRoute.put('/update', db_midleware_1.dbMiddleware, partidaPresupuestal_controller_1.partidaPresupuestalController.updatePartidaPresupuestal);
exports.partidaPresupuestalRoute.put('/delete/:partidaPresupuestalId', db_midleware_1.dbMiddleware, partidaPresupuestal_controller_1.partidaPresupuestalController.deletePartidaPresupuestal);
//# sourceMappingURL=partidaPresupuestal.routes.js.map