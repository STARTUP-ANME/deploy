"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.partidaPresupuestalService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class PartidaPresupuestalService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PartidaPresupuestalService();
        return this.instance;
    }
    findPartidaPresupuestal(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PartidaPresupuestalModel).find({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createPartidaPresupuestal(partidaPresupuestal, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PartidaPresupuestalModel).save(partidaPresupuestal);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updatePartidaPresupuestal(partidaPresupuestal, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PartidaPresupuestalModel).update({ partidaId: partidaPresupuestal.partidaId }, {
                    codigo: partidaPresupuestal.codigo,
                    detalle: partidaPresupuestal.detalle,
                    descripcion: partidaPresupuestal.descripcion,
                    estado: partidaPresupuestal.estado,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deletePartidaPresupuestal(partidaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PartidaPresupuestalModel).update({ partidaId: partidaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.partidaPresupuestalService = PartidaPresupuestalService.getInstance();
//# sourceMappingURL=partidaPresupuestal.service.js.map