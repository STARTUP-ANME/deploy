"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.partidaPresupuestalController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const partidaPresupuestal_service_1 = require("../service/partidaPresupuestal.service");
class PartidaPresupuestalController {
    static getInstance() {
        if (!this.instance)
            this.instance = new PartidaPresupuestalController();
        return this.instance;
    }
    findPartidaPresupuestal(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield partidaPresupuestal_service_1.partidaPresupuestalService.findPartidaPresupuestal();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createPartidaPresupuestal(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { partidaPresupuestal } = req.body;
                const response = yield partidaPresupuestal_service_1.partidaPresupuestalService.createPartidaPresupuestal(partidaPresupuestal);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_PARTIDA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updatePartidaPresupuestal(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { partidaPresupuestal } = req.body;
                const response = yield partidaPresupuestal_service_1.partidaPresupuestalService.updatePartidaPresupuestal(partidaPresupuestal);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_PARTIDA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deletePartidaPresupuestal(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { partidaPresupuestalId } = req.params;
                const response = yield partidaPresupuestal_service_1.partidaPresupuestalService.deletePartidaPresupuestal(Number(partidaPresupuestalId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_PARTIDA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.partidaPresupuestalController = PartidaPresupuestalController.getInstance();
//# sourceMappingURL=partidaPresupuestal.controller.js.map