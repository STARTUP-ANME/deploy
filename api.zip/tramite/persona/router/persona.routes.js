"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.personaRoute = void 0;
const express_1 = require("express");
const persona_controller_1 = require("../controller/persona.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.personaRoute = (0, express_1.Router)();
exports.personaRoute.get('/', db_midleware_1.dbMiddleware, persona_controller_1.personaController.findPersona);
exports.personaRoute.get('/one', db_midleware_1.dbMiddleware, persona_controller_1.personaController.findOnePersona);
exports.personaRoute.get('/document', db_midleware_1.dbMiddleware, persona_controller_1.personaController.findPersonaForDocument);
exports.personaRoute.get('/verify-email', db_midleware_1.dbMiddleware, persona_controller_1.personaController.validateEmailPerson);
exports.personaRoute.post('/create', db_midleware_1.dbMiddleware, persona_controller_1.personaController.createPersona);
exports.personaRoute.put('/update', db_midleware_1.dbMiddleware, persona_controller_1.personaController.updatePersona);
exports.personaRoute.put('/credentials', db_midleware_1.dbMiddleware, persona_controller_1.personaController.updatePersonaForCredentials);
exports.personaRoute.put('/delete/:personaId', db_midleware_1.dbMiddleware, persona_controller_1.personaController.deletePersona);
//# sourceMappingURL=persona.routes.js.map