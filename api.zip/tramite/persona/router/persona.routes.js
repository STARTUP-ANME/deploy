"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.personaRoute = void 0;
const express_1 = require("express");
const persona_controller_1 = require("../controller/persona.controller");
exports.personaRoute = (0, express_1.Router)();
exports.personaRoute.get('/', persona_controller_1.personaController.findPersona);
exports.personaRoute.get('/one', persona_controller_1.personaController.findOnePersona);
exports.personaRoute.get('/document', persona_controller_1.personaController.findPersonaForDocument);
exports.personaRoute.post('/create', persona_controller_1.personaController.createPersona);
exports.personaRoute.put('/update', persona_controller_1.personaController.updatePersona);
exports.personaRoute.put('/delete/:personaId', persona_controller_1.personaController.deletePersona);
//# sourceMappingURL=persona.routes.js.map