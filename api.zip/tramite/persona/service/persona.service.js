"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.personaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const bycrypt_handler_1 = require("../../../core/handler/bycrypt.handler");
const crypto_1 = require("../../../core/handler/crypto");
class PersonaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PersonaService();
        return this.instance;
    }
    findPersona(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        tipoDocumento: true,
                        tipoPersona: true
                    },
                    select: {}
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOnePersona(personaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).findOne({
                    where: {
                        personaId: personaId,
                        audAnulado: '0'
                    },
                    relations: {
                        tipoDocumento: true,
                        tipoPersona: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findPersonaForDocument(documentNumber, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).findOne({
                    where: {
                        documento: documentNumber,
                        audAnulado: '0'
                    },
                    relations: {
                        tipoDocumento: true,
                        tipoPersona: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    findPersonByEmail(email, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).findOne({
                    where: {
                        email: email,
                        audAnulado: '0'
                    },
                    relations: {
                        tipoDocumento: true,
                        tipoPersona: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    createPersona(persona, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let hashPassword = null;
                if (persona.contrasena) {
                    hashPassword = yield (0, bycrypt_handler_1.encrypt)(persona.contrasena);
                }
                const person = Object.assign(Object.assign({}, persona), { contrasena: hashPassword });
                const response = yield dataSource.getRepository(entities_1.PersonaModel).save(person);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createPersona');
            }
        });
    }
    updatePersonaBasic(persona, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield queryRunner.manager.update(entities_1.PersonaModel, { personaId: persona.personaId }, {
                    nombres: persona.nombres,
                    apeMaterno: persona.apeMaterno,
                    apePaterno: persona.apePaterno,
                    email: persona.email,
                    telefono: persona.telefono,
                    direccion: persona.direccion
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                throw error;
            }
        });
    }
    updatePersonaCredentials(persona, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const hashPassword = yield (0, bycrypt_handler_1.encrypt)(persona.contrasena);
                const response = yield dataSource.getRepository(entities_1.PersonaModel).update({ personaId: persona.personaId }, {
                    email: persona.email,
                    contrasena: hashPassword,
                    token: persona.token,
                    tokenExpiration: persona.tokenExpiration,
                    telefono: persona.telefono,
                    direccion: persona.direccion
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updatePersona(persona, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).update({ personaId: persona.personaId }, {
                    nombres: persona.nombres,
                    apeMaterno: persona.apeMaterno,
                    apePaterno: persona.apePaterno,
                    documento: persona.documento,
                    tipoPersonaId: persona.tipoPersonaId,
                    tipoDocumentoId: persona.tipoDocumentoId,
                    email: persona.email,
                    direccion: persona.direccion,
                    contrasena: persona.contrasena,
                    repLegal: persona.repLegal,
                    servidor: persona.servidor,
                    puerto: persona.puerto,
                    ssl: persona.ssl,
                    docRep: persona.docRep,
                    nombresRep: persona.nombresRep,
                    apMatRep: persona.apMatRep,
                    telefono: persona.telefono,
                    apPatRep: persona.apPatRep,
                    emailConfirmado: persona.emailConfirmado,
                    token: persona.token,
                    tokenExpiration: persona.tokenExpiration,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deletePersona(personaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).update({ personaId: personaId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    changeStatusEmailForPersona(token, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const key = process.env.JWT_SECRET;
            const decodeURI = decodeURIComponent(token);
            const decryptToken = (0, crypto_1.decryptData)(decodeURI, key);
            const response = yield dataSource.getRepository(entities_1.PersonaModel).update({ personaId: decryptToken.key.personaId }, {
                emailConfirmado: true
            });
            return response;
        });
    }
    updatePassword(personaId, clave, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const passwordHash = yield (0, bycrypt_handler_1.encrypt)(clave);
                const claveHash = passwordHash;
                const response = yield dataSource.getRepository(entities_1.PersonaModel).update({ personaId: personaId }, {
                    contrasena: claveHash
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('update password person: ', error.message);
                throw error;
            }
        });
    }
    verifiedExistEmail(email, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.PersonaModel).count({
                    where: {
                        email: email,
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('count email exist: ', error.message);
                throw error;
            }
        });
    }
}
exports.personaService = PersonaService.getInstance();
//# sourceMappingURL=persona.service.js.map