"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.personaController = void 0;
const http_status_codes_1 = require("http-status-codes");
const persona_service_1 = require("../service/persona.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class PersonaController {
    static getInstance() {
        if (!this.instance)
            this.instance = new PersonaController();
        return this.instance;
    }
    findPersona(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const response = yield persona_service_1.personaService.findPersona(dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findOnePersona(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { personaId } = req.query;
                const response = yield persona_service_1.personaService.findOnePersona(Number(personaId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findPersonaForDocument(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { documento } = req.query;
                const response = yield persona_service_1.personaService.findPersonaForDocument(documento, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
    createPersona(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { persona } = req.body;
                const findPersona = yield persona_service_1.personaService.findPersonaForDocument(persona.documento, dataSource);
                let findEmail;
                if (persona === null || persona === void 0 ? void 0 : persona.email) {
                    findEmail = yield persona_service_1.personaService.verifiedExistEmail(persona.email, dataSource);
                }
                if (findPersona) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({ code: http_status_codes_1.StatusCodes.BAD_REQUEST, success: false, message: MessaApi_1.MessageApi.DUPLICATE_ROW_PERSONA });
                }
                else if (findEmail > 0) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({ code: http_status_codes_1.StatusCodes.BAD_REQUEST, success: false, message: MessaApi_1.MessageApi.DUPLICATE_EMAIL_PERSONA });
                }
                else {
                    const response = yield persona_service_1.personaService.createPersona(persona, dataSource);
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_PERSONA, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updatePersona(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { persona } = req.body;
                const findPersona = yield persona_service_1.personaService.findPersonaForDocument(persona.documento, dataSource);
                const findEmail = yield persona_service_1.personaService.findPersonByEmail(persona.email, dataSource);
                if (findPersona && findPersona.personaId !== persona.personaId) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                        code: http_status_codes_1.StatusCodes.BAD_REQUEST,
                        success: false,
                        message: MessaApi_1.MessageApi.DUPLICATE_ROW_PERSONA
                    });
                }
                else if (findEmail && findEmail.personaId !== persona.personaId) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                        code: http_status_codes_1.StatusCodes.BAD_REQUEST,
                        success: false,
                        message: MessaApi_1.MessageApi.DUPLICATE_EMAIL_PERSONA
                    });
                }
                else {
                    const response = yield persona_service_1.personaService.updatePersona(persona, dataSource);
                    res.status(http_status_codes_1.StatusCodes.OK).json({
                        code: http_status_codes_1.StatusCodes.OK,
                        success: true,
                        message: MessaApi_1.MessageApi.SUCCESS_UPDATE_PERSONA,
                        data: response
                    });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updatePersonaForCredentials(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { persona } = req.body;
                const findEmail = yield persona_service_1.personaService.findPersonByEmail(persona.email, dataSource);
                if (findEmail) {
                    const findPersona = yield persona_service_1.personaService.findPersonaForDocument(findEmail.documento, dataSource);
                    if (findPersona && findPersona.personaId !== persona.personaId) {
                        res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                            code: http_status_codes_1.StatusCodes.BAD_REQUEST,
                            success: false,
                            message: MessaApi_1.MessageApi.DUPLICATE_ROW_PERSONA
                        });
                    }
                }
                if (findEmail && findEmail.personaId !== persona.personaId) {
                    res.status(http_status_codes_1.StatusCodes.BAD_REQUEST).json({
                        code: http_status_codes_1.StatusCodes.BAD_REQUEST,
                        success: false,
                        message: MessaApi_1.MessageApi.DUPLICATE_EMAIL_PERSONA
                    });
                }
                else {
                    const response = yield persona_service_1.personaService.updatePersonaCredentials(persona, dataSource);
                    res.status(http_status_codes_1.StatusCodes.OK).json({
                        code: http_status_codes_1.StatusCodes.OK,
                        success: true,
                        message: MessaApi_1.MessageApi.SUCCESS_CREATE_USUARIO,
                        data: response
                    });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updatePersonaBasic(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { persona } = req.body;
                const response = yield persona_service_1.personaService.updatePersonaCredentials(persona, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({
                    code: http_status_codes_1.StatusCodes.OK,
                    success: true,
                    message: MessaApi_1.MessageApi.SUCCESS_CREATE_USUARIO,
                    data: response
                });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deletePersona(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { personaId } = req.params;
                const response = yield persona_service_1.personaService.deletePersona(Number(personaId), dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_PERSONA, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    validateEmailPerson(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { token } = req.query;
                const response = yield persona_service_1.personaService.changeStatusEmailForPersona(token, dataSource);
                if (response.affected > 0) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'Su correo ha sido verificado correctamente' });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.BAD_REQUEST, success: false, message: 'Ha ocurrido un error al verificar su correo' });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    verifiedExistEmail(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { email } = req.query;
                const response = yield persona_service_1.personaService.verifiedExistEmail(email, dataSource);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: response > 0 ? 'El correo ya está en uso' : 'El correo es válido', data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.personaController = PersonaController.getInstance();
//# sourceMappingURL=persona.controller.js.map