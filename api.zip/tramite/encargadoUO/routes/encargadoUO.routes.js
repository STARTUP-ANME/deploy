"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encargadoUoRoute = void 0;
const express_1 = require("express");
const encargadoUO_controller_1 = require("../controller/encargadoUO.controller");
exports.encargadoUoRoute = (0, express_1.Router)();
exports.encargadoUoRoute.get('/', encargadoUO_controller_1.encargadosUOController.findEncargadoUO);
exports.encargadoUoRoute.get('/unidad', encargadoUO_controller_1.encargadosUOController.findEncargadoUOForUnidadOrganica);
exports.encargadoUoRoute.get('/one', encargadoUO_controller_1.encargadosUOController.findOneEncargadoUOForUnidadOrganica);
exports.encargadoUoRoute.post('/create', encargadoUO_controller_1.encargadosUOController.createEncargadoUO);
exports.encargadoUoRoute.put('/update', encargadoUO_controller_1.encargadosUOController.updateEncargadoUO);
exports.encargadoUoRoute.put('/delete/:encargadoUoId', encargadoUO_controller_1.encargadosUOController.deleteEncargadoUO);
//# sourceMappingURL=encargadoUO.routes.js.map