"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encargadoUoRoute = void 0;
const express_1 = require("express");
const encargadoUO_controller_1 = require("../controller/encargadoUO.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.encargadoUoRoute = (0, express_1.Router)();
exports.encargadoUoRoute.get('/', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.findEncargadoUO);
exports.encargadoUoRoute.get('/unidad', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.findEncargadoUOForUnidadOrganica);
exports.encargadoUoRoute.get('/one', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.findOneEncargadoUOForUnidadOrganica);
exports.encargadoUoRoute.post('/create', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.createEncargadoUO);
exports.encargadoUoRoute.put('/update', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.updateEncargadoUO);
exports.encargadoUoRoute.put('/delete/:encargadoUoId', db_midleware_1.dbMiddleware, encargadoUO_controller_1.encargadosUOController.deleteEncargadoUO);
//# sourceMappingURL=encargadoUO.routes.js.map