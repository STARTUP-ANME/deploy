"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.encargadosUOService = exports.EncargadoUOService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class EncargadoUOService {
    static getInstance() {
        if (!this.instance)
            this.instance = new EncargadoUOService();
        return this.instance;
    }
    findEncargadoUO() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.find({
                    where: {
                        audAnulado: '0'
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findEncargadoUOForUnidadOrganica(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.find({
                    where: {
                        unidadOrganicaId: unidadOrganicaId,
                        audAnulado: '0'
                    },
                    relationLoadStrategy: 'join',
                    relations: {
                        persona: true,
                        cargo: true,
                        tipoDocumento: true,
                        unidadOrganica: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findEncargadoUOForUO(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.findOne({
                    where: {
                        unidadOrganicaId: unidadOrganicaId,
                        estado: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createEncargadoUO(encargadoUo) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.save(encargadoUo);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    updateEncargadoUO(encargadoUo) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.update({ encargadoUOId: encargadoUo.encargadoUOId }, {
                    fechaInicio: encargadoUo.fechaInicio,
                    fechaFin: encargadoUo.fechaFin,
                    documento: encargadoUo.documento,
                    personaId: encargadoUo.personaId,
                    tipoDocumentoId: encargadoUo.tipoDocumentoId,
                    unidadOrganicaId: encargadoUo.unidadOrganicaId,
                    cargoId: encargadoUo.cargoId,
                    estado: encargadoUo.estado
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteEncargadoUO(encargadoUoId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.EncargadosUOModel.update({ encargadoUOId: encargadoUoId }, {
                    estado: false
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.EncargadoUOService = EncargadoUOService;
exports.encargadosUOService = EncargadoUOService.getInstance();
//# sourceMappingURL=encargadoUO.service.js.map