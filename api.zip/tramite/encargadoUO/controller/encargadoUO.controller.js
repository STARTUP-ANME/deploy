"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.encargadosUOController = exports.EncargadoUOController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const encargadoUO_service_1 = require("../service/encargadoUO.service");
class EncargadoUOController {
    static getInstance() {
        if (!this.instance)
            this.instance = new EncargadoUOController();
        return this.instance;
    }
    findEncargadoUO(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield encargadoUO_service_1.encargadosUOService.findEncargadoUO();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    findEncargadoUOForUnidadOrganica(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { unidadOrganicaId } = req.query;
                const response = yield encargadoUO_service_1.encargadosUOService.findEncargadoUOForUnidadOrganica(Number(unidadOrganicaId));
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createEncargadoUO(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { encargadoUo } = req.body;
                const response = yield encargadoUO_service_1.encargadosUOService.createEncargadoUO(encargadoUo);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ENCARGADO_UO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateEncargadoUO(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { encargadoUo } = req.body;
                const response = yield encargadoUO_service_1.encargadosUOService.updateEncargadoUO(encargadoUo);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ENCARGADO_UO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteEncargadoUO(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { encargadoUoId } = req.params;
                const response = yield encargadoUO_service_1.encargadosUOService.deleteEncargadoUO(Number(encargadoUoId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ENCARGADO_UO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.EncargadoUOController = EncargadoUOController;
exports.encargadosUOController = EncargadoUOController.getInstance();
//# sourceMappingURL=encargadoUO.controller.js.map