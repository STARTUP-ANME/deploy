"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoRoute = void 0;
const express_1 = require("express");
const archivoAdjunto_controller_1 = require("../controller/archivoAdjunto.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.archivoAdjuntoRoute = (0, express_1.Router)();
exports.archivoAdjuntoRoute.get('/:expedienteId', db_midleware_1.dbMiddleware, archivoAdjunto_controller_1.archivoAdjuntoController.findArchivosAdjunto);
exports.archivoAdjuntoRoute.delete('/:archivoExpedienteId', db_midleware_1.dbMiddleware, archivoAdjunto_controller_1.archivoAdjuntoController.deleteArchivosAdjunto);
//# sourceMappingURL=archivoAdjunto.routes.js.map