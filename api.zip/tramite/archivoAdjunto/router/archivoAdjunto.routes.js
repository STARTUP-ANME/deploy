"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoRoute = void 0;
const express_1 = require("express");
const archivoAdjunto_controller_1 = require("../controller/archivoAdjunto.controller");
exports.archivoAdjuntoRoute = (0, express_1.Router)();
exports.archivoAdjuntoRoute.get('/:expedienteId', archivoAdjunto_controller_1.archivoAdjuntoController.findArchivosAdjunto);
//# sourceMappingURL=archivoAdjunto.routes.js.map