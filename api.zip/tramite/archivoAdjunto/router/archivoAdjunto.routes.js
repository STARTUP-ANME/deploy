"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.archivoAdjuntoRoute = void 0;
const express_1 = require("express");
const archivoAdjunto_controller_1 = require("../controller/archivoAdjunto.controller");
exports.archivoAdjuntoRoute = (0, express_1.Router)();
exports.archivoAdjuntoRoute.get('/:expedienteId', archivoAdjunto_controller_1.archivoAdjuntoController.findArchivosAdjunto);
exports.archivoAdjuntoRoute.delete('/:archivoExpedienteId', archivoAdjunto_controller_1.archivoAdjuntoController.deleteArchivosAdjunto);
//# sourceMappingURL=archivoAdjunto.routes.js.map