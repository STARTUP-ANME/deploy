"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class CorrelativoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CorrelativoService();
        return this.instance;
    }
    findCorrelativo() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CorrelativoModel.find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        tipoExpediente: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createCorrelativo(correlativo) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CorrelativoModel.save(correlativo);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createCorrelativo');
            }
        });
    }
    updateCorrelativo(correlativo) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CorrelativoModel.update({ correlativoId: correlativo.correlativoId }, {
                    anio: correlativo.anio,
                    correlativo: correlativo.correlativo,
                    longitud: correlativo.longitud,
                    prefijo: correlativo.prefijo,
                    sedeId: correlativo.sedeId,
                    correlativoId: correlativo.correlativoId
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteCorrelativo(correlativoId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.CorrelativoModel.update({ correlativoId: correlativoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.correlativoService = CorrelativoService.getInstance();
//# sourceMappingURL=correlativo.service.js.map