"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class CorrelativoService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CorrelativoService();
        return this.instance;
    }
    findCorrelativo(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        tipoExpediente: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    findOneCorrelativo(tipoExpedienteId, anio, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoModel).findOne({
                    where: {
                        tipoExpedienteId,
                        anio,
                        audAnulado: '0'
                    },
                    relations: {
                        tipoExpediente: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    createCorrelativo(correlativo, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoModel).save(correlativo);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createCorrelativo');
            }
        });
    }
    updateCorrelativo(correlativo, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoModel).update({ correlativoId: correlativo.correlativoId }, {
                    anio: correlativo.anio,
                    correlativo: correlativo.correlativo,
                    longitud: correlativo.longitud,
                    prefijo: correlativo.prefijo,
                    sedeId: correlativo.sedeId,
                    correlativoId: correlativo.correlativoId
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteCorrelativo(correlativoId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoModel).update({ correlativoId: correlativoId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    incrementCorrelativo(tipoExpedienteId, anio, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                // Incrementar el campo "correlativo" por 1 en el registro que coincide con "tipoExpedienteId"
                return yield queryRunner.manager.increment(entities_1.CorrelativoModel, // El modelo o la tabla
                { tipoExpedienteId, anio }, // La condición para identificar el registro
                'correlativo', // El campo que deseas incrementar
                1 // El valor del incremento, en este caso, incrementar por 1
                );
            }
            catch (error) {
                log_helper_1.logger.error(error);
                throw error;
            }
        });
    }
}
exports.correlativoService = CorrelativoService.getInstance();
//# sourceMappingURL=correlativo.service.js.map