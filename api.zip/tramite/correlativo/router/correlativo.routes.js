"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoRoute = void 0;
const express_1 = require("express");
const correlativo_controller_1 = require("../controller/correlativo.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.correlativoRoute = (0, express_1.Router)();
exports.correlativoRoute.get('/', db_midleware_1.dbMiddleware, correlativo_controller_1.correlativoController.findCorrelativo);
exports.correlativoRoute.get('/one', db_midleware_1.dbMiddleware, correlativo_controller_1.correlativoController.findOneCorrelativo);
exports.correlativoRoute.post('/create', db_midleware_1.dbMiddleware, correlativo_controller_1.correlativoController.createCorrelativo);
exports.correlativoRoute.put('/update', db_midleware_1.dbMiddleware, correlativo_controller_1.correlativoController.updateCorrelativo);
exports.correlativoRoute.put('/delete/:correlativoId', db_midleware_1.dbMiddleware, correlativo_controller_1.correlativoController.deleteCorrelativo);
//# sourceMappingURL=correlativo.routes.js.map