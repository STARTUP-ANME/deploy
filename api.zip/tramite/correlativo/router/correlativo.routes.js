"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoRoute = void 0;
const express_1 = require("express");
const correlativo_controller_1 = require("../controller/correlativo.controller");
exports.correlativoRoute = (0, express_1.Router)();
exports.correlativoRoute.get('/', correlativo_controller_1.correlativoController.findCorrelativo);
exports.correlativoRoute.get('/one', correlativo_controller_1.correlativoController.findOneCorrelativo);
exports.correlativoRoute.post('/create', correlativo_controller_1.correlativoController.createCorrelativo);
exports.correlativoRoute.put('/update', correlativo_controller_1.correlativoController.updateCorrelativo);
exports.correlativoRoute.put('/delete/:correlativoId', correlativo_controller_1.correlativoController.deleteCorrelativo);
//# sourceMappingURL=correlativo.routes.js.map