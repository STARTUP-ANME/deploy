"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoUnidadController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const correlativoUnidad_service_1 = require("../service/correlativoUnidad.service");
class CorrelativoUnidadController {
    static getInstance() {
        if (!this.instance)
            this.instance = new CorrelativoUnidadController();
        return this.instance;
    }
    findCorrelativoUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield correlativoUnidad_service_1.correlativoUnidadService.findCorrelativoUnidad();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    createCorrelativoUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { correlativoUnidad } = req.body;
                const response = yield correlativoUnidad_service_1.correlativoUnidadService.createCorrelativoUnidad(correlativoUnidad);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_CORRELATIVO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateCorrelativoUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { correlativoUnidad } = req.body;
                const response = yield correlativoUnidad_service_1.correlativoUnidadService.updateCorrelativoUnidad(correlativoUnidad);
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_CORRELATIVO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    updateCorrelativosUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { correlativoUnidad } = req.body;
                if (!Array.isArray(correlativoUnidad)) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
                }
                const response = yield Promise.all(correlativoUnidad.map(item => correlativoUnidad_service_1.correlativoUnidadService.updateCorrelativoUnidad(item)));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_CORRELATIVO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    deleteCorrelativoUnidad(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { correlativoUnidadId } = req.params;
                const response = yield correlativoUnidad_service_1.correlativoUnidadService.deleteCorrelativoUnidad(Number(correlativoUnidadId));
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_CORRELATIVO, data: response });
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR)
                    .json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
}
exports.correlativoUnidadController = CorrelativoUnidadController.getInstance();
//# sourceMappingURL=correlativoUnidad.controller.js.map