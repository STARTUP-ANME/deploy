"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoUnidadRoute = void 0;
const express_1 = require("express");
const correlativoUnidad_controller_1 = require("../controller/correlativoUnidad.controller");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.correlativoUnidadRoute = (0, express_1.Router)();
exports.correlativoUnidadRoute.get('/', db_midleware_1.dbMiddleware, correlativoUnidad_controller_1.correlativoUnidadController.findCorrelativoUnidad);
exports.correlativoUnidadRoute.post('/create', db_midleware_1.dbMiddleware, correlativoUnidad_controller_1.correlativoUnidadController.createCorrelativoUnidad);
exports.correlativoUnidadRoute.put('/update', db_midleware_1.dbMiddleware, correlativoUnidad_controller_1.correlativoUnidadController.updateCorrelativoUnidad);
exports.correlativoUnidadRoute.put('/updates', db_midleware_1.dbMiddleware, correlativoUnidad_controller_1.correlativoUnidadController.updateCorrelativosUnidad);
exports.correlativoUnidadRoute.put('/delete/:correlativoUnidadId', db_midleware_1.dbMiddleware, correlativoUnidad_controller_1.correlativoUnidadController.deleteCorrelativoUnidad);
//# sourceMappingURL=correlativoUnidad.routes.js.map