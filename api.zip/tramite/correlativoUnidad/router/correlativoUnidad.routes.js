"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoUnidadRoute = void 0;
const express_1 = require("express");
const correlativoUnidad_controller_1 = require("../controller/correlativoUnidad.controller");
exports.correlativoUnidadRoute = (0, express_1.Router)();
exports.correlativoUnidadRoute.get('/', correlativoUnidad_controller_1.correlativoUnidadController.findCorrelativoUnidad);
exports.correlativoUnidadRoute.post('/create', correlativoUnidad_controller_1.correlativoUnidadController.createCorrelativoUnidad);
exports.correlativoUnidadRoute.put('/update', correlativoUnidad_controller_1.correlativoUnidadController.updateCorrelativoUnidad);
exports.correlativoUnidadRoute.put('/updates', correlativoUnidad_controller_1.correlativoUnidadController.updateCorrelativosUnidad);
exports.correlativoUnidadRoute.put('/delete/:correlativoUnidadId', correlativoUnidad_controller_1.correlativoUnidadController.deleteCorrelativoUnidad);
//# sourceMappingURL=correlativoUnidad.routes.js.map