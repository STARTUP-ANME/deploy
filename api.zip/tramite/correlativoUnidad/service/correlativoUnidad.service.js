"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlativoUnidadService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class CorrelativoUnidadService {
    static getInstance() {
        if (!this.instance)
            this.instance = new CorrelativoUnidadService();
        return this.instance;
    }
    findCorrelativoUnidad(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoUnidadModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: {
                        tipoDocumento: true
                    }
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    createCorrelativoUnidad(correlativoUnidad, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoUnidadModel).save(correlativoUnidad);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                (0, log_helper_1.logError)(error, 'createCorrelativo');
            }
        });
    }
    updateCorrelativoUnidad(correlativoUnidad, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoUnidadModel).update({ correlativoUnidadId: correlativoUnidad.correlativoUnidadId }, {
                    anio: correlativoUnidad.anio,
                    correlativo: correlativoUnidad.correlativo,
                    longitud: correlativoUnidad.longitud,
                    prefijo: correlativoUnidad.prefijo,
                    unidadOrganicaId: correlativoUnidad.unidadOrganicaId,
                    tipoDocumentoId: correlativoUnidad.tipoDocumentoId,
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
    deleteCorrelativoUnidad(correlativoUnidadId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.CorrelativoUnidadModel).update({ correlativoUnidadId: correlativoUnidadId }, {
                    audAnulado: '1'
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.correlativoUnidadService = CorrelativoUnidadService.getInstance();
//# sourceMappingURL=correlativoUnidad.service.js.map