"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = void 0;
const email_router_1 = require("./email/router/email.router");
// app.ts
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const cargo_routes_1 = require("./empresa/cargo/router/cargo.routes");
const configuracion_routes_1 = require("./empresa/configuracion/router/configuracion.routes");
const divisas_routes_1 = require("./empresa/divisas/router/divisas.routes");
const empresa_routes_1 = require("./empresa/empresa/router/empresa.routes");
const estado_routes_1 = require("./empresa/estado/router/estado.routes");
const parametro_routes_1 = require("./empresa/parametro/router/parametro.routes");
const tipoDocumento_routes_1 = require("./empresa/tipoDocumento/router/tipoDocumento.routes");
const tipoExpediente_routes_1 = require("./empresa/tipoExpediente/router/tipoExpediente.routes");
const tipoPersona_routes_1 = require("./empresa/tipoPersona/router/tipoPersona.routes");
const ubigeo_routes_1 = require("./empresa/ubigeo/router/ubigeo.routes");
const rol_routes_1 = require("./sistema/rol/routes/rol.routes");
const unidadOrganica_routes_1 = require("./tramite/unidadOrganica/router/unidadOrganica.routes");
const persona_routes_1 = require("./tramite/persona/router/persona.routes");
const menu_routes_1 = require("./sistema/menu/routes/menu.routes");
const usuario_routes_1 = require("./sistema/usuario/routes/usuario.routes");
const sede_routes_1 = require("./tramite/sede/router/sede.routes");
const correlativo_routes_1 = require("./tramite/correlativo/router/correlativo.routes");
const auth_router_1 = require("./auth/router/auth.router");
const createApp = () => {
    const app = (0, express_1.default)();
    app.use((0, cors_1.default)());
    app.use(express_1.default.json());
    app.use(`/rol`, rol_routes_1.rolRoute);
    app.use(`/cargo`, cargo_routes_1.cargoRoute);
    app.use(`/configuracion`, configuracion_routes_1.configuracionRoute);
    app.use(`/usuario`, usuario_routes_1.usuarioRoute);
    app.use(`/divisas`, divisas_routes_1.divisaRoute);
    app.use(`/empresa`, empresa_routes_1.empresaRoute);
    app.use(`/estado`, estado_routes_1.estadoRoute);
    app.use(`/parametro`, parametro_routes_1.parametroRoute);
    app.use(`/tipo_documento`, tipoDocumento_routes_1.tipoDocumentoRoute);
    app.use(`/tipo_expediente`, tipoExpediente_routes_1.tipoExpedienteRoute);
    app.use(`/tipo_persona`, tipoPersona_routes_1.tipoPersonaRoute);
    app.use(`/ubigeo`, ubigeo_routes_1.ubigeoRoute);
    app.use(`/unidad_organica`, unidadOrganica_routes_1.unidadOrganicaRoute);
    app.use(`/persona`, persona_routes_1.personaRoute);
    app.use(`/menu`, menu_routes_1.menuRoute);
    // SISTEMA
    app.use(`/usuario`, usuario_routes_1.usuarioRoute);
    app.use(`/sede`, sede_routes_1.sedeRoute);
    app.use(`/correlativo`, correlativo_routes_1.correlativoRoute);
    app.use(`/email`, email_router_1.emailRoute);
    // Auth
    app.use('/auth', auth_router_1.authRoute);
    return app;
};
exports.createApp = createApp;
//# sourceMappingURL=app.js.map