"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionRoute = void 0;
const express_1 = require("express");
const session_controllers_1 = require("../controllers/session.controllers");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.sessionRoute = (0, express_1.Router)();
exports.sessionRoute.get('/', db_midleware_1.dbMiddleware, session_controllers_1.sessionController.find);
exports.sessionRoute.post('/delete', db_midleware_1.dbMiddleware, session_controllers_1.sessionController.delete);
//# sourceMappingURL=session.routes.js.map