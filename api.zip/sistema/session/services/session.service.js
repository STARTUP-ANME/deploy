"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const typeorm_1 = require("typeorm");
const session_1 = require("entities/src/entities/sistema/session");
class SessionService {
    static getInstance() {
        if (!this.instance)
            this.instance = new SessionService();
        return this.instance;
    }
    find(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const rols = yield dataSource.getRepository(entities_1.RolModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: ['permisosRoles', 'permisosRoles.menu', 'permisosRoles.accion']
                });
                return rols;
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return [];
            }
        });
    }
    create(session, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const sessionEntity = dataSource.getRepository(session_1.SessionModel).create(session);
                return yield dataSource.getRepository(session_1.SessionModel).save(sessionEntity);
            }
            catch (error) {
                log_helper_1.logger.error('create session:', error.message);
            }
        });
    }
    delete(usuarioId, token, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(session_1.SessionModel).delete({ usuarioId, token: (0, typeorm_1.Not)(token) });
            }
            catch (error) {
                log_helper_1.logger.error('create session:', error.message);
            }
        });
    }
}
exports.sessionService = SessionService.getInstance();
//# sourceMappingURL=session.service.js.map