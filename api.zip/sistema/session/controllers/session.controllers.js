"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionController = void 0;
const http_status_codes_1 = require("http-status-codes");
const session_service_1 = require("../services/session.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const websocketService_1 = require("../../../websocketService");
const empresa_service_1 = require("../../../empresa/empresa/service/empresa.service");
class RolController {
    constructor() {
        this.find = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const rols = yield session_service_1.sessionService.find(dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(rols);
        });
        this.delete = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { usuarioId, token } = req.body;
                const dataSource = req['dbConnection'];
                const response = yield session_service_1.sessionService.delete(usuarioId, token, dataSource);
                if (response) {
                    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
                    websocketService_1.websocketService.notifyDeleteSession(usuarioId, empresa.uuid, token);
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new RolController();
        return this.instance;
    }
}
exports.sessionController = RolController.getInstance();
//# sourceMappingURL=session.controllers.js.map