"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rolController = void 0;
const http_status_codes_1 = require("http-status-codes");
const rol_service_1 = require("../services/rol.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class RolController {
    constructor() {
        this.findRol = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const rols = yield rol_service_1.rolService.findRol();
            res.status(http_status_codes_1.StatusCodes.OK).json(rols);
        });
        this.findRolOne = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const rolId = req.params.rolId;
            const rols = yield rol_service_1.rolService.findRolOne(rolId);
            res.status(http_status_codes_1.StatusCodes.OK).json(rols);
        });
        this.createRol = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { rol, permisoRoles } = req.body;
                const response = yield rol_service_1.rolService.createRolTransaction(rol, permisoRoles);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updateRol = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const rolId = req.params.rolId;
                const { rol, permisoRoles } = req.body;
                const response = yield rol_service_1.rolService.updateRolTransaction(rolId, rol, permisoRoles);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL });
            }
        });
        this.deleteRol = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const rolId = req.params.rolId;
                const response = yield rol_service_1.rolService.deleteRol(rolId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new RolController();
        return this.instance;
    }
}
exports.rolController = RolController.getInstance();
//# sourceMappingURL=rol.controllers.js.map