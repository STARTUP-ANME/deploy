"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rolService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const log_helper_2 = require("../../../core/helpers/log.helper");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const permisoRol_service_1 = require("../../permisoRol/services/permisoRol.service");
class RolService {
    static getInstance() {
        if (!this.instance)
            this.instance = new RolService();
        return this.instance;
    }
    findRol(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const rols = yield dataSource.getRepository(entities_1.RolModel).find({
                    where: {
                        audAnulado: '0'
                    },
                    relations: ['permisosRoles', 'permisosRoles.menu', 'permisosRoles.accion']
                });
                return rols;
            }
            catch (error) {
                console.log("🚀 ~ RolsService ~ findRol ~ error:", error);
                log_helper_1.logger.error(error);
                return [];
            }
        });
    }
    findRolOne(rolId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.RolModel).findOne({
                    where: {
                        rolId
                    },
                    relations: ['permisosRoles', 'permisosRoles.menu', 'permisosRoles.accion']
                });
            }
            catch (error) {
                log_helper_1.logger.error("");
                return [];
            }
        });
    }
    createRolTransaction(rol, permisoRoles, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log("🚀 ~ RolService ~ result ~ permisoRolModify:", permisoRoles);
                const result = yield (0, entities_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    const rolSaved = yield this.createRol(rol, queryRunner);
                    console.log("🚀 ~ RolService ~ result ~ rolSaved:", rolSaved);
                    const permisoRolModify = permisoRoles.map(p => (Object.assign(Object.assign({}, p), { rolId: rolSaved.rolId })));
                    console.log("🚀 ~ RolService ~ result ~ permisoRolModify:", permisoRolModify);
                    //await permisoRolService.deletePermisoRol(rol.rolId,queryRunner);
                    yield Promise.all(permisoRolModify.map(permiso => permisoRol_service_1.permisoRolService.createPermisoRol(permiso, queryRunner)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL };
                }));
                return result;
            }
            catch (error) {
                console.log("🚀 ~ RolService ~ createRolTransaction ~ error:", error.message);
                (0, log_helper_2.logError)(error);
                return null;
            }
        });
    }
    /**
     * Actualizar rol con sus respectivo permisos
     * @param rol
     * @param permisoRoles
     * @returns
     */
    updateRolTransaction(rolId, rol, permisoRoles, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield (0, entities_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    yield this.updateRol(rolId, rol, queryRunner);
                    yield permisoRol_service_1.permisoRolService.deletePermisoRol(rolId, queryRunner);
                    yield Promise.all(permisoRoles.map(permiso => permisoRol_service_1.permisoRolService.createPermisoRol(permiso, queryRunner)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ROL };
                }));
                return result;
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                return null;
            }
        });
    }
    createRol(rol, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _rol = entities_1.RolModel.create(rol);
                return yield queryRunner.manager.save(_rol);
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
    updateRol(rolId, rol, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.update(entities_1.RolModel, { rolId }, {
                    descripcion: rol.descripcion,
                    detalle: rol.detalle,
                    interno: rol.interno,
                    correlativo: rol.correlativo
                });
            }
            catch (error) {
                log_helper_1.logger.error("");
                throw error;
            }
        });
    }
    deleteRol(rolId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.RolModel).update({ rolId }, {
                    audAnulado: "1",
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('deleteRol: ');
                throw error;
            }
        });
    }
}
exports.rolService = RolService.getInstance();
//# sourceMappingURL=rol.service.js.map