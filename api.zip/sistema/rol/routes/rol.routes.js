"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rolRoute = void 0;
const express_1 = require("express");
const rol_controllers_1 = require("../controllers/rol.controllers");
const rol_validators_1 = require("../validators/rol.validators");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.rolRoute = (0, express_1.Router)();
exports.rolRoute.get('/', db_midleware_1.dbMiddleware, rol_controllers_1.rolController.findRol);
exports.rolRoute.get('/one/:rolId', db_midleware_1.dbMiddleware, rol_controllers_1.rolController.findRolOne);
exports.rolRoute.post('/', db_midleware_1.dbMiddleware, rol_validators_1.validateCreateRol, rol_controllers_1.rolController.createRol);
exports.rolRoute.put('/:rolId', db_midleware_1.dbMiddleware, rol_validators_1.validateUpdateRol, rol_controllers_1.rolController.updateRol);
exports.rolRoute.delete('/:rolId', db_midleware_1.dbMiddleware, rol_validators_1.validateDeleteRol, rol_controllers_1.rolController.deleteRol);
//# sourceMappingURL=rol.routes.js.map