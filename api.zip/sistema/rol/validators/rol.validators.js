"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteRol = exports.validateUpdateRol = exports.validateCreateRol = void 0;
const express_validator_1 = require("express-validator");
// Middleware to handle validation results
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validation for rolId
const validateId = (0, express_validator_1.param)('rolId')
    .exists().withMessage('El parámetro id es requerido')
    .isNumeric().withMessage('El parámetro id debe ser numérico');
// Validations for Rol fields
const validateRolDescripcion = (0, express_validator_1.check)('rol.descripcion')
    .exists().trim().not().isEmpty().withMessage('La descripción del rol es requerida')
    .isString().withMessage('La descripción debe ser una cadena de caracteres');
const validateRolDetalle = (0, express_validator_1.check)('rol.detalle')
    .exists().trim().not().isEmpty().withMessage('El detalle del rol es requerido')
    .isString().withMessage('El detalle debe ser una cadena de caracteres');
const validateRolInterno = (0, express_validator_1.check)('rol.interno')
    .exists().withMessage('El campo interno es requerido')
    .isBoolean().withMessage('El campo interno debe ser un valor booleano');
const validateRolCorrelativo = (0, express_validator_1.check)('rol.correlativo')
    .exists().withMessage('El campo correlativo es requerido')
    .isBoolean().withMessage('El campo correlativo debe ser un valor booleano');
// Validation for permisoRoles array
const validatePermisoRoles = (0, express_validator_1.check)('permisoRoles')
    .isArray().withMessage('permisoRoles debe ser un arreglo')
    .custom((arr) => arr.every((permiso) => permiso.menuId && (!permiso.rolId || permiso.rolId)))
    .withMessage('Cada permiso en permisoRoles debe tener un menuId válido, y si rolId está presente, debe ser válido.');
// Validation for creating a role
exports.validateCreateRol = [
    validateRolDescripcion,
    //validateRolDetalle,
    validateRolInterno,
    validateRolCorrelativo,
    validatePermisoRoles,
    handleValidationResult
];
// Validation for updating a role
exports.validateUpdateRol = [
    validateId,
    validateRolDescripcion,
    //validateRolDetalle,
    validateRolInterno,
    validateRolCorrelativo,
    validatePermisoRoles,
    handleValidationResult
];
// Validation for deleting a role
exports.validateDeleteRol = [
    validateId,
    handleValidationResult
];
//# sourceMappingURL=rol.validators.js.map