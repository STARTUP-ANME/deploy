"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const log_helper_2 = require("../../../core/helpers/log.helper");
class MenuService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MenuService();
        return this.instance;
    }
    findMenu() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const menus = yield entities_1.MenuModel.find({
                    relations: ['menuAcciones', 'menuAcciones.accion'],
                    order: {
                        'menuId': 'ASC'
                    }
                });
                return menus;
            }
            catch (error) {
                log_helper_1.logger.error("");
                return [];
            }
        });
    }
    createMenu(menus) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.MenuModel.save(menus);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("");
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
    updateMenu(menuId, menu) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.MenuModel.update({ menuId }, {
                    descripcion: menu.descripcion
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("");
                throw error;
            }
        });
    }
    deleteMenu(menuId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield entities_1.MenuModel.update({ menuId }, {
                    audAnulado: "1",
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('deleteMenu: ');
                throw error;
            }
        });
    }
}
exports.menuService = MenuService.getInstance();
//# sourceMappingURL=menu.service.js.map