"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const log_helper_2 = require("../../../core/helpers/log.helper");
class MenuService {
    static getInstance() {
        if (!this.instance)
            this.instance = new MenuService();
        return this.instance;
    }
    findMenu(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const menus = yield dataSource.getRepository(entities_1.MenuModel).find({
                    relations: ['menuAcciones', 'menuAcciones.accion'],
                    order: {
                        'menuId': 'ASC',
                        'menuAcciones': {
                            'accionId': 'ASC'
                        }
                    }
                });
                // Obtener los menús que están asociados con la empresa en `menu_company`
                const buildHierarchy = (data, parentId = null) => {
                    return data
                        .filter(item => item.parentId === parentId)
                        .map(item => (Object.assign(Object.assign({}, item), { children: buildHierarchy(data, item.menuId) })));
                };
                const hierarchicalMenu = buildHierarchy(menus);
                //return hierarchicalMenu;
                return hierarchicalMenu;
            }
            catch (error) {
                log_helper_1.logger.error("");
                return [];
            }
        });
    }
    createMenu(menus, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.MenuModel).save(menus);
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("");
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
    updateMenu(menuId, menu, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.MenuModel).update({ menuId }, {
                    descripcion: menu.descripcion
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error("");
                throw error;
            }
        });
    }
    deleteMenu(menuId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.MenuModel).update({ menuId }, {
                    audAnulado: "1",
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('deleteMenu: ');
                throw error;
            }
        });
    }
}
exports.menuService = MenuService.getInstance();
//# sourceMappingURL=menu.service.js.map