"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteMenu = exports.validateUpdateMenu = exports.validateCreateMenu = void 0;
const express_validator_1 = require("express-validator");
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
const validateId = (0, express_validator_1.param)('id')
    .exists().withMessage('El parámetro id es requerido')
    .isNumeric().withMessage('El parámetro id debe ser numérico');
const validateMenuDescripcion = (0, express_validator_1.check)('descripcion')
    .exists().trim().not().isEmpty().withMessage('La descripción del menu es requerida')
    .isString().withMessage('La descripción debe ser una cadena de caracteres');
const validateMenuDetalle = (0, express_validator_1.check)('detalle')
    .exists().trim().not().isEmpty().withMessage('El detalle del menu es requerido')
    .isString().withMessage('El detalle debe ser una cadena de caracteres');
const validateMenuInterno = (0, express_validator_1.check)('interno')
    .exists().withMessage('El campo interno es requerido')
    .isBoolean().withMessage('El campo interno debe ser un valor booleano');
const validateMenuCorrelativo = (0, express_validator_1.check)('correlativo')
    .exists().withMessage('El campo correlativo es requerido')
    .isBoolean().withMessage('El campo correlativo debe ser un valor booleano');
// * Validación para la creación de un menu
exports.validateCreateMenu = [
    validateMenuDescripcion,
    validateMenuDetalle,
    validateMenuInterno,
    validateMenuCorrelativo,
    handleValidationResult
];
// * Validación para la actualización de un menu
exports.validateUpdateMenu = [
    validateId,
    validateMenuDescripcion,
    validateMenuDetalle,
    validateMenuInterno,
    validateMenuCorrelativo,
    handleValidationResult
];
// * Validación para la eliminación de un menu
exports.validateDeleteMenu = [
    validateId,
    handleValidationResult
];
//# sourceMappingURL=menu.validators.js.map