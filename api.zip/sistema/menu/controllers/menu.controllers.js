"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuController = void 0;
const http_status_codes_1 = require("http-status-codes");
const menu_service_1 = require("../services/menu.service");
const MessaApi_1 = require("../../../core/constants/MessaApi");
class MenuController {
    constructor() {
        this.findMenu = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const menus = yield menu_service_1.menuService.findMenu(dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(menus);
        });
        this.createMenus = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const response = yield menu_service_1.menuService.createMenu(req.body, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updateMenu = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const id = req.params.id;
                const menu = req.body;
                const response = yield menu_service_1.menuService.updateMenu(Number(id), menu, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.deleteMenu = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const id = req.params.id;
                const response = yield menu_service_1.menuService.deleteMenu(Number(id), dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: true, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new MenuController();
        return this.instance;
    }
}
exports.menuController = MenuController.getInstance();
//# sourceMappingURL=menu.controllers.js.map