"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.menuRoute = void 0;
const express_1 = require("express");
const menu_validators_1 = require("../validators/menu.validators");
const menu_controllers_1 = require("../controllers/menu.controllers");
exports.menuRoute = (0, express_1.Router)();
exports.menuRoute.get('/', menu_controllers_1.menuController.findMenu);
exports.menuRoute.post('/', menu_validators_1.validateCreateMenu, menu_controllers_1.menuController.createMenus);
exports.menuRoute.put('/:id', menu_validators_1.validateUpdateMenu, menu_controllers_1.menuController.updateMenu);
exports.menuRoute.delete('/:id', menu_validators_1.validateDeleteMenu, menu_controllers_1.menuController.deleteMenu);
//# sourceMappingURL=menu.routes.js.map