"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoPermisoUsuarioRoute = void 0;
const permisoUsuario_controllers_1 = require("./../controllers/permisoUsuario.controllers");
const express_1 = require("express");
exports.permisoPermisoUsuarioRoute = (0, express_1.Router)();
exports.permisoPermisoUsuarioRoute.get('/', permisoUsuario_controllers_1.permisoUsuarioController.findPermisoUsuario);
//# sourceMappingURL=permisoUsuario.routes.js.map