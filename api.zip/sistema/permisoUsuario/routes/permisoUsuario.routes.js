"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoPermisoUsuarioRoute = void 0;
const db_midleware_1 = require("../../../core/middleware/db.midleware");
const permisoUsuario_controllers_1 = require("./../controllers/permisoUsuario.controllers");
const express_1 = require("express");
exports.permisoPermisoUsuarioRoute = (0, express_1.Router)();
exports.permisoPermisoUsuarioRoute.get('/', db_midleware_1.dbMiddleware, permisoUsuario_controllers_1.permisoUsuarioController.findPermisoUsuario);
//# sourceMappingURL=permisoUsuario.routes.js.map