"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoUsuarioController = void 0;
const http_status_codes_1 = require("http-status-codes");
const permisoUsuario_service_1 = require("../services/permisoUsuario.service");
class PermisoUsuarioController {
    constructor() {
        this.findPermisoUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const permisoRols = yield permisoUsuario_service_1.permisoUsuarioService.findPermisoUsuario(1, dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(permisoRols);
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PermisoUsuarioController();
        return this.instance;
    }
}
exports.permisoUsuarioController = PermisoUsuarioController.getInstance();
//# sourceMappingURL=permisoUsuario.controllers.js.map