"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoRolService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const log_helper_2 = require("../../../core/helpers/log.helper");
class PermisoRolService {
    static getInstance() {
        if (!this.instance)
            this.instance = new PermisoRolService();
        return this.instance;
    }
    findPermisoRol(rolId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const permisoRols = yield dataSource.getRepository(entities_1.PermisoRolModel).find({
                    where: {
                        rolId
                    },
                    relations: {
                        menu: true,
                        accion: true
                    }
                });
                const permisoFormat = permisoRols.reduce((acc, per) => {
                    const subject = per.menu.descripcion;
                    const action = per.accion.descripcion;
                    // Si el subject no está en el acumulador, lo agregamos con un array vacío
                    if (!acc.some(item => item.subject === subject)) {
                        acc.push({ subject, actions: [] });
                    }
                    // Buscamos el objeto correspondiente al subject y agregamos la acción
                    const subjectObj = acc.find(item => item.subject === subject);
                    subjectObj.actions.push(action);
                    return acc;
                }, []);
                return permisoFormat;
            }
            catch (error) {
                log_helper_1.logger.error("");
                return [];
            }
        });
    }
    createPermisoRol(permisoRol, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _permisoRol = entities_1.PermisoRolModel.create(permisoRol);
                const response = yield queryRunner.manager.save(_permisoRol);
                return response;
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
    deletePermisoRol(rolId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.delete(entities_1.PermisoRolModel, { rolId });
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
}
exports.permisoRolService = PermisoRolService.getInstance();
//# sourceMappingURL=permisoRol.service.js.map