"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoPermisoRolRoute = void 0;
const express_1 = require("express");
const permisoRol_controllers_1 = require("../controllers/permisoRol.controllers");
exports.permisoPermisoRolRoute = (0, express_1.Router)();
exports.permisoPermisoRolRoute.get('/', permisoRol_controllers_1.permisoRolController.findPermisoRol);
//# sourceMappingURL=permisoRol.routes.js.map