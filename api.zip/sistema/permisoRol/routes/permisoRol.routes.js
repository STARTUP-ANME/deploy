"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoPermisoRolRoute = void 0;
const express_1 = require("express");
const permisoRol_controllers_1 = require("../controllers/permisoRol.controllers");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.permisoPermisoRolRoute = (0, express_1.Router)();
exports.permisoPermisoRolRoute.get('/', db_midleware_1.dbMiddleware, permisoRol_controllers_1.permisoRolController.findPermisoRol);
//# sourceMappingURL=permisoRol.routes.js.map