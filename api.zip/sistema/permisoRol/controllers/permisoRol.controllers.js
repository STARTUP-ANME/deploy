"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.permisoRolController = void 0;
const http_status_codes_1 = require("http-status-codes");
const permisoRol_service_1 = require("../services/permisoRol.service");
class PermisoRolContpermisoRoller {
    constructor() {
        this.findPermisoRol = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const permisoRols = yield permisoRol_service_1.permisoRolService.findPermisoRol(1);
            res.status(http_status_codes_1.StatusCodes.OK).json(permisoRols);
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new PermisoRolContpermisoRoller();
        return this.instance;
    }
}
exports.permisoRolController = PermisoRolContpermisoRoller.getInstance();
//# sourceMappingURL=permisoRol.controllers.js.map