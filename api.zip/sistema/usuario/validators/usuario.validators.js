"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateDeleteUsuario = exports.validateUpdateUsuario = exports.validateCreateUsuario = void 0;
const express_validator_1 = require("express-validator");
// Middleware to handle validation results
const handleValidationResult = (req, res, next) => {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};
// Validation for usuarioId
const validateId = (0, express_validator_1.param)('usuarioId')
    .exists().withMessage('El parámetro id es requerido')
    .isNumeric().withMessage('El parámetro id debe ser numérico');
// Validations for Usuario fields
const validateUsuarioNombre = (0, express_validator_1.check)('usuario.usuarioNombre')
    .exists().trim().not().isEmpty().withMessage('El nombre del usuario es requerido')
    .isString().withMessage('El nombre del usuario debe ser una cadena de caracteres')
    .isLength({ max: 150 }).withMessage('El nombre del usuario no puede exceder los 150 caracteres');
const validateUsuarioClave = (0, express_validator_1.check)('usuario.clave')
    .exists().trim().not().isEmpty().withMessage('La clave del usuario es requerida')
    .isString().withMessage('La clave debe ser una cadena de caracteres')
    .isLength({ min: 6 }).withMessage('La clave debe tener al menos 6 caracteres');
const validateUsuarioEstado = (0, express_validator_1.check)('usuario.estado')
    .exists().withMessage('El estado del usuario es requerido')
    .isBoolean().withMessage('El estado debe ser un valor booleano');
// Validation for permisoUsuarioes array
const validatePermisoUsuarioes = (0, express_validator_1.check)('permisosUsuarios')
    .isArray().withMessage('permisoUsuarioes debe ser un arreglo')
    .custom((arr) => arr.every((permiso) => permiso.menuId && (!permiso.usuarioId || permiso.usuarioId)))
    .withMessage('Cada permiso en permisoUsuarioes debe tener un menuId válido, y si usuarioId está presente, debe ser válido.');
// Validation for creating a usuario
exports.validateCreateUsuario = [
    validateUsuarioNombre,
    validateUsuarioClave,
    validateUsuarioEstado,
    validatePermisoUsuarioes,
    handleValidationResult
];
// Validation for updating a usuario
exports.validateUpdateUsuario = [
    validateId,
    validateUsuarioNombre,
    //validateUsuarioClave,
    validateUsuarioEstado,
    validatePermisoUsuarioes,
    handleValidationResult
];
// Validation for deleting a usuario
exports.validateDeleteUsuario = [
    validateId,
    handleValidationResult
];
//# sourceMappingURL=usuario.validators.js.map