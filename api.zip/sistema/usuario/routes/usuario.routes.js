"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioRoute = void 0;
const express_1 = require("express");
const usuario_validators_1 = require("../validators/usuario.validators");
const usuario_controllers_1 = require("../controllers/usuario.controllers");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.usuarioRoute = (0, express_1.Router)();
exports.usuarioRoute.get('/', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.findUsuario);
exports.usuarioRoute.get('/one/:usuarioId', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.findUsuarioOne);
exports.usuarioRoute.post('/validate', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.validarCredenciales);
exports.usuarioRoute.post('/update-credential', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.updateCredentials);
exports.usuarioRoute.post('/', db_midleware_1.dbMiddleware, usuario_validators_1.validateCreateUsuario, usuario_controllers_1.usuarioController.createUsuario);
exports.usuarioRoute.post('/change-password', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.updatePasswordUsuario);
exports.usuarioRoute.post('/change-avatar', db_midleware_1.dbMiddleware, usuario_controllers_1.usuarioController.updateAvatar);
exports.usuarioRoute.put('/:usuarioId', db_midleware_1.dbMiddleware, usuario_validators_1.validateUpdateUsuario, usuario_controllers_1.usuarioController.updateUsuario);
exports.usuarioRoute.delete('/:usuarioId', db_midleware_1.dbMiddleware, usuario_validators_1.validateDeleteUsuario, usuario_controllers_1.usuarioController.deleteUsuario);
//# sourceMappingURL=usuario.routes.js.map