"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioRoute = void 0;
const express_1 = require("express");
const usuario_validators_1 = require("../validators/usuario.validators");
const usuario_controllers_1 = require("../controllers/usuario.controllers");
exports.usuarioRoute = (0, express_1.Router)();
exports.usuarioRoute.get('/', usuario_controllers_1.usuarioController.findUsuario);
exports.usuarioRoute.get('/one/:usuarioId', usuario_controllers_1.usuarioController.findUsuarioOne);
exports.usuarioRoute.post('/', usuario_validators_1.validateCreateUsuario, usuario_controllers_1.usuarioController.createUsuario);
exports.usuarioRoute.put('/:usuarioId', usuario_validators_1.validateUpdateUsuario, usuario_controllers_1.usuarioController.updateUsuario);
exports.usuarioRoute.delete('/:usuarioId', usuario_validators_1.validateDeleteUsuario, usuario_controllers_1.usuarioController.deleteUsuario);
//# sourceMappingURL=usuario.routes.js.map