"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const usuario_service_1 = require("../services/usuario.service");
const bycrypt_handler_1 = require("../../../core/handler/bycrypt.handler");
const auth_service_1 = require("../../../auth/services/auth.service");
class UsuarioController {
    constructor() {
        this.findUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const rols = yield usuario_service_1.usuarioService.findUsuario();
            res.status(http_status_codes_1.StatusCodes.OK).json(rols);
        });
        this.findUsuarioOne = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const usuarioId = req.params.usuarioId;
            const usuarios = yield usuario_service_1.usuarioService.findUsuarioOne(usuarioId);
            res.status(http_status_codes_1.StatusCodes.OK).json(usuarios);
        });
        this.validarCredenciales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { usuarioNombre, clave } = req.body;
                // Llamada al servicio de autenticación para obtener el usuario
                const usuario = yield auth_service_1.authService.signIn(usuarioNombre);
                if (!usuario) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.USUARIO_INCORRECTO });
                }
                // Si el usuario no existe, responde con error de autorización
                const correctPassword = yield (0, bycrypt_handler_1.compare)(clave, usuario.clave);
                if (!correctPassword) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.PASSWORD_INCORRECT });
                }
                // Enviar respuesta exitosa con el token
                return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'OK' });
            }
            catch (error) {
                // Manejo de error interno del servidor
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
        this.createUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { usuario, permisosUsuarios, usuarioUOrganicas } = req.body;
                const exist = yield usuario_service_1.usuarioService.existUsuario(usuario.usuarioNombre);
                if (exist) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.EXIST_USER });
                    return;
                }
                const response = yield usuario_service_1.usuarioService.createUsuarioTransaction(usuario, permisosUsuarios, usuarioUOrganicas);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updateCredentials = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const usuario = req.body;
                const response = yield usuario_service_1.usuarioService.updateCredentials(usuario);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_SUCCES_CHANGE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_ERROR_CHANGE });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL });
            }
        });
        this.updateUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const usuarioId = req.params.usuarioId;
                const { usuario, permisosUsuarios, usuarioUOrganicas } = req.body;
                const response = yield usuario_service_1.usuarioService.updateUsuarioTransaction(usuarioId, usuario, permisosUsuarios, usuarioUOrganicas);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL });
            }
        });
        this.deleteUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const rolId = req.params.rolId;
                const response = yield usuario_service_1.usuarioService.deleteUsuario(rolId);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updatePasswordUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            console.log("OKOKOKO");
            try {
                const { usuarioId, clave } = req.body;
                console.log("🚀 ~ UsuarioController ~ updatePasswordUsuario= ~ req.body:", req.body);
                const response = yield usuario_service_1.usuarioService.updatePassword(usuarioId, clave);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_USUARIO, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_USUARIO });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new UsuarioController();
        return this.instance;
    }
}
exports.usuarioController = UsuarioController.getInstance();
//# sourceMappingURL=usuario.controllers.js.map