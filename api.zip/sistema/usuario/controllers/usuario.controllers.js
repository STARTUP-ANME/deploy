"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const usuario_service_1 = require("../services/usuario.service");
const bycrypt_handler_1 = require("../../../core/handler/bycrypt.handler");
const auth_service_1 = require("../../../auth/services/auth.service");
const expediente_service_1 = require("../../../tramite/expediente/service/expediente.service");
class UsuarioController {
    constructor() {
        this.findUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const rols = yield usuario_service_1.usuarioService.findUsuario(dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(rols);
        });
        this.findUsuarioOne = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const usuarioId = req.params.usuarioId;
            const usuarios = yield usuario_service_1.usuarioService.findUsuarioOne(usuarioId, dataSource);
            res.status(http_status_codes_1.StatusCodes.OK).json(usuarios);
        });
        this.validarCredenciales = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuarioNombre, clave } = req.body;
                // Llamada al servicio de autenticación para obtener el usuario
                const usuario = yield auth_service_1.authService.signIn(usuarioNombre, dataSource);
                if (!usuario) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.USUARIO_INCORRECTO });
                }
                // Si el usuario no existe, responde con error de autorización
                const correctPassword = yield (0, bycrypt_handler_1.compare)(clave, usuario.clave);
                if (!correctPassword) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.PASSWORD_INCORRECT });
                }
                // Enviar respuesta exitosa con el token
                return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'OK' });
            }
            catch (error) {
                // Manejo de error interno del servidor
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
        this.createUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuario, permisosUsuarios, usuarioUOrganicas } = req.body;
                const exist = yield usuario_service_1.usuarioService.existUsuario(usuario.usuarioNombre, dataSource);
                if (exist) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.EXIST_USER });
                    return;
                }
                const response = yield usuario_service_1.usuarioService.createUsuarioTransaction(usuario, permisosUsuarios, usuarioUOrganicas, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updateCredentials = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const usuario = req.body;
                const response = yield usuario_service_1.usuarioService.updateCredentials(usuario, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_SUCCES_CHANGE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_ERROR_CHANGE });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL });
            }
        });
        this.updateUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const usuarioId = req.params.usuarioId;
                const { usuario, permisosUsuarios, usuarioUOrganicas } = req.body;
                const response = yield usuario_service_1.usuarioService.updateUsuarioTransaction(usuarioId, usuario, permisosUsuarios, usuarioUOrganicas, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_UPDATE_ROL });
            }
        });
        this.deleteUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const usuarioId = req.params.usuarioId;
                const existExpediente = yield expediente_service_1.expedienteService.userExistExpediente(usuarioId, dataSource);
                if (existExpediente) {
                    return res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: 'Imposible eliminar: usuario con expedientes.' });
                }
                const response = yield usuario_service_1.usuarioService.deleteUsuario(usuarioId, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_DELETE_ROL, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL, data: response });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
        this.updatePasswordUsuario = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuarioId, clave } = req.body;
                const response = yield usuario_service_1.usuarioService.updatePassword(usuarioId, clave, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_USUARIO, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_USUARIO });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new UsuarioController();
        return this.instance;
    }
    updateAvatar(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuarioId, avatar } = req.body;
                const response = yield usuario_service_1.usuarioService.updateAvatar(usuarioId, avatar, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: 'Avatar actualizado' });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: false, message: 'Error al actualizar avatar' });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: MessaApi_1.MessageApi.ERROR_DELETE_ROL });
            }
        });
    }
}
exports.usuarioController = UsuarioController.getInstance();
//# sourceMappingURL=usuario.controllers.js.map