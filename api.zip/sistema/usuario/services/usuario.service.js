"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
const log_helper_2 = require("../../../core/helpers/log.helper");
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const permisoUsuario_service_1 = require("../../permisoUsuario/services/permisoUsuario.service");
const bycrypt_handler_1 = require("../../../core/handler/bycrypt.handler");
const usuarioUOrganica_service_1 = require("../../usuarioUOrganica/services/usuarioUOrganica.service");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
class UsuarioService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UsuarioService();
        return this.instance;
    }
    findUsuario(dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const usuarios = yield dataSource.getRepository(entities_1.UsuarioModel).find({
                    where: {
                        audAnulado: '0',
                    },
                    relations: ['persona']
                });
                return usuarios;
            }
            catch (error) {
                log_helper_1.logger.error("");
                return [];
            }
        });
    }
    findUsuarioByEmail(email, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).findOne({
                    where: {
                        persona: {
                            email
                        }
                    },
                    relations: [
                        'rol',
                        'persona',
                        'permisosUsuarios',
                        'usuarioUOrganicas',
                        'usuarioUOrganicas.unidadOrganica',
                        'permisosUsuarios.menu',
                        'permisosUsuarios.accion'
                    ],
                    order: {
                        usuarioUOrganicas: {
                            unidadOrganica: {
                                unidadOrganicaId: 'ASC'
                            }
                        }
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    findUsuarioOne(usuarioId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).findOne({
                    where: {
                        usuarioId
                    },
                    relations: [
                        'rol',
                        'persona',
                        'sessions',
                        'permisosUsuarios',
                        'usuarioUOrganicas',
                        'usuarioUOrganicas.unidadOrganica',
                        'permisosUsuarios.menu',
                        'permisosUsuarios.accion',
                    ],
                    order: {
                        usuarioUOrganicas: {
                            unidadOrganica: {
                                unidadOrganicaId: 'ASC'
                            }
                        }
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    existUsuario(usuarioNombre, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).exists({
                    where: { usuarioNombre }
                });
            }
            catch (error) {
                return false;
            }
        });
    }
    cantUsuario(usuarioNombre, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).findAndCount({
                    where: { usuarioNombre }
                });
            }
            catch (error) {
                return null;
            }
        });
    }
    createUsuarioTransaction(usuario, permisoUsuarios, usuarioUOrganicas, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield (0, entities_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    const passwordHash = yield (0, bycrypt_handler_1.encrypt)(usuario.clave);
                    usuario.clave = yield passwordHash;
                    const usuarioSaved = yield this.createUsuario(usuario, queryRunner);
                    const permisoUsuarioModify = permisoUsuarios.map(p => (Object.assign(Object.assign({}, p), { usuarioId: usuarioSaved.usuarioId })));
                    const usuarioUOrganicaModify = usuarioUOrganicas.map(p => (Object.assign(Object.assign({}, p), { usuarioId: usuarioSaved.usuarioId })));
                    yield Promise.all(permisoUsuarioModify.map(permiso => permisoUsuario_service_1.permisoUsuarioService.createPermisoUsuario(permiso, queryRunner)));
                    yield Promise.all(usuarioUOrganicaModify.map(uOrganica => usuarioUOrganica_service_1.usuarioUOrganicaService.createUsuarioUOrganica(uOrganica, queryRunner)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_CREATE_ROL };
                }));
                return result;
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                return null;
            }
        });
    }
    /**
     * Actualizar usuario con sus respectivo permisos
     * @param usuario
     * @param permisoUsuarioes
     * @returns
     */
    updateUsuarioTransaction(usuarioId, usuario, permisoUsuarioes, usuarioUOrganicas, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield (0, entities_1.handleTransaction)(dataSource, (queryRunner) => __awaiter(this, void 0, void 0, function* () {
                    yield this.updateUsuario(usuarioId, usuario, queryRunner);
                    yield permisoUsuario_service_1.permisoUsuarioService.deletePermisoUsuario(usuarioId, queryRunner);
                    yield usuarioUOrganica_service_1.usuarioUOrganicaService.deleteUsuarioUOrganica(usuarioId, queryRunner);
                    yield Promise.all(permisoUsuarioes.map(permiso => permisoUsuario_service_1.permisoUsuarioService.createPermisoUsuario(permiso, queryRunner)));
                    yield Promise.all(usuarioUOrganicas.map(usuarioUOrganica => usuarioUOrganica_service_1.usuarioUOrganicaService.createUsuarioUOrganica(usuarioUOrganica, queryRunner)));
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_UPDATE_ROL };
                }));
                return result;
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                return null;
            }
        });
    }
    createUsuario(usuario, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _usuario = queryRunner.manager.create(entities_1.UsuarioModel, usuario);
                return yield queryRunner.manager.save(_usuario);
            }
            catch (error) {
                (0, log_helper_2.logError)(error);
                throw error;
            }
        });
    }
    updateUsuario(usuarioId, usuario, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.update(entities_1.UsuarioModel, { usuarioId }, {
                    personaId: usuario.personaId,
                    usuarioNombre: usuario.usuarioNombre,
                    rolId: usuario.rolId,
                    estado: usuario.estado
                });
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                throw error;
            }
        });
    }
    updateAvatar(usuarioId, avatar, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).update({ usuarioId }, {
                    avatar
                });
            }
            catch (error) {
                log_helper_1.logger.error(error.message);
                throw error;
            }
        });
    }
    updateCredentials(usuario, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            const passwordHash = yield (0, bycrypt_handler_1.encrypt)(usuario.clave);
            usuario.clave = yield passwordHash;
            return yield dataSource.getRepository(entities_1.UsuarioModel).update({
                usuarioId: usuario.usuarioId,
            }, {
                usuarioNombre: usuario.usuarioNombre,
                clave: usuario.clave,
            });
        });
    }
    deleteUsuario(usuarioId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield dataSource.getRepository(entities_1.UsuarioModel).update({ usuarioId }, {
                    audAnulado: "1",
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('deleteUsuario: ');
                throw error;
            }
        });
    }
    updatePassword(usuarioId, clave, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const passwordHash = yield (0, bycrypt_handler_1.encrypt)(clave);
                const claveHash = passwordHash;
                const response = yield dataSource.getRepository(entities_1.UsuarioModel).update({ usuarioId }, {
                    clave: claveHash,
                    fechaCambioClave: (0, moment_timezone_1.default)().tz("America/Lima").format()
                });
                return response;
            }
            catch (error) {
                log_helper_1.logger.error('deleteUsuario: ');
                throw error;
            }
        });
    }
}
exports.usuarioService = UsuarioService.getInstance();
//# sourceMappingURL=usuario.service.js.map