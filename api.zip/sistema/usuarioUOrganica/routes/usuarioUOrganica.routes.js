"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioUOrganicaRoute = void 0;
const express_1 = require("express");
const usuarioUOrganica_controllers_1 = require("../controllers/usuarioUOrganica.controllers");
exports.usuarioUOrganicaRoute = (0, express_1.Router)();
exports.usuarioUOrganicaRoute.post('/select', usuarioUOrganica_controllers_1.usuarioUOrganicaController.select);
//# sourceMappingURL=usuarioUOrganica.routes.js.map