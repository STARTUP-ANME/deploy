"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioUOrganicaRoute = void 0;
const express_1 = require("express");
const usuarioUOrganica_controllers_1 = require("../controllers/usuarioUOrganica.controllers");
const db_midleware_1 = require("../../../core/middleware/db.midleware");
exports.usuarioUOrganicaRoute = (0, express_1.Router)();
exports.usuarioUOrganicaRoute.post('/select', db_midleware_1.dbMiddleware, usuarioUOrganica_controllers_1.usuarioUOrganicaController.select);
//# sourceMappingURL=usuarioUOrganica.routes.js.map