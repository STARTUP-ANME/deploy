"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioUOrganicaService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../../core/helpers/log.helper");
class UsuarioUOrganicaService {
    static getInstance() {
        if (!this.instance)
            this.instance = new UsuarioUOrganicaService();
        return this.instance;
    }
    select(usuarioId, unidadOrganicaId, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield dataSource.getRepository(entities_1.UsuarioUOrganicaModel).update({ usuarioId }, { select: false });
                return yield dataSource.getRepository(entities_1.UsuarioUOrganicaModel).update({ usuarioId, unidadOrganicaId }, {
                    select: true
                });
            }
            catch (error) {
                (0, log_helper_1.logError)(error);
                throw error;
            }
        });
    }
    createUsuarioUOrganica(usuarioUOrganica, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const _usuarioUOrganica = queryRunner.manager.create(entities_1.UsuarioUOrganicaModel, usuarioUOrganica);
                const response = yield queryRunner.manager.save(_usuarioUOrganica);
                return response;
            }
            catch (error) {
                (0, log_helper_1.logError)(error);
                throw error;
            }
        });
    }
    deleteUsuarioUOrganica(usuarioId, queryRunner) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield queryRunner.manager.delete(entities_1.UsuarioUOrganicaModel, { usuarioId });
            }
            catch (error) {
                (0, log_helper_1.logError)(error);
                throw error;
            }
        });
    }
}
exports.usuarioUOrganicaService = UsuarioUOrganicaService.getInstance();
//# sourceMappingURL=usuarioUOrganica.service.js.map