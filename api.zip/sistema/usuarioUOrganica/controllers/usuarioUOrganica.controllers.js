"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.usuarioUOrganicaController = void 0;
const http_status_codes_1 = require("http-status-codes");
const MessaApi_1 = require("../../../core/constants/MessaApi");
const usuarioUOrganica_service_1 = require("../services/usuarioUOrganica.service");
class UsuarioUOrganicaController {
    static getInstance() {
        if (!this.instance)
            this.instance = new UsuarioUOrganicaController();
        return this.instance;
    }
    select(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuarioId, unidadOrganicaId } = req.body;
                const response = yield usuarioUOrganica_service_1.usuarioUOrganicaService.select(usuarioId, unidadOrganicaId, dataSource);
                if (response) {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_SUCCES_CHANGE, data: response });
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.PASSWORD_USUARIO_ERROR_CHANGE });
                }
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR);
            }
        });
    }
}
exports.usuarioUOrganicaController = UsuarioUOrganicaController.getInstance();
//# sourceMappingURL=usuarioUOrganica.controllers.js.map