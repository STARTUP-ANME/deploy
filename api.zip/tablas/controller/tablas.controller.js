"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tablasController = exports.TablasController = void 0;
const http_status_codes_1 = require("http-status-codes");
const tablas_service_1 = require("../service/tablas.service");
const MessaApi_1 = require("../../core/constants/MessaApi");
class TablasController {
    static getInstance() {
        if (!this.instance)
            this.instance = new TablasController();
        return this.instance;
    }
    findTablas(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const response = yield tablas_service_1.tablasService.findTablas();
                res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
}
exports.TablasController = TablasController;
exports.tablasController = TablasController.getInstance();
//# sourceMappingURL=tablas.controller.js.map