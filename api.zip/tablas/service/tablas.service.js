"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tablasService = void 0;
const data_source_1 = require("entities/src/data-source");
const log_helper_1 = require("../../core/helpers/log.helper");
class TablasService {
    static getInstance() {
        if (!this.instance)
            this.instance = new TablasService();
        return this.instance;
    }
    findTablas() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const entidades = data_source_1.AppDataSource.entityMetadatas;
                const tablas = entidades.map(entidad => ({
                    tableName: entidad.tableName,
                    schema: entidad.schema,
                }));
                return tablas;
            }
            catch (error) {
                log_helper_1.logger.error(error);
            }
        });
    }
}
exports.tablasService = TablasService.getInstance();
//# sourceMappingURL=tablas.service.js.map