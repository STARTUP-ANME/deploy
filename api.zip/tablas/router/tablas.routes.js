"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tablasRoute = void 0;
const express_1 = require("express");
const tablas_controller_1 = require("../controller/tablas.controller");
exports.tablasRoute = (0, express_1.Router)();
exports.tablasRoute.get('/', tablas_controller_1.tablasController.findTablas);
//# sourceMappingURL=tablas.routes.js.map