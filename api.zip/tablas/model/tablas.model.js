"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=tablas.model.js.map