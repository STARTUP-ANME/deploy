"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reniecController = void 0;
const reniec_service_1 = require("../service/reniec.service");
const http_status_codes_1 = require("http-status-codes");
class ReniecController {
    constructor() {
        this.searchPersonForDni = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { number } = req.query;
                const response = yield reniec_service_1.reniecService.searchPersonForDni(number.toString());
                if (response) {
                    const clientDni = response.data;
                    res.status(http_status_codes_1.StatusCodes.OK).json(clientDni);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: "No hay datos" });
                }
            }
            catch (error) {
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Error en el servidor', error: error.message });
            }
        });
        this.searchPersonForRuc = (req, res) => __awaiter(this, void 0, void 0, function* () {
            try {
                const { number } = req.query;
                const response = yield reniec_service_1.reniecService.searchPersonForRuc(number.toString());
                if (response) {
                    const clientRuc = response.data;
                    res.status(http_status_codes_1.StatusCodes.OK).json(clientRuc);
                }
                else {
                    res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json({ message: "No hay datos" });
                }
            }
            catch (error) {
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({ message: 'Error en el servidor', error: error.message });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new ReniecController();
        return this.instance;
    }
}
exports.reniecController = ReniecController.getInstance();
//# sourceMappingURL=reniec.controller.js.map