"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reniecRoute = void 0;
const express_1 = require("express");
const reniec_controller_1 = require("../controller/reniec.controller");
exports.reniecRoute = (0, express_1.Router)();
exports.reniecRoute.get('/dni', reniec_controller_1.reniecController.searchPersonForDni);
exports.reniecRoute.get('/ruc', reniec_controller_1.reniecController.searchPersonForRuc);
//# sourceMappingURL=reniec.router.js.map