"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reniecService = void 0;
const axios_1 = __importDefault(require("axios"));
const log_helper_1 = require("../../core/helpers/log.helper");
class ReniecService {
    static getInstance() {
        if (!this.instance)
            this.instance = new ReniecService();
        return this.instance;
    }
    searchPersonForDni(documentNumber) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const endpointReniec = process.env.API_RENIEC;
                const tokenReniec = process.env.TOKEN_RENIEC;
                if (!endpointReniec || !tokenReniec) {
                    return null;
                }
                const response = yield axios_1.default.post(endpointReniec, {
                    token: tokenReniec,
                    type_document: "dni",
                    document_number: documentNumber
                });
                return response.data;
            }
            catch (error) {
                (0, log_helper_1.logError)(error);
                return error;
            }
        });
    }
    searchPersonForRuc(documentNumber) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const endpointReniec = process.env.API_RENIEC;
                const tokenReniec = process.env.TOKEN_RENIEC;
                if (!endpointReniec || !tokenReniec) {
                    return null;
                }
                const response = yield axios_1.default.post(endpointReniec, {
                    token: tokenReniec,
                    type_document: "ruc",
                    document_number: documentNumber
                });
                return response.data;
            }
            catch (error) {
                (0, log_helper_1.logError)(error);
                return error;
            }
        });
    }
}
exports.reniecService = ReniecService.getInstance();
//# sourceMappingURL=reniec.service.js.map