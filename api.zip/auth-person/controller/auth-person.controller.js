"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authPersonController = void 0;
const http_status_codes_1 = require("http-status-codes");
const auth_person_service_1 = require("../services/auth-person.service");
const bycrypt_handler_1 = require("../../core/handler/bycrypt.handler");
const token_handler_1 = require("../../core/handler/token.handler");
const MessaApi_1 = require("../../core/constants/MessaApi");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const persona_service_1 = require("../../tramite/persona/service/persona.service");
const email_service_1 = require("../../email/service/email.service");
const empresa_service_1 = require("../../empresa/empresa/service/empresa.service");
const format_domain_1 = require("../../core/constants/format-domain");
class AuthPersonController {
    static getInstance() {
        if (!this.instance)
            this.instance = new AuthPersonController();
        return this.instance;
    }
    signIn(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { documento, clave } = req.body;
                // Llamada al servicio de autenticación para obtener a la persona
                const usuarioPerson = yield auth_person_service_1.authPersonService.signIn(documento, dataSource);
                // Si la persona no existe, responde con error de autorización
                if (!usuarioPerson) {
                    return res.status(http_status_codes_1.StatusCodes.UNAUTHORIZED).json({ message: 'Unauthorized' });
                }
                if (usuarioPerson && !usuarioPerson.emailConfirmado) {
                    return res.status(http_status_codes_1.StatusCodes.UNAUTHORIZED).json({ message: 'Su cuenta no ha sido verificada. intentelo otra vez' });
                }
                // Verificación de la contraseña
                const correctPassword = yield (0, bycrypt_handler_1.compare)(clave, usuarioPerson.contrasena);
                if (!correctPassword) {
                    return res.status(http_status_codes_1.StatusCodes.UNAUTHORIZED).json({ message: 'Unauthorized' });
                }
                // Generación del token de acceso
                const token = yield (0, token_handler_1.tokenSignPerson)(usuarioPerson);
                // Preparar la respuesta de autenticación
                const _usuarioPerson = yield persona_service_1.personaService.findOnePersona(Number(usuarioPerson.personaId), dataSource);
                _usuarioPerson.contrasena = '';
                const response = {
                    usuario: _usuarioPerson,
                    accessToken: token,
                    tokenType: "bearer"
                };
                // Enviar respuesta exitosa con el token
                return res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                // Manejo de error interno del servidor
                console.error(error);
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
    signInWithToken(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const accessToken = req.body.accessToken;
                // Verify the token
                if ((0, token_handler_1.verifyJWTToken)(accessToken)) {
                    const decodedToken = jsonwebtoken_1.default.verify(accessToken, process.env.JWT_SECRET);
                    const { usuarioId } = decodedToken;
                    const usuarioPerson = yield persona_service_1.personaService.findOnePersona(Number(usuarioId), dataSource);
                    const token = yield (0, token_handler_1.tokenSignPerson)(usuarioPerson);
                    usuarioPerson.contrasena = '';
                    const response = {
                        usuario: usuarioPerson,
                        accessToken: token,
                        tokenType: "bearer"
                    };
                    return res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
            }
            catch (error) {
                // Manejo de error interno del servidor
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
    forgotPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const { email } = req.body;
            const userPerson = yield persona_service_1.personaService.findPersonByEmail(email, dataSource);
            if (!userPerson) {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('No tienes acceso');
                return;
            }
            const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
            const configEmail = {
                configEmailId: 0,
                name: empresa.nombre,
                user: empresa.email,
                pass: empresa.contrasena,
                host: empresa.servidor,
                port: empresa.puerto,
                secure: empresa.ssl,
                companyId: empresa.empresaId, //umuw rfne brzp tqvi       
            };
            if (!empresa.dominioPrincipal) {
                res.status(http_status_codes_1.StatusCodes.NOT_FOUND).json('not found');
                return;
            }
            const token = yield (0, token_handler_1.tokenSignPerson)(userPerson);
            const domain = (0, format_domain_1.formatDomain)(empresa.dominioPrincipal);
            const resetLink = `${domain}/reset-password?token=${token}`;
            const content = yield auth_person_service_1.authPersonService.generateContentForgotPassowrd(resetLink);
            const emailModel = [{
                    recipient: userPerson.email,
                    subject: `Restablecimiento de contraseña`,
                    content: content,
                    name: `${userPerson.nombres} ${userPerson.apePaterno} ${userPerson.apeMaterno}`,
                    account: empresa.nombre
                }];
            const response = yield email_service_1.emailService.sendEmail(configEmail, emailModel, content);
            if (response) {
                res.status(http_status_codes_1.StatusCodes.OK).json('Ok');
            }
            else {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
            }
        });
    }
    resetPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { token, password } = req.body;
            const dataSource = req['dbConnection'];
            if (!(0, token_handler_1.verifyJWTToken)(token)) {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
                return;
            }
            const decodedToken = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
            const { usuarioId } = decodedToken;
            const updatePassword = yield persona_service_1.personaService.updatePassword(usuarioId, password, dataSource);
            if ((updatePassword === null || updatePassword === void 0 ? void 0 : updatePassword.affected) > 0) {
                res.status(http_status_codes_1.StatusCodes.OK).json('Ok');
            }
            else {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
            }
        });
    }
}
exports.authPersonController = AuthPersonController.getInstance();
//# sourceMappingURL=auth-person.controller.js.map