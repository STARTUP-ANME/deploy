"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authPersonRoute = void 0;
const express_1 = require("express");
const auth_person_controller_1 = require("../controller/auth-person.controller");
const db_midleware_1 = require("../../core/middleware/db.midleware");
exports.authPersonRoute = (0, express_1.Router)();
exports.authPersonRoute.post('/sign-in', db_midleware_1.dbMiddleware, auth_person_controller_1.authPersonController.signIn);
exports.authPersonRoute.post('/sign-in-with-token', db_midleware_1.dbMiddleware, auth_person_controller_1.authPersonController.signInWithToken);
exports.authPersonRoute.post('/forgot-password', db_midleware_1.dbMiddleware, auth_person_controller_1.authPersonController.forgotPassword);
exports.authPersonRoute.post('/reset-password', db_midleware_1.dbMiddleware, auth_person_controller_1.authPersonController.resetPassword);
//# sourceMappingURL=auth-person.routes.js.map