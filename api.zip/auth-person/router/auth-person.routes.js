"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authPersonRoute = void 0;
const express_1 = require("express");
const auth_person_controller_1 = require("../controller/auth-person.controller");
exports.authPersonRoute = (0, express_1.Router)();
exports.authPersonRoute.post('/sign-in', auth_person_controller_1.authPersonController.signIn);
exports.authPersonRoute.post('/sign-in-with-token', auth_person_controller_1.authPersonController.signInWithToken);
//# sourceMappingURL=auth-person.routes.js.map