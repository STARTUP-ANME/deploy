"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../core/helpers/log.helper");
class DashboardService {
    static getInstance() {
        if (!this.instance)
            this.instance = new DashboardService();
        return this.instance;
    }
    // Función para obtener expedienteInfo
    getExpedienteInfo(destinoId) {
        return __awaiter(this, void 0, void 0, function* () {
            const expedienteInfoQuery = `
        WITH 
        CTE_porRecibir AS (
            SELECT COUNT(*) AS "porRecibir"
            FROM tramite.proceso_tramite "procesoTramite"
            WHERE "procesoTramite"."audAnulado" = '0'
              AND "procesoTramite"."estadoId" IN (504, 507, 515, 502)
              AND "procesoTramite"."usuarioRecibeId" IS NULL
              AND "procesoTramite"."destinoId" = $1
        ),
        CTE_recepcionados AS (
            SELECT COUNT(*) AS "recepcionados"
            FROM tramite.proceso_tramite "procesoTramite"
            WHERE "procesoTramite"."audAnulado" = '0'
              AND "procesoTramite"."estadoId" IN (504, 507, 515, 502)
              AND "procesoTramite"."usuarioRecibeId" IS NOT NULL
              AND "procesoTramite"."isComplete" IS NULL
              AND "procesoTramite"."destinoId" = $1
        ),
        CTE_copias AS (
            SELECT COUNT(*) AS "copias"
            FROM tramite.proceso_tramite "procesoTramite"
            WHERE "procesoTramite"."audAnulado" = '0'
              AND "procesoTramite"."estadoId" IN (504, 507, 515)
              AND "procesoTramite"."usuarioRecibeId" IS NOT NULL
              AND "procesoTramite"."isComplete" IS NULL
              AND "procesoTramite"."tipoEnvioId" = 2
              AND "procesoTramite"."destinoId" = $1
        ),
        CTE_atendidos AS (
            SELECT COUNT(*) AS "atendidos"
            FROM tramite.proceso_tramite "procesoTramite"
            WHERE "procesoTramite"."audAnulado" = '0'
              AND "procesoTramite"."estadoId" IN (504, 515, 502)
              AND "procesoTramite"."usuarioRecibeId" IS NOT NULL
              AND "procesoTramite"."isComplete" IS NOT NULL
              AND "procesoTramite"."destinoId" = $1
        )
        SELECT 
            (SELECT "porRecibir" FROM CTE_porRecibir) AS "porRecibir",
            (SELECT "recepcionados" FROM CTE_recepcionados) AS "recepcionados",
            (SELECT "copias" FROM CTE_copias) AS "copias",
            (SELECT "atendidos" FROM CTE_atendidos) AS "atendidos";
    `;
            return yield entities_1.ProcesoTramiteModel.query(expedienteInfoQuery, [destinoId]);
        });
    }
    // Función para obtener estados
    getEstados(destinoId) {
        return __awaiter(this, void 0, void 0, function* () {
            const estadosQuery = `
        SELECT 
            COUNT(CASE 
                WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') > DATE((NOW() AT TIME ZONE 'America/Lima')) + INTERVAL '3 day' THEN 1
            END) AS pendientes,
            COUNT(CASE 
                WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') 
                    BETWEEN DATE(NOW() AT TIME ZONE 'America/Lima') - INTERVAL '3 day' 
                    AND DATE(NOW() AT TIME ZONE 'America/Lima') THEN 1
            END) AS por_vencer,
            COUNT(CASE 
                WHEN DATE(e."fechaLimite" AT TIME ZONE 'America/Lima') < DATE(NOW() AT TIME ZONE 'America/Lima') THEN 1
            END) AS vencidos
        FROM tramite.proceso_tramite pt
        INNER JOIN tramite.expediente e ON e."expedienteId" = pt."expedienteId"
        WHERE pt."destinoId" = $1
          AND pt."usuarioRecibeId" IS NULL
          AND pt."isComplete" IS NULL;
    `;
            return yield entities_1.ProcesoTramiteModel.query(estadosQuery, [destinoId]);
        });
    }
    findAreaNoResponde(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            const query = `SELECT 
                    COUNT(*) AS cantidad, 
                    uo.nombre
                FROM 
                    tramite.proceso_tramite pt
                JOIN 
                    tramite.unidad_organica uo 
                ON 
                    pt."destinoId" = uo."unidadOrganicaId"
                WHERE 
                    pt."origenId" = $1 
                    AND pt."usuarioRecibeId" IS NULL
                    AND pt."estadoId" IN (504, 507, 515, 502)
                GROUP BY 
                    uo.nombre
                ORDER BY 
                    cantidad DESC;`;
            return yield entities_1.ProcesoTramiteModel.query(query, [unidadOrganicaId]);
        });
    }
    // Función principal que combina ambos métodos
    findDashboard(unidadOrganicaId) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const [expedienteInfo] = yield this.getExpedienteInfo(unidadOrganicaId);
                const [estados] = yield this.getEstados(unidadOrganicaId);
                const areaNoResponde = yield this.findAreaNoResponde(unidadOrganicaId);
                if (!expedienteInfo || !estados) {
                    log_helper_1.logger.warn(`Datos incompletos para unidadOrganicaId: ${unidadOrganicaId}`);
                    return null;
                }
                return {
                    expedienteInfo,
                    estados,
                    areaNoResponde
                };
            }
            catch (error) {
                log_helper_1.logger.error(`Error al ejecutar findDashboard para unidadOrganicaId: ${unidadOrganicaId}`, error);
                return null;
            }
        });
    }
}
exports.dashboardService = DashboardService.getInstance();
//# sourceMappingURL=dashboard.service.js.map