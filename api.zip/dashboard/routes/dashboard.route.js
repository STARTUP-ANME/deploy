"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dashboardRoute = void 0;
const express_1 = require("express");
const dashboard_controller_1 = require("../controllers/dashboard.controller");
const db_midleware_1 = require("../../core/middleware/db.midleware");
exports.dashboardRoute = (0, express_1.Router)();
exports.dashboardRoute.get('/:unidadOrganicaId', db_midleware_1.dbMiddleware, dashboard_controller_1.dashboardController.findDashboard);
//# sourceMappingURL=dashboard.route.js.map