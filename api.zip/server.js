"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
// server.ts
require("dotenv/config");
const node_http_1 = require("node:http");
const app_1 = require("./app");
const activeConnections = {};
function startServer() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // await AppDataSource.initialize()
            console.info('DataSource initialized');
            const app = (0, app_1.createApp)();
            const server = (0, node_http_1.createServer)(app);
            const port = process.env.PORT || 4000;
            server.listen(port, () => {
                console.info(`🌟 ¡El servidor Express ha comenzado en el puerto ${port}! 🚀✨`);
            });
        }
        catch (error) {
            console.error('Error al iniciar la aplicación:', error);
        }
    });
}
startServer();
//# sourceMappingURL=server.js.map