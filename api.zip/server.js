"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.io = void 0;
// server.ts
require("dotenv/config");
const app_1 = require("./app");
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const activeConnections = {};
let io;
function startServer() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // await AppDataSource.initialize()
            console.info('DataSource initialized');
            const app = (0, app_1.createApp)();
            const server = http_1.default.createServer(app);
            exports.io = io = new socket_io_1.Server(server, {
                cors: { origin: '*' }, // Configurar CORS según tus necesidades
            });
            io.on('connection', (socket) => {
                console.log('Client connected:', socket.id);
                // Recibir y asociar el usuario con su ID
                const { usuarioId, uuid } = socket.handshake.query;
                if (usuarioId) {
                    socket.join(`user-${usuarioId}-${uuid}`); // Vincula el socket a una sala basada en el ID del usuario
                    console.log(`User ${usuarioId}-${uuid} joined room: user-${usuarioId}`);
                    io.emit("message", 'hola como estas');
                }
                socket.on('disconnect', () => {
                    console.log('Client disconnected:', socket.id);
                });
            });
            const port = process.env.PORT || 4000;
            server.listen(port, () => {
                console.info(`🌟 ¡El servidor Express ha comenzado en el puerto ${port}! 🚀✨`);
            });
        }
        catch (error) {
            console.error('Error al iniciar la aplicación:', error);
        }
    });
}
startServer();
//# sourceMappingURL=server.js.map