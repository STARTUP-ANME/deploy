"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authController = void 0;
const http_status_codes_1 = require("http-status-codes");
const auth_service_1 = require("../services/auth.service");
const bycrypt_handler_1 = require("../../core/handler/bycrypt.handler");
const token_handler_1 = require("../../core/handler/token.handler");
const MessaApi_1 = require("../../core/constants/MessaApi");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const usuario_service_1 = require("../../sistema/usuario/services/usuario.service");
const empresa_service_1 = require("../../empresa/empresa/service/empresa.service");
const email_service_1 = require("../../email/service/email.service");
const permisoUsuario_service_1 = require("../../sistema/permisoUsuario/services/permisoUsuario.service");
const session_service_1 = require("../../sistema/session/services/session.service");
const websocketService_1 = require("../../websocketService");
class AuthController {
    static getInstance() {
        if (!this.instance)
            this.instance = new AuthController();
        return this.instance;
    }
    signIn(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const { usuarioNombre, clave } = req.body;
                // Llamada al servicio de autenticación para obtener el usuario
                const usuario = yield auth_service_1.authService.signIn(usuarioNombre, dataSource);
                // Si el usuario no existe, responde con error de autorización
                if (!usuario) {
                    return res.status(http_status_codes_1.StatusCodes.UNAUTHORIZED).json({ message: 'Unauthorized' });
                }
                // Verificación de la contraseña
                const correctPassword = yield (0, bycrypt_handler_1.compare)(clave, usuario.clave);
                if (!correctPassword) {
                    return res.status(http_status_codes_1.StatusCodes.UNAUTHORIZED).json({ message: 'Unauthorized' });
                }
                // Generación del token de acceso
                const token = yield (0, token_handler_1.tokenSign)(usuario);
                // Preparar la respuesta de autenticación
                const _usuario = yield usuario_service_1.usuarioService.findUsuarioOne(Number(usuario.usuarioId), dataSource);
                _usuario.clave = '';
                const permissions = yield permisoUsuario_service_1.permisoUsuarioService.findPermisoUsuario(usuario.usuarioId, dataSource);
                const createSession = {
                    sessionId: 0,
                    token,
                    usuarioId: usuario.usuarioId,
                };
                yield session_service_1.sessionService.create(createSession, dataSource);
                const usuarioSession = yield usuario_service_1.usuarioService.findUsuarioOne(Number(usuario.usuarioId), dataSource);
                const response = {
                    usuario: _usuario,
                    accessToken: token,
                    tokenType: "bearer",
                    permissions,
                    sessions: usuarioSession.sessions
                };
                const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
                websocketService_1.websocketService.notifyUser(usuario.usuarioId, empresa.uuid, usuarioSession.sessions);
                // Enviar respuesta exitosa con el token
                return res.status(http_status_codes_1.StatusCodes.OK).json(response);
            }
            catch (error) {
                // Manejo de error interno del servidor
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
    signInWithToken(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const dataSource = req['dbConnection'];
                const accessToken = req.body.accessToken;
                // Verify the token
                if ((0, token_handler_1.verifyJWTToken)(accessToken)) {
                    const decodedToken = jsonwebtoken_1.default.verify(accessToken, process.env.JWT_SECRET);
                    const { usuarioId } = decodedToken;
                    const usuario = yield usuario_service_1.usuarioService.findUsuarioOne(Number(usuarioId), dataSource);
                    const token = yield (0, token_handler_1.tokenSign)(usuario);
                    //const permissionRole = await permisoRolService.findPermisoRol(usuario.rolId)
                    const permissions = yield permisoUsuario_service_1.permisoUsuarioService.findPermisoUsuario(usuario.usuarioId, dataSource);
                    const usuarioSession = yield usuario_service_1.usuarioService.findUsuarioOne(Number(usuario.usuarioId), dataSource);
                    usuario.clave = '';
                    const response = {
                        usuario: usuario,
                        accessToken: token,
                        tokenType: "bearer",
                        permissions,
                        sessions: usuarioSession.sessions
                    };
                    const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
                    websocketService_1.websocketService.notifyUser(usuario.usuarioId, empresa.uuid, usuarioSession.sessions);
                    return res.status(http_status_codes_1.StatusCodes.OK).json(response);
                }
            }
            catch (error) {
                // Manejo de error interno del servidor
                return res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json({
                    code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
                    success: false,
                    message: MessaApi_1.MessageApi.ERROR_SERVER
                });
            }
        });
    }
    forgotPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const dataSource = req['dbConnection'];
            const { email } = req.body;
            const usuario = yield usuario_service_1.usuarioService.findUsuarioByEmail(email, dataSource);
            if (!usuario) {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('No tienes acceso');
                return;
            }
            const empresa = yield empresa_service_1.empresaService.findOneEmpresa(dataSource);
            const configEmail = {
                configEmailId: 0,
                name: empresa.nombre,
                user: empresa.email,
                pass: empresa.contrasena,
                host: empresa.servidor,
                port: empresa.puerto,
                secure: empresa.ssl,
                companyId: 0, //umuw rfne brzp tqvi       
            };
            if (!empresa.dominioPrincipal) {
                res.status(http_status_codes_1.StatusCodes.NOT_FOUND).json('not found');
                return;
            }
            const token = yield (0, token_handler_1.tokenSign)(usuario);
            const resetLink = `${empresa.dominioPrincipal}/reset-password?token=${token}`;
            const content = yield auth_service_1.authService.generateContentForgotPassowrd(resetLink);
            const emailModel = [{
                    recipient: usuario.persona.email,
                    subject: `${usuario.persona.nombres} ${usuario.persona.apePaterno} ${usuario.persona.apeMaterno}`,
                    content: content,
                    name: `${usuario.persona.nombres} ${usuario.persona.apePaterno} ${usuario.persona.apeMaterno}`,
                    account: empresa.nombre
                }];
            const response = yield email_service_1.emailService.sendEmail(configEmail, emailModel, content);
            if (response) {
                res.status(http_status_codes_1.StatusCodes.OK).json('Ok');
            }
            else {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
            }
        });
    }
    resetPassword(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const { token, password } = req.body;
            const dataSource = req['dbConnection'];
            if (!(0, token_handler_1.verifyJWTToken)(token)) {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
                return;
            }
            const decodedToken = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
            const { usuarioId } = decodedToken;
            const updatePassword = yield usuario_service_1.usuarioService.updatePassword(usuarioId, password, dataSource);
            if ((updatePassword === null || updatePassword === void 0 ? void 0 : updatePassword.affected) > 0) {
                res.status(http_status_codes_1.StatusCodes.OK).json('Ok');
            }
            else {
                res.status(http_status_codes_1.StatusCodes.FORBIDDEN).json('not found');
            }
        });
    }
}
exports.authController = AuthController.getInstance();
//# sourceMappingURL=auth.controller.js.map