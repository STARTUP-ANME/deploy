"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoute = void 0;
const express_1 = require("express");
const auth_controller_1 = require("../controller/auth.controller");
exports.authRoute = (0, express_1.Router)();
exports.authRoute.post('/sign-in', auth_controller_1.authController.signIn);
exports.authRoute.post('/sign-in-with-token', auth_controller_1.authController.signInWithToken);
//# sourceMappingURL=auth.router.js.map