"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoute = void 0;
const express_1 = require("express");
const auth_controller_1 = require("../controller/auth.controller");
const db_midleware_1 = require("../../core/middleware/db.midleware");
exports.authRoute = (0, express_1.Router)();
exports.authRoute.post('/sign-in', db_midleware_1.dbMiddleware, auth_controller_1.authController.signIn);
exports.authRoute.post('/sign-in-with-token', db_midleware_1.dbMiddleware, auth_controller_1.authController.signInWithToken);
exports.authRoute.post('/forgot-password', db_midleware_1.dbMiddleware, auth_controller_1.authController.forgotPassword);
exports.authRoute.post('/reset-password', db_midleware_1.dbMiddleware, auth_controller_1.authController.resetPassword);
//# sourceMappingURL=auth.router.js.map