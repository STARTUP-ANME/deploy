"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authService = void 0;
const entities_1 = require("entities");
const log_helper_1 = require("../../core/helpers/log.helper");
class AuthService {
    static getInstance() {
        if (!this.instance)
            this.instance = new AuthService();
        return this.instance;
    }
    /**
     * Iniciar sesion
     * @returns
     */
    signIn(usuarioNombre, dataSource) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield dataSource.getRepository(entities_1.UsuarioModel).findOne({
                    where: {
                        usuarioNombre,
                        audAnulado: '0'
                    },
                    select: {
                        usuarioId: true,
                        avatar: true,
                        usuarioNombre: true,
                        clave: true,
                        rolId: true
                    }
                });
            }
            catch (error) {
                log_helper_1.logger.error(error);
                return null;
            }
        });
    }
    generateContentForgotPassowrd(resetLink) {
        return __awaiter(this, void 0, void 0, function* () {
            const template = `<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
            margin: auto;
        }
        .button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            margin-top: 20px;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Restablecer tu contraseña</h1>
        <p>Haz clic en el botón de abajo para restablecer tu contraseña:</p>
        <a href="{{ resetLink }}" class="button">Restablecer Contraseña</a>
        <p>Si no solicitaste este cambio, puedes ignorar este mensaje.</p>
    </div>
</body>
</html>
`.replace('{{ resetLink }}', resetLink);
            return template;
        });
    }
}
exports.authService = AuthService.getInstance();
//# sourceMappingURL=auth.service.js.map