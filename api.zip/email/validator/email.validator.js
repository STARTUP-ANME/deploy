"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateSendEmail = void 0;
const express_validator_1 = require("express-validator");
const validate_result_1 = require("../../core/handler/validate.result");
exports.validateSendEmail = [
    (0, express_validator_1.check)("description").exists().not().isEmpty(),
    (req, res, next) => {
        (0, validate_result_1.ValidateResult)(req, res, next);
    }
];
//# sourceMappingURL=email.validator.js.map