"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailController = void 0;
const http_status_codes_1 = require("http-status-codes");
const email_service_1 = require("../service/email.service");
const MessaApi_1 = require("../../core/constants/MessaApi");
class EmailController {
    constructor() {
        this.sendEmail = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { configEmail, emails, content } = req.body;
            const response = yield email_service_1.emailService.sendEmail(configEmail, emails, content);
            if (response) {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.OK, success: true, message: MessaApi_1.MessageApi.SUCCESS_MESSAGE_EMAIL, data: response });
            }
            else {
                res.status(http_status_codes_1.StatusCodes.OK).json({ code: http_status_codes_1.StatusCodes.FORBIDDEN, success: false, message: MessaApi_1.MessageApi.ERROR_SERVER });
            }
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new EmailController();
        return this.instance;
    }
}
exports.emailController = EmailController.getInstance();
//# sourceMappingURL=email.controller.js.map