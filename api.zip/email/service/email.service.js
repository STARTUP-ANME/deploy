"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailService = void 0;
const nodemailer = __importStar(require("nodemailer"));
class EmailService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new EmailService();
        }
        return this.instance;
    }
    createTransporter(config) {
        return nodemailer.createTransport(config);
    }
    sendEmail(configEmail, emails, content) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const transporter = nodemailer.createTransport({
                    service: configEmail.host === 'gmail' ? 'gmail' : undefined, // Verifica si es Gmail
                    host: configEmail.host !== 'gmail' ? configEmail.host : undefined, // Solo define host si no es Gmail
                    port: configEmail.host !== 'gmail' ? configEmail.port : undefined, // Solo define puerto si no es Gmail
                    auth: {
                        user: configEmail.user, // Tu correo de Gmail o el del otro servicio
                        pass: configEmail.pass // Contraseña de aplicación para Gmail o la contraseña para otro servicio
                    }
                });
                //'angelmn.dev@gmail.com'
                // egja mopo fynz qssy
                let response;
                for (const item of emails) {
                    let mailOptions = {
                        from: `${item.account} <${configEmail.user}>`, //configEmail.user,
                        to: item.recipient,
                        subject: item.subject,
                        text: item.content,
                        html: item.content,
                    };
                    let info = yield transporter.sendMail(mailOptions);
                    response = info.response;
                }
                return response;
            }
            catch (error) {
                console.error('Error al enviar el correo:', error);
                return null;
            }
        });
    }
}
exports.emailService = EmailService.getInstance();
//# sourceMappingURL=email.service.js.map