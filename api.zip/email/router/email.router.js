"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailRoute = void 0;
const express_1 = require("express");
const email_controller_1 = require("../controller/email.controller");
exports.emailRoute = (0, express_1.Router)();
exports.emailRoute.post('/', email_controller_1.emailController.sendEmail);
//# sourceMappingURL=email.router.js.map