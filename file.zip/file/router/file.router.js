"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileRoute = void 0;
const express_1 = require("express");
const file_controller_1 = require("../controller/file.controller");
const multer_middleware_1 = require("../../common/middleware/multer.middleware");
exports.fileRoute = (0, express_1.Router)();
exports.fileRoute.post('/upload', multer_middleware_1.upload.array('file'), file_controller_1.fileController.uploadFile);
exports.fileRoute.post('/download', file_controller_1.fileController.downloadFile);
//# sourceMappingURL=file.router.js.map