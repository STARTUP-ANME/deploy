"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileController = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const request_handler_1 = require("../../common/handler/request.handler");
const http_status_codes_1 = require("http-status-codes");
const message_api_1 = require("../../common/constant/message.api");
class FileController {
    constructor() {
        this.uploadFile = (req, res) => __awaiter(this, void 0, void 0, function* () {
            (0, request_handler_1.HandleRequest)(res, () => __awaiter(this, void 0, void 0, function* () {
                const { body, files } = req;
                const names = [];
                if (Array.isArray(files)) {
                    const SERVER_URL = process.env.SERVER_URL || '';
                    const uuid = body.uuid;
                    files.forEach(element => {
                        names.push({
                            name: element.filename,
                            url: `${SERVER_URL}/public-files/${uuid}/${element.filename}`
                        });
                    });
                }
                if (names.length > 0)
                    return { code: http_status_codes_1.StatusCodes.OK, success: true, message: message_api_1.MessageCustomApi.FILE_SAVE_SUCCESS, data: names };
                else
                    return { code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR, success: false, message: message_api_1.MessageCustomApi.FILE_SAVE_ERROR };
            }));
        });
        this.downloadFile = (req, res) => __awaiter(this, void 0, void 0, function* () {
            const { uuid, fileName } = req.body;
            const filePath = path_1.default.join('uploads', uuid, fileName);
            if (!fs_1.default.existsSync(filePath)) {
                return res.status(404).json({ message: 'Archivo no encontrado.' });
            }
            res.download(filePath);
        });
    }
    static getInstance() {
        if (!this.instance)
            this.instance = new FileController();
        return this.instance;
    }
}
exports.fileController = FileController.getInstance();
//# sourceMappingURL=file.controller.js.map