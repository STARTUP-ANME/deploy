"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseHandler = void 0;
const ResponseHandler = (response) => {
    return {
        code: response.code, success: response.success, message: response.message, data: response.data
    };
};
exports.ResponseHandler = ResponseHandler;
//# sourceMappingURL=response.handler.js.map