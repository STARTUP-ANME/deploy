"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HandleRequest = void 0;
const http_status_codes_1 = require("http-status-codes");
const response_handler_1 = require("./response.handler");
const message_api_1 = require("../constant/message.api");
/**
 * - Utilizar HandleRequest para manejar errores de manera uniforme
 * @param res - Envia a front el resultado
 * @param action - El accion que retoran por accion
 */
const HandleRequest = (res, action) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const response = yield action();
        res.status(response.code).json((0, response_handler_1.ResponseHandler)(response));
    }
    catch (error) {
        res.status(http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR).json((0, response_handler_1.ResponseHandler)({
            code: http_status_codes_1.StatusCodes.INTERNAL_SERVER_ERROR,
            success: false,
            message: message_api_1.MessageApi.ERROR_SERVER,
            data: error
        }));
    }
});
exports.HandleRequest = HandleRequest;
//# sourceMappingURL=request.handler.js.map