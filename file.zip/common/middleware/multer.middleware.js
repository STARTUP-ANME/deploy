"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.upload = void 0;
const multer_1 = __importDefault(require("multer"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const storage = multer_1.default.diskStorage({
    destination: function (req, file, cb) {
        const uuid = req.body.uuid;
        const uploadPath = `uploads/${uuid}`;
        fs_1.default.mkdir(uploadPath, { recursive: true }, (err) => {
            if (err) {
                return cb(err, uploadPath);
            }
            cb(null, uploadPath);
        });
    },
    filename: function (req, file, cb) {
        const extname = path_1.default.extname(file.originalname);
        const cleanedName = file.originalname
            .replace(/\s+/g, '_') // Reemplaza espacios por guiones bajos
            .replace(/[^a-zA-Z0-9._-]/g, '') // Elimina caracteres no permitidos
            .toLowerCase();
        //const filename = `${uuidv4()}${extname}`;
        cb(null, cleanedName);
    },
});
exports.upload = (0, multer_1.default)({ storage });
//# sourceMappingURL=multer.middleware.js.map